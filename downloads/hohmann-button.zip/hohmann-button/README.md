# hohmann-button

A button that waits in a parking orbit while its work is queued, then inks the transfer from Earth to Mars as the work is done. The craft meets Mars at 100% and the button says it is done.

This is the button part of `hohmann-loader` and nothing else: the inline loader inside a real `<button>`, at three sizes, with no page plate, essay or texture. The drawing comes from the original engine, `hohmann-loader.js`, which is unchanged. `hohmann-button.js` gives it a button (states, words, aria, a polite status line) and a way to drive it.

**The house rule this piece breaks, and why.** The first rule (`CONVENTIONS.md`, and "What a button means here" in
`notes/round-6/README.md`) asks for a real photographed object whose own part moves, as rigid real pixels, when it is
pressed; `components/elephant-clock` is the bar. Here the object is the original loader's engraving, generated as SVG
by `hohmann-loader.js`, not a photograph, and a press moves drawn planets, not photographed pixels. It stays because
Connor asked for the Hohmann loader's button part, and the engine stays byte for byte. If every piece in the Buttons
section must be a photographed part, this one needs a different object (a photographed brass orrery with a real arm,
say), not a fix here.

## Markup

```html
<link rel="stylesheet" href="hohmann-loader.css">
<link rel="stylesheet" href="hohmann-button.css">

<button type="button" class="hb" data-hohmann-button
        data-working="Publishing" data-done="Published">Publish</button>

<button type="button" class="hb hb-sm" data-hohmann-button>Back up</button>        <!-- a 36px row button -->
<button type="button" class="hb hb-lg" data-hohmann-button>Send</button>           <!-- 60px -->
<button type="button" class="hb hb-solid" data-hohmann-button>Publish</button>     <!-- the primary, in ink -->
<button type="button" class="hb hb-sm" data-hohmann-button disabled>Copy</button>  <!-- not now -->

<script type="module" src="hohmann-button.js"></script>
```

The script puts the original's inline loader in front of the word:
`<span data-hohmann-loader><progress max="100" value="0"></progress></span>`. You can write that span
in the button yourself, as the original README does, and the button will use it. Until the script has
started it the span is hidden, so without JS (or after `destroy()`) the browser's own progress bar never
shows in the pill. Its `<progress>` stays the source of truth: with no `value` the craft waits in the parking
orbit, and with a value the transfer is drawn to that share of its time. The button takes the `value` away only
once a job has been quiet for 0.3 s (see States).

## Driving it

A press starts it. The button goes busy and says its working word, and your code does the work and reports it.
If the first report comes within 0.3 s, as upload progress does, the craft leaves straight from the still launch
window; if not, it parks until it does:

```js
const btn = document.getElementById('publish');
btn.addEventListener('hohmann-button:start', async () => {
  const hb = btn.hohmannButton;
  try {
    for await (const share of upload()) hb.progress(share);  // 0..1 of the job: the transfer drawn that far
    hb.done();                   // the craft finishes the transfer, meets Mars, and the button says "Published"
  } catch {
    hb.reset({ say: 'Could not publish' });   // back to rest at once, and the failure is said
  }
});
```

```js
import { hohmannButton } from './hohmann-button.js';
const hb = hohmannButton(btn, { working: 'Sending', done: 'Sent', reset: 2600 });
hb.start();              // busy, no value yet: the parking orbit after 0.3 s (a press does this for you). false if disabled
hb.progress(0.4);        // forwards only; 0 keeps it waiting (still, then in the parking orbit)
hb.done();               // or done({ stay: true }) to keep the done word, done({ say: '3 more uploads' }) to announce that
hb.reset();              // back to rest now, a fresh launch window (abandons a job: stop calling progress)
hb.reset({ say: 'Could not send' });   // the same, and says why. A plain reset() mid-job clears the status line
hb.state;                // 'idle' | 'waiting' | 'working' | 'done'
hb.loader;               // the hohmann-loader controller underneath
hb.destroy();            // removes everything it added; the button is its own markup again
```

Report in small, frequent steps, as progress events come: the drawing then keeps an even pace with the work.
A big jump is eased in over about 0.3 s, and the planets hurry to catch up with it.

`done()` with no progress before it is fine: the whole transfer is drawn, and the button passes through
working on the way. After `destroy()` the controller does nothing. A late `progress()`, `done()` or `reset()`
from a job that outlived the button is ignored, and a second `destroy()` is a no-op, even after the button has
been set up again.

### Options (data attributes or the options object, which wins)

| | default | |
|---|---|---|
| `data-working` | the word | the word while busy ("Publishing") |
| `data-done` | the word | the word once the craft has arrived ("Published") |
| `data-reset` | `2600` | ms showing the done word before it comes back to rest; `0` stays done until `reset()` |
| `data-auto` | `true` | `false`: a press does not start it, so call `start()` yourself (after validating a form, say) |
| `data-status` | none | the id of an element to speak through, in place of the status line the script adds after the button. Give it `role="status"`. If it has neither a role nor `aria-live`, the script adds `role="status"` and takes it off again in `destroy()`. Use it when the button may be removed, so its last word is said from an element that stays, or when the button's siblings must stay as they are (see Accessibility) |
| `data-coast` | `6` | engine: seconds for Earth to go once round the parking orbit while waiting (Mars takes 1.9 times as long). The engine's own default, 2.6 s, reads as a spinner at button size; 6 s is a calm drift of about 60° a second |
| `data-pace` | `1.25` | engine: the shortest time, in seconds, to draw the whole transfer. A quick job is drawn at this pace, so Earth sweeps its 255° of the transfer in 1.25 s. A larger value sweeps more calmly, and the done word comes later |
| `data-fine` | `false` | engine: the engraved detail (Sun rays, hatched planets, ticks). It is drawn for a loader a few hundred px across. At button sizes it is too faint to read, so leave it off |

Size is the class: `.hb-sm` 36px with a 22px orrery, the default 46px with 26px (the original's button), and
`.hb-lg` 60px with 38px. The orrery sits concentric with the pill's round end. `.hb-solid` is the primary in
ink, with the drawing in paper. `.hb-block` makes it fill its row.

The pill hugs its resting word, so it is even at rest, and it never gets narrower than that: a shorter busy or
done word ("Load more" to "Loading" to "Loaded") keeps the pill's size, set at the start next to the orrery, so
the words that share a beginning cross-fade only where they differ. A longer word ("Send" to "Sending", "Publish"
to "Publishing") grows the pill over 0.22 s: to the right in a left-aligned slot, to the left in a right-aligned
one. Give it room to grow into if its neighbours must not move (the demo's editor footer puts Save draft at
the other end). Keep the word short when the words around the button already say what it sends: a long resting
word leaves a shorter busy word sitting in an empty pill. When the word changes, the old one fades out in 0.1 s,
fast first, and the new one fades in over 0.2 s from 0.04 s, so the two only overlap while both are faint (they
never read as one garbled word) and the cell is never empty.

Theme with `--paper`, `--ink`, `--ink-2`, `--ink-3`, `--rule` and `--sans`. `--hb-paper` is the button's face
and also the loader's paper, so set it to whatever is behind an outline button (the demo's cards set it to
their sheet colour). `--hl-size` sets the orrery's size.

### Events (all bubble)

| | when |
|---|---|
| `hohmann-button:start` | pressed (or `start()`): your cue to begin the work |
| `hohmann-button:state` | every change, `detail: { state, from }`: idle, waiting, working, done, idle |
| `hohmann:arrive` | from the engine: the craft has reached Mars |

### States

| | the button | the drawing |
|---|---|---|
| idle | its word | the launch window: Earth, with the craft, and Mars 44.3° ahead of it, still |
| pressed | the outline face sinks a pixel and darkens a touch; the ink face lifts a clear step instead, since near-black cannot darken much (the main mouse button, a touch, a held Space; under reduced motion the colour changes and nothing sinks). A mouse press slid off the button lets go of it, as releasing there does nothing, and slid back on it presses again | as at rest |
| waiting | the working word, `aria-disabled` | for 0.3 s the launch window holds still, so a job that reports at once leaves straight from it. A job still quiet after that parks the craft: Earth with the craft, and Mars, going round at their true rates (Earth once in 6 s) |
| working | the working word | the transfer inked from the launch window to the job's share of its time. From the parking orbit, the parking picture first cross-fades to a fresh launch window over 0.25 s: the Sun and the orbits stay put, the planets and the craft fade from their parked places into their launch places, and the ink starts at once. The icon never empties |
| done | the done word | the craft on Mars. After `data-reset` ms, the same cross-fade to a fresh launch window |
| disabled | grey word, faint edge, no hover and no press. The `disabled` attribute (or a disabled `<fieldset>`), or your own `aria-disabled="true"`, at rest. A button disabled while its job runs keeps its busy and done look and goes grey when it comes back to rest | the launch window, in grey |

At rest the drawing is part of the button: the still launch window. The original's button kept its loader
hidden until it was pressed, so the drawing appearing (and the pill widening) was the press's first answer.

## Accessibility

- A real `<button>`. Its name is the visible word, which changes with the state (Publish, Publishing,
  Published). Only the word on show is in the name: the others are `aria-hidden`, and hidden once faded.
- The drawing is `aria-hidden` (a button's children are presentational anyway). A polite `role="status"`
  after the button says the start, then a step of ten at most every three seconds, then the end, or the word
  given to `reset({ say })`. A button set up in script before it is in the page gets that line once it is in
  (on focus, a press, or its first word), and its first word goes in a moment after the line, so it is heard.
- That line is a sibling right after the button, so it changes what `:last-child`, `:only-child` and `+` match
  in your CSS (`.hb + .hb` in a button group, say). It sits there so it stays inside the same dialog or region
  as the button. If the siblings must stay as they are, point `data-status` at a live region of your own.
- While busy it stays focusable and is `aria-disabled="true"`. A second press, Space or Enter does nothing,
  so a form is never sent twice. Focus is never moved. Back at rest your own `aria-disabled` is put back.
- Disabled: with `disabled` it is out of the Tab order and ignores every press, and `start()` returns false.
  With your own `aria-disabled="true"` (the focusable pattern) it stays in the Tab order; a press does not start
  it or submit a form, but your own click listeners still hear it, so you can say why.
- Visible focus: a 2px ring, 3px off the pill. Hover styles only apply where there is a real hover, and only
  when a press would do something, so a tapped button does not stay lit and a busy one does not look pressable.
  Only the main mouse button shows the pressed look, and a press slid off the button visibly lets go.
- Forced colours (Windows high contrast): the drawing takes the button's own text colour on its face, and
  GrayText when disabled.
- Reduced motion: nothing moves by itself. The parking picture holds still, each progress step snaps the
  transfer to its fraction, the words and the width change at once, and the departure, the arrival and the
  reset have no cross-fade.
- No JS: a plain, even pill with its word (and the browser's own disabled look when disabled).

## In life, and here

| In life | Here |
|---|---|
| A craft bound for Mars waits in a parking orbit for its window, when Mars is 44.3° ahead of Earth. That comes round about every 26 months. | Pressed, the button holds the launch window for a moment, and a job that reports at once leaves straight from it. A job that is really queued parks the craft. A button cannot make you wait for the window, and running the clock on to it is a whirl (Earth goes round once or twice in half a second), so when the first progress comes in the parking picture cross-fades to the window and the craft leaves from there, always from the left. |
| Two burns along the direction of travel. The transfer ellipse touches Earth's orbit at perihelion and Mars's at aphelion, and takes half its period, 258.9 days. | The job's progress is the transfer's time (mean anomaly, through Kepler's equation every frame). The craft runs out fast and slows as it climbs, so 50% of the job has it 113° of the 180° round, over the top from left to right. |
| Mars reaches the meeting point exactly as the craft does. | At 100% the craft meets Mars, `hohmann:arrive` fires, and the button says it is done. |

Simplified as in the original: the orbits are circular and coplanar, the burns are impulsive, and the Sun and
planets are not to scale. Nothing runs at rest, so a page of idle buttons draws nothing. The engine's loop
exists only while the craft waits on screen in a visible tab, or while the line still has somewhere to go, and
the button writes the job's progress to the engine only while it is on screen. Off screen the progress is
kept and written once on the way back, and a job that finishes off screen puts the craft on Mars at once
(`hohmann:arrive` still fires), so an upload left running while you scroll away draws nothing at all. A
cross-fade is a copy of the outgoing planets laid over the new drawing for 0.25 s and then removed; off screen,
in a hidden tab or under reduced motion there is none.

## Files

- `hohmann-loader.js`: the engine, byte for byte from `claude-2026-10-27 (set aside)/potential/hohmann-loader`.
  Its full-page plate mode is still inside it, but that mode's styles and texture are not in this folder, so
  use the inline variant only.
- `hohmann-loader.css`: the original stylesheet without its page-plate section.
- `hohmann-button.js`: the button part (states, words, aria, the status line, the API, the grace before
  parking and the cross-fade between pictures).
- `hohmann-button.css`: the button, with three sizes, the ink primary, and the pressed, busy, done and
  disabled states.

## Credits

No outside artwork, sound or code. The script generates the drawing as SVG. The original's plate texture
(`plate-tone.webp`) belongs to its page plate and is not used here. The demo sets its words in Inter and
Cormorant Garamond from Google Fonts (SIL Open Font License). `assets/credits.json` says the same.

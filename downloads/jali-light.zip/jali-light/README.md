# jali-light

A row of real stone windows and the sun that crosses them. Four photographed
jalis (Sidi Saiyyed's tree of life, two from Humayun's Tomb, a floral screen from
Kusru Bagh) hang in a dark stone wall; a flagstone floor runs toward you. Scroll
and you walk along the wall while the sun climbs: a cold grey dawn at the first
window, gold, white noon, amber evening at the last, each window throwing its
lace across the stones at the angle of its own hour. Everything you see is a
photograph (windows, wall, floor); the only thing made in code is the light.
Colour is earned: the room is grey until the sun warms it.

## Markup

```html
<link rel="stylesheet" href="jali-light.css">
<figure data-jali-light data-wall="assets/wall.webp" data-floor="assets/floor.webp">
  <img src="assets/tree-of-life.webp" data-h="1.55" alt="">
  <img src="assets/mihrab.webp" data-h="2.4" alt="">
  <img src="assets/geometric.webp" data-h="2.55" alt="">
  <img src="assets/floral.webp" data-h="2.3" alt="">
</figure>
<script type="module" src="jali-light.js"></script>
```

Or `import { jaliLight } from './jali-light.js'; const destroy = jaliLight(figure, { start: 1 });`

Each `<img>` is one window: a photograph (soft alpha edges so its dark surround
melts into the wall) with a twin beside it named `<name>-mask.webp` (or set
`data-mask`): the same view in greyscale, white where daylight comes through
and black on stone. Make the mask by thresholding the photograph's own
luminance: a window shot from inside against bright daylight gives an exact one
(that is how these four were made). `data-h` is the window's height in the
room's units (about metres); its width follows from the photograph. The script
wraps the figure in a `.jl-track` (the tall scroll lane the figure sticks in)
unless you made one yourself. Without script the windows sit in a row you can
scroll along.

## Atmosphere (`air.js`)

- **Shafts:** each window's own lace is swept through the air along the sun's
  direction in forty thin slices, softer and fainter farther out, every slice cut
  off at the floor, so a shaft ends exactly where its patch of light begins. A
  slow mist thickens and thins it, and a faint haze lifts the far end of the room.
  Brightness and colour follow the hour as you walk.
- **Dust:** three depths of motes (far and tiny, mid, and a few near ones out of
  focus), drawn only as bright as the beam they sit in, so they blink on and off
  as they cross the lace. Warm air lifts them in the beam, a faint draught
  pushes them along, and a mote that has drifted into shade respawns in the
  light. Depth parallax shifts them with the pointer and tilt; they never react to
  a pointer or a finger.
- **Glints:** a slow highlight on the rim of each glass orb, grains of mica in
  the lit floor, and a twinkle on the stone edge of a window.
- Cost: shafts draw on a 0.4x canvas at 30 a second, dust and glints on one
  canvas; both stop when the piece is off screen.

## Options

| `data-` attribute | option | default | |
|---|---|---|---|
| `data-screens` | `screens` | the `<img>` srcs | comma-separated image URLs, if you do not want `<img>` children |
| `data-mask` (on each `<img>`) | `masks` | `<name>-mask.webp` | the greyscale lattice mask for that window |
| `data-h` (on each `<img>`) | `heights` | `1.9` | window height in room units |
| `data-wall` | `wall` | `wall.webp` beside the first screen | seamless wall tile (a scanned stone texture or any stone photograph) |
| `data-floor` | `floor` | `floor.webp` beside the first screen | seamless floor tile |
| `data-start` | `start` | `1` | the window shown in the reduced-motion still, counting from 0 |
| `data-intensity` | `intensity` | `.7` | 0 to 1: how strong the shafts, dust and glints are |
| `data-motes` | `motes` | `700` | specks of dust in the room (half that on a phone); `0` for none |
| `data-dust="off"` | `dust: false` | on | no dust |
| `data-shafts="off"` | `shafts: false` | on | no shafts of light or haze |
| `data-glimmer="off"` | `glimmer: false` | on | no glints on the orbs, floor or window stone |

Theming: the figure fills the viewport height (`height`, `min-height` in the
CSS); `--jl-n` on the track is set for you. The scroll length is
`70svh` per window (the last rule in `jali-light.css`). The day's palette (sun,
sky, ambient, gain, colour amount) is the `STOPS` table at the top of
`jali-light.js`; the room's size is the constants above it.

## Orbs: things in the room

In front of each window hangs one **orb** (`orbs.js`, imported by `jali-light.js`):
a ball of frosted glass with a thin-line glyph in it, hung in the room's own
geometry between the window and you. It travels with the walk and moves more
than the wall behind it; the pointer or the phone's tilt turns it a little toward
you; it bobs slowly. The sun's lace falls across the glass (the same beam lookup
that lights the floor is read over its face), the rim light takes the hour's
colour, and on the floor beneath it sit a soft shadow and a small bright pool of
focused light. A **gaze reticle** follows the mouse; over an orb its ring opens
and fills (on a phone the ring blooms where you tap). Click, tap or Enter and the
orb unfolds into a floating glass window, a small app. Escape, the close button or
a tap outside folds it back and returns focus to the orb.

Four apps ship, one per window: **profile** (a card with an avatar, a name and
three link rows; "Your Name" is placeholder text), **code** (an editor with a
tiny highlighted snippet, two file tabs, a blinking caret), **social** (a feed of
three posts; the heart toggles and counts) and **gallery** (the windows' own
photographs, with arrows and thumbnails). Everything is placeholder content to be
replaced.

Configure on each `<img>`:

```html
<img src="assets/mihrab.webp" data-orb="Code" data-glyph="code" data-app="code" alt="">
```

| `data-` attribute | option (`orbs[i]`) | default | |
|---|---|---|---|
| `data-orb` | `label` | by window: About me, Code, Social, Photographs | the orb's accessible name, and the word that appears when you look at it |
| `data-glyph` | `glyph` | `user`, `code`, `chat`, `photo` | a name from `GLYPHS` in `orbs.js` (`user code chat photo note mail`), or an SVG fragment on a 24-unit grid |
| `data-app` | `app` | `profile`, `code`, `social`, `gallery` | which app opens |
| `data-orbs="off"` on the figure | `orbs: false` | on | no orbs at all |

Options object: `jaliLight(figure, { orbs: [{ label, glyph, app }, ...], apps: { name: (host) => HTMLElement | { el, destroy } }, glyphs: { name: '<path d=...>' } })`.
An app builder receives `{ images(), index, label }` and returns the element that
goes inside the glass window. `jali:open` (detail `{ app, label }`) and `jali:close`
fire on the figure. Where each orb hangs (height, depth, drift off the window's
centre) is the `SPOTS` table in `orbs.js`; the look is the `.jl-orb` rules in the
CSS (`--jl-sun`, `--jl-sky` are set on the figure from the hour).

Accessibility: each orb is a real `<button>` with an `aria-label` and
`aria-haspopup="dialog"`, with a visible focus ring; focusing one walks to its
window. An open app is `role="dialog"` with `aria-modal`, a focus trap and Escape,
and the room behind it is `inert`. Arrow keys inside an app belong to the app.
Reduced motion: no bob, no parallax or turning, no unfolding; orbs still open.

## How the light works

Each floor pixel is a point in a small model of the room (wall at z = 0, floor
at y = 0, a camera 5 units back). To find out whether the sun reaches it, follow
the ray from that point toward the sun until it crosses the wall, and look at
the screens there: stone is shadow, an opening is light. All the screens share
one mask atlas, pre-blurred at six widths, and the lookup picks the width from
the length of the ray: the pattern is crisp at the foot of the wall and melts
to a soft glow far away, as a sun of finite size does. The same lookup lights
each mote of dust, which is why the dust draws the beam in the air, and
nothing else. The floor photograph is laid in perspective a row at a time and
multiplied by that light; the windows are drawn flat in the wall, graded to the
hour (grey and dim at dawn, full colour at noon, dimmer at dusk).

## Input

- Scroll: the page scroll is pinned and mapped to the walk, so it works with a
  wheel, a trackpad or a thumb.
- Drag (mouse or finger), a horizontal wheel or trackpad swipe: they move the
  same scroll. Vertical swipes still scroll the page.
- Keyboard: the room is a group with a polite status line ("window 2 of 4,
  morning"). Left/right step a window, Home/End go to the ends; Tab reaches the
  orbs.
- Pointer x and, on a phone, tilt (`tilt.js`, the house helper; iOS asks on
  first tap) nudge the sun a little around its place.

## Behaviour

Cheap when idle: the scene redraws only when the walk or the sun has moved; the
dust loop runs only while the piece is on screen. Canvas DPR is capped at 2.
Reduced motion: no pinned scroll and no drifting dust; the shafts and a few frozen glints stay, as a finished still of window
`start`. Drag, the pointer and the arrow keys still walk it, directly.
At 390px the windows fill most of the width. `destroy()` removes listeners, observers,
the canvases, the track it made and the ARIA attributes it added.

## Credits

No libraries (`tilt.js` is the house helper, copied in). All photographs,
credited in `assets/credits.json`:

- *Sidi Saiyyed Mosque, marble screen* by Ronakshah1990, CC BY-SA 4.0
- *Humayun's Tomb, jali with symbolic mihrab* by Varun Shiv Kapur, CC BY 2.0
- *Humayun Tomb, jali, Islamic geometric pattern* by Hu741f4, CC BY-SA 4.0
- *Allahabad, Kusru Bagh 11 - jali* by juggadery, CC BY-SA 2.0
- *Stone block wall* and *Monastery stone floor*, scanned textures by Amal Kumar
  (Poly Haven), CC0, from Wikimedia Commons

Three of the four windows are share-alike: if you ship them, credit them and
license the derived images the same way. The two textures are CC0.

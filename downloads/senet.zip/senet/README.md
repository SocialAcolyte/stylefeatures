# senet

Pagination on a senet board. The control is a real `<nav><ol>` of page links (Previous, numbered pages with the
current one marked `aria-current="page"`, Next). Above it lies a photograph of an Egyptian senet board, faience tiles
from a tomb at Abydos made in the reign of Thutmose III (the Met, 01.4.1a), and one of **that board's own pieces**,
photographed from straight above in the same campaign, stands on the square that is the current page. Go to another
page and the piece is moved there the way a player moves it: a move of one to five squares (what a throw of the
sticks can give) is counted out square by square along the board's S, each hop rising under gravity and coming down
with a knock; a longer move is lifted, carried across the board in the air and set down.

Nothing is drawn. The board is the `<img>`; the piece is an `<img>`; its shadow is the piece's own silhouette. At
rest, what you see is the photograph with a real piece on it.

```html
<link rel="stylesheet" href="senet.css">
<nav class="sn" data-senet data-pages="41" data-page="1" data-href="?page={n}" aria-label="Pages">
  <div class="sn-board" aria-hidden="true">
    <img class="sn-art" src="assets/board.webp" srcset="assets/board-1200.webp 1200w, assets/board.webp 2400w"
         sizes="(max-width: 1100px) calc(100vw - 32px), 1040px" width="2400" height="755" alt="">
    <!-- --x / --y: the current page's square, so the piece stands there without JS (see "Squares" below) -->
    <img class="sn-piece" src="assets/cone.webp" width="192" height="192" alt="" style="--x:.0605;--y:.1895">
  </div>
  <ol class="sn-pages">
    <li class="sn-step sn-prev"><span class="sn-off" aria-disabled="true"><span aria-hidden="true">‹ </span><span class="sn-word">Previous</span></span></li>
    <li><a href="?page=1" aria-current="page">1</a></li>
    <li><a href="?page=2">2</a></li>
    <li><a href="?page=3">3</a></li>
    <li class="sn-gap" aria-hidden="true">…</li>
    <li><a href="?page=41">41</a></li>
    <li class="sn-step sn-next"><a href="?page=2" rel="next" aria-label="Next page"><span class="sn-word">Next</span><span aria-hidden="true"> ›</span></a></li>
  </ol>
</nav>

<!-- compact, for a footer: a small board between ‹ and ›, "3 / 6" under it, a spool for the piece -->
<nav class="sn sn-compact" data-senet data-pages="6" data-href="?note={n}" data-param="note" data-label="Note" aria-label="Notes">
  <div class="sn-board" aria-hidden="true">
    <img class="sn-art" src="assets/board-1200.webp" width="1200" height="378" alt="">
    <img class="sn-piece sn-spool" src="assets/spool.webp" width="195" height="195" alt="">
  </div>
  <ol class="sn-pages">…Previous, <li class="sn-count"><a … aria-current="page">1</a><span aria-hidden="true"> / 6</span></li>, Next…</ol>
</nav>
<script type="module" src="senet.js"></script>
```

```js
import { senet, squareOf, windowed } from './senet.js';
const s = nav.senet;            // auto-started controller (or senet(nav, opts) yourself; the same one comes back)
s.go(12);                       // move to page 12 (pushes ?page=12 unless history is 'none')
s.page; s.pages;                // live
s.setPages(50);                 // the list grew
s.hold(); s.advance(120);       // stills: freeze, then step the simulation by hand (ms)
s.release();
s();                            // destroy: removes listeners, the shadow, the tip and the live region
nav.addEventListener('senet:change', (e) => e.detail);   // {page, from, pages, square}: render that page here
nav.addEventListener('senet:knock', (e) => e.detail);    // {square, force 0..1}: the piece touched down
nav.addEventListener('senet:settle', (e) => e.detail);   // {page}: it is at rest
```

## Options

| attribute | option | default | |
|---|---|---|---|
| `data-pages` | `pages` | 1 | how many pages |
| `data-page` | `page` | the URL's `?<param>`, else `data-page`, else the `aria-current` link, else 1 | the current page |
| `data-href` | `href` | `?page={n}` | each link's href; `{n}` is the page |
| `data-param` | `param` | `page` | the query parameter read on load and on Back/Forward |
| `data-history` | `history` | `push` | `push` / `replace`: the component handles the click, updates the URL and fires `senet:change` (you render the page). `none`: no URL change. `load`: the links navigate normally (a multi-page site); the page you left is kept in `sessionStorage`, and the new page's piece starts on its old square and walks to the new one |
| `data-around` | `around` | 2, or 1 when the nav is under 520 px | pages either side of the current one in the list |
| `data-label` | `label` | `Page` | the word in the live announcement ("Page 4 of 41") |
| class `sn-compact` | `compact` | | Previous, the small board, Next; "4 / 41" under the board |
| class `sn-spool` on `.sn-piece` | | | use the spool (`assets/spool.webp`) instead of the cone |

## Squares and pages

Thirty squares, played in the S the Egyptians played them in: 1–10 along the top row left to right, 11–20 back along
the middle, 21–30 along the bottom. Their centres were measured on the photograph (`tools/cut.py` → `assets/board.json`,
copied into `SQUARES` in `senet.js`). Without JS, write the current square's centre into the piece's `--x` / `--y`
(fractions of the board image).

- **30 pages or fewer**: page *n* is square *n*; the squares after the last page stay empty.
- **More than 30**: the last five pages always take the marked squares 26–30 (the house of beauty, the water, and
  the squares off the board), and the pages before them share squares 1–25 evenly (`squareOf`). On a long list the
  piece's place is how far through you are, and the end of the series is the end of the game. A page change that
  stays on the same square still answers: the piece is lifted (0.26 s in the air, about three quarters of its width)
  and set down where it was, with the same `senet:knock`. Why not a windowed mapping (the current page and its
  neighbours always on squares of their own): with more than 30 pages no fixed mapping can give every page its own
  square, so a windowed one would have to depend on the path you took, and the same URL would show the piece in
  different places. The even share keeps one page, one place.

The list under the board is the control and the tap target (44 px tall, at least 34 px wide). With a pointer, the
squares are targets too: hovering one shows the page or pages it holds, and clicking goes there.

## In life, and here

| In life | Here |
|---|---|
| A senet board is thirty squares in three rows of ten, played as an S: along the top, back along the middle, along the bottom. This one is faience tiles from tomb D99 at Abydos (reign of Thutmose III, ca. 1479–1425 BCE), set by the museum into a modern wooden box 43 cm long. | The Met's straight-down photograph of it (01.4.1a_EGDP013652, 4000 px), cropped to the box top and cut along its four straight edges. Scaled, never redrawn. The squares' centres are measured on it; the piece only ever moves between them along the S. |
| The last squares are marked. Here 26 has three *nefer* signs (the house of beauty), 27 water, 28 part of a sign. | The last five pages of a long list always land on 26–30. |
| The pieces are cones and spools of blue faience marbled in black, about half a tile across, kept in the box's drawer. | One cone (or one spool in the compact variant), from the same set, photographed straight down in the same campaign and matted. Its size is half a tile, the ratio measured on the Met's three-quarter view DP310299, where these pieces stand on this board. On a small board (a phone) it is never drawn under 23 px (`--sn-min`), nor over 82% of a tile, so it stays a piece and never covers the dividers; its shadow keeps at least 1.2 px of offset and blur there, to stand it off the pale tiles. |
| A move is cast with four throw sticks: one to five squares. The player counts the squares out, touching each. | A move of one to five squares is counted out: each square is a hop, up under gravity (90 piece-diameters/s², 0.2 s in the air, rising about half its width) while a critically damped spring on the hand carries it across, then a knock (`senet:knock`) and a 50 ms pause before the next. |
| A piece moved further than a throw (setting up, putting away) is picked up and carried. | More than five squares: a spring lifts it to about one piece-width above the board, a slower critically damped spring carries it straight to the square in the air, and a third lowers it until the board stops it. |
| Lifted, the piece comes nearer the eye and its shadow leaves it. | As it rises it grows by up to 12% (the camera is straight above) and its shadow, the same image blackened and blurred, falls further off and softer. |
| | Fixed steps at 240 Hz inside `requestAnimationFrame`; the loop runs only while the piece moves. |

## Accessibility

- A `<nav>` with your `aria-label`, an `<ol>` of real links, `aria-current="page"`, `rel="prev"` / `rel="next"`,
  Previous / Next as `<span aria-disabled="true">` on the first and last page.
- The board is `aria-hidden`: it is the picture of the control, the list is the control.
- A polite live region says "Page 4 of 41" after each change. Focus stays where it was: on Previous / Next if you
  pressed one, else on the new current page.
- Back and Forward move the piece (popstate).
- Reduced motion: the piece is on its square at once.
- Without JS: the links work as links, and the piece stands where `--x` / `--y` put it.

## Theming

`--ink`, `--ink-2`, `--ink-3`, `--rule`, `--paper`, `--serif`, `--sans` as everywhere; `--sn-max` is the board's
widest (1040 px, 300 px compact). The current page is underlined in the faience's own turquoise (`#1aa5a6`).

## Files

- `assets/board.webp` (2400 × 755, 0.55 MB), `assets/board-1200.webp` (0.12 MB), `assets/cone.webp`,
  `assets/spool.webp`, `assets/board.json` (squares, piece sizes), `assets/credits.json`, `assets/PICK.md`.
- `assets/catalogue/`, `assets/catalogue.json`: the demo's handlist only (483 Cleveland Museum of Art objects, CC0).
- `tools/cut.py`: board crop and alpha, square measurement, piece mattes and scale. `tools/catalogue.py`: the demo's
  handlist. `tools/demo_page1.py`: writes page 1 of the handlist into `demo.html`, so it is a page without JS.

## Sound

None yet. `senet:knock` fires on every touchdown with a force, for a recorded knock of faience on faience to be
wired to with the studio's sound tool. No real recording of a small ceramic piece on a tile turned up (Commons has
door knocks), and a synthesized click would be worse than silence.

## Credits

Board and pieces: The Metropolitan Museum of Art, Gameboard and Gaming Pieces, 01.4.1a–p, Gift of Egypt Exploration
Fund, 1901, CC0. Handlist: The Cleveland Museum of Art Open Access, CC0. Matte: BiRefNet via the asset engine
(`tools/engine/stages/matte.py`). Details in `assets/credits.json`.

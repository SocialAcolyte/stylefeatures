# dragon-volvelle

A loader / progress indicator that is Peter Apian's lunar dragon volvelle, from the *Astronomicum Caesareum*
(Ingolstadt, 1540). The hand-coloured woodcut lies on the page, cut to its printed outline, and its own paper disc
turns on its centre over the printed zodiac, the way the book's reader turned it.

With a value, the disc has turned through that share of a full turn: the dragon's head (the tab CAPVT) goes back
through the signs, the way the moon's node does, and at 100% it is home where it was printed. With no value, the disc
keeps going round slowly. While it waits it can be handled: take the disc and turn it, and when you let go the work
takes it back.

At rest it is the plate, pixel for pixel: what you are looking at is the `<img>`. The control is a real `<progress>`.

```html
<link rel="stylesheet" href="dragon-volvelle.css">
<div class="dv dv-wide" data-dragon-volvelle>
  <div class="dv-plate"><img class="dv-img" src="assets/plate.webp" width="1600" height="2063" alt="…"></div>
  <div class="dv-face">
    <label class="dv-label" for="up">Uploading 12 files</label>
    <progress id="up" max="12" value="0">0 of 12</progress>      <!-- no value attribute = indeterminate -->
    <p class="dv-readout" aria-hidden="true">0%</p>
  </div>
</div>
<!-- small, beside a line of words: a thumbnail of the plate -->
<div class="dv dv-small" data-dragon-volvelle>…same plate…<label class="dv-label" for="s">Saving</label><progress id="s"></progress>…</div>
<script type="module" src="dragon-volvelle.js"></script>
```

Drive it by setting the `<progress>` as you normally would (`bar.value = n`, or `bar.removeAttribute('value')` for
indeterminate). The component watches the element. Or use the API:

```js
import { dragonVolvelle } from './dragon-volvelle.js';
const v = dragonVolvelle(root, { turn: 40 });
v.value = .4;      // 40%: the disc goes 144 degrees back through the signs
v.value = null;    // indeterminate: it goes round
v.done();          // 100%: home
root.addEventListener('dragon-volvelle:change', (e) => e.detail.value);
root.addEventListener('dragon-volvelle:done', () => {});
root.addEventListener('dragon-volvelle:turned', (e) => e.detail.angle);   // a hand let go of it
v();               // destroy: removes the canvas, live region, listeners and loop; leaves the plain markup
```

If the value goes down (a new job), the disc carries on forwards from wherever it is, so it never runs backwards.
Without JS it is the plate and a native `<progress>` (the CSS hides the bar only once the script has started).

## In life, and here

| In life | Here |
|---|---|
| Apian printed the plates from woodblocks, had them coloured, and cut and assembled the paper instruments in his own workshop. The disc is tied at its centre and turns over the mater, the printed base. | The scan's own disc is cut along its own hand-cut edge, which is measured angle by angle (radius 1309 to 1319 px at 3840 px), so it turns with its real, slightly irregular outline. It turns about the centre printed on the disc, fitted to its rules to 0.4 px. |
| The disc carries the dragon, two tabs at its rim (CAPVT, the ascending node, and CAVDA, the descending node), rings of year marks, and the arched latitude scales. The reader set CAPVT against the node's longitude on the mater's zodiac, from the tables, and read the moon's latitude off the arcs. | The two tabs are part of the disc, and so are the small shadows they cast on the mater. Under them, the mater's zodiac ring is restored from the same printed sign 60 or 120 degrees round (the white signs repeat their numerals and checker), registered on the ring either side, with its seams on printed cell rules. Nothing is drawn. |
| The moon's nodes regress: they go backwards through the signs, one full turn in about 18.6 years. | The disc turns clockwise on the page, which is backwards through the signs (they run counter-clockwise on this mater). A value turns it through that share of one full turn, and at 100% CAPVT is back on Scorpio, where it was printed. With no value it goes round once every 40 seconds. |
| You turned it by hand. | You still can. A drag on the disc or a tab turns it about the pin. Let go and a critically damped spring takes it back to the value (or friction brings it back to its slow turn). The work never turns it faster than 100 degrees a second, and a hand can turn it at any speed. |

Simplified, and why:

- The real volvelle has a thread from the centre for reading across the scales. This copy's thread is gone, so it is
  not here either.
- The disc is a flat sheet. The real paper sits a fraction of a millimetre above the mater. Only the tabs' small
  cast shadows show that, and they turn with the tabs.

## How it was cut (offline, `tools/`)

Python, `./tools/run.sh <stage>.py`. The source goes in `tools/engine/jobs/dragon-volvelle-src/` (see `credits.json`).

1. `geometry.py`: the printed centre (circles fitted to the disc's own rules), the paper edge per quarter degree,
   the zodiac's inner rule and the rough tab sectors.
2. `cut.py`: the disc's alpha, with the edge carried across the tabs. The tabs are found by their yellow paper, and
   their convex hulls are drawn antialiased. Under each tab, the ring inside the checker's outer rule comes from the
   same sign a third or a sixth of the way round, in polar coordinates about the mater, registered per side
   (angle and radius, about 0.15 rms). Its tone comes from the bare paper either side, and its sector's edges are
   snapped to printed cell rules. The gap between the disc and the ring comes from the same gap a sector along, at
   the same radius. In the blank strip before the sign names, the tab's soft shadow is divided out. The shadow layer
   is how much darker the scan is than the restored mater, so it travels with its tab. The disc's colour is solved so
   that `base·(1−a) + F·a = scan`.
3. `export.py`: the instrument is cut off its page by Lab distance from the paper's own colour (filled, opened,
   1 px feather), at 1600 px wide. `ring.webp` is the restored mater in the annulus the turning disc can uncover.
   `disc.webp` is the disc, its tabs and their shadows, as a square about the pin. `volvelle.json` holds the
   geometry.

## Runtime

Canvas 2D, about 300 lines, no libraries. At its size the canvas caches a base once (the plate, with the restored
ring over it) and the disc resampled once to device pixels, so each frame is one blit plus one rotated blit. The loop
runs only while the disc moves, or while it goes round indeterminately and is on screen in a visible tab. At rest the
canvas is hidden and the `<img>` shows. Fixed 240 Hz substeps keep the spring stable at any frame rate.

`v.hold(true)` stops the loop and `v.advance(seconds)` steps it exactly (for screenshots).

## Options

| Option | Attribute | Default | |
|---|---|---|---|
| `turn` | `data-turn` | `40` | Seconds per turn while indeterminate. |
| `speed` | `data-speed` | `100` | The most degrees a second the work turns it (a hand can turn it faster). |
| `touch` | `data-touch` | `true` | `false`: look-only. |
| `src` | `data-src` | `volvelle.json` beside the image | Geometry; `ring.webp` and `disc.webp` sit beside it. |
| `doneText` | `data-done-text` | `Done.` | What the live region says at 100%. |
| | `data-busy` on `.dv-readout` | | Words shown while indeterminate (e.g. `working…`). |

Layouts: `.dv-wide` puts plate and words side by side from 860 px. `.dv-small` makes the plate a thumbnail beside a
line. Without either, they stack.

## Theming

Uses `--ink`, `--ink-2`, `--ink-3`, `--accent` (the readout at 100%), `--serif`, `--sans`.

| Variable | Default | |
|---|---|---|
| `--dv-plate` | `min(100%, 520px)` | The plate's width. |
| `--dv-size` | `clamp(44px, 12cqi, 88px)` | The readout. |
| `--dv-gap` | `clamp(18px, 5cqi, 48px)` | Between plate and words. |

## Accessibility

The `<progress>` is labelled by its `<label>` and carries the exact value. It is visually hidden but stays in the
accessibility tree. The root has `aria-busy="true"` until 100%. A polite live region speaks each quarter and the done
text. The readout is `aria-hidden` (it duplicates the bar). When the plate can be handled it is focusable: the arrow
keys turn the disc and the work brings it back. The canvas is `aria-hidden`. In forced colours the canvas is hidden
and the plate stays.

**Reduced motion:** nothing moves by itself. A value puts the disc straight where it belongs, with no sweep, so the
proportion still shows. Indeterminate, it rests as the plate. Your own hand still turns it, and it goes straight back.

## Cost

Assets about 1.6 MB: the plate 743 KB (it is also the page's image), the disc 691 KB, the ring 198 KB, and the JSON
under 1 KB. Idle at a value: nothing runs. Moving: one base blit and one rotated sprite a frame, DPR capped at 2.

## Credits

*Astronomicum Caesareum*, Petrus Apianus, Ingolstadt 1540, the first dragon volvelle. The copy in the National
Library of Poland (Polona), public domain, via Wikimedia Commons. The pick, with its shortlist and contact sheets,
is in `assets/PICK.md`. Reference: Lars Gislén, *A commentary on the volvelles in Petrus Apianus' Astronomicum
Caesareum* (2018). See `assets/credits.json`.

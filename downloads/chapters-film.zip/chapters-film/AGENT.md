# chapters: notes for the coding agent

One longer film beside a chapter list. Click a chapter to jump to it; the current chapter darkens and
fills as it plays. Captions show on the film, and a transcript under it follows along and jumps the film
when a line is clicked. The film is a **code tour**: the product's real screens in a window, a scripted
cursor working through them, on the engine's play bar. Its `chapter()` and `caption()` steps are the
chapter times, the captions and the transcript, so the words and timing are written once.

## Files

```
index.html     the page; the film is <div class="screen" data-film="long">, one <li> per chapter in #chapters
style.css      the page's look; tokens on :root
script.js      ~45 lines: chapter jumps and times, the transcript from the tour's captions, following along
film/          film.js (mounts a tour in a slot), film.css, tours.js (the tours), screens/ (the product)
tour/          the tour engine and its docs: README.md (vocabulary), AGENT.md (how to make a tour)
```

(In the StyleFeatures repo, `python3 templates/formats/film/export.py chapters <dest>` writes this folder.)

## The film: harvest the screens, then write the tour

Read `tour/AGENT.md` and follow its steps 1–4. In short:

1. **Learn the product** and plan the film: 3–7 chapters, each one idea, 1–2 minutes in all.
2. **Put the real screens in `film/screens/`**: harvested fragments (`tour/snapshot.py`) for a web app, a
   static rebuild for a native one. Keep the `data-tour="…"` hooks. Delete the placeholder product.
3. **Write the `long` tour in `film/tours.js`** (delete the tours this page doesn't use):
   - one `chapter()` per `<li>`, in the same order; the list's times fill themselves in;
   - a `caption()` for every beat, written as the narration: one sentence, under about 80 characters,
     in the product's voice. Leave each on screen long enough to read (`pause()` after it if needed);
     the transcript groups them by chapter.
   - `intro: 0`, a `still` for reduced motion.
4. **Check**: play it through at 1440 and 390 px; click chapters and transcript lines; `?t=40` freezes a
   moment; `?record` plays it alone on a clean stage with the chapter card.

## The words

From the project's README:

- `.mark`, `<title>`, `og:title`: the product name.
- `.intro .eyebrow`: "A film", its length (filled in from the tour), "with captions". `h1`: what the film shows.
- Each chapter: `<b>` a two- or three-word title, `<span>` one short line.
- `.end h2` and its buttons: the invitation and the main action.

## Don't

- Don't add a player or captions library; the engine's play bar does play, scrub, Space and arrows.
- Don't paste the transcript into the HTML. It comes from the tour's captions, so it can't drift.
- Don't autoplay.

## Optional: use Monet Shot recordings instead

Record the walkthrough with Monet Shot, with voice, and put it in `media/`. On the `.screen` add
`data-src="media/film.mp4" data-vtt="media/film.vtt" data-sound`, and give each `<li>` a
`data-at="seconds"`. Write `film.vtt` one cue per sentence (`WEBVTT`, then `00:00:01.000 --> 00:00:05.000`
and the line); the transcript is built from it the same way. Under 40 MB.

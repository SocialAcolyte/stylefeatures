# badbezan

A range input that is a Persian brisé fan: the *Fan with Poetic Verses*, Tehran, dated 1301 AH (1883–84), wood,
painted, gilded and lacquered (the Met, 90.2.65). *Bādbezan* is Persian for a hand fan.

The fan is the slider's picture. Closed is the minimum, fully open the maximum, and every value between opens it that
far. Take the top guard, or anywhere on the fan, and turn it round the pin; use the keys; or set the value: the
fan follows. Its twenty sticks are each their own photographed face, cut from one Met photograph, turning about the
brass pin in their real stacking order. A quick opening deals them out from the top, the way the ribbon pulls them.
Fully open and at rest, what you see is the `<img>`: the photograph itself.

The control is a real `<input type="range">`, with its `<label>` and an `<output>`.

```html
<link rel="stylesheet" href="badbezan.css">
<div class="bz" data-badbezan data-format="{value}%">
  <div class="bz-fan"><img class="bz-img" src="assets/fan.webp" width="1690" height="913" alt="…"></div>
  <div class="bz-face"><label class="bz-label" for="size">Text size</label><output class="bz-out" for="size">100%</output></div>
  <input class="bz-input" id="size" type="range" min="80" max="150" step="5" value="100">
</div>
<!-- compact, in a row (about 44 px tall): add .bz-compact -->
<div class="bz bz-compact" data-badbezan>…same parts, id="vol" min="0" max="100"…</div>
<script type="module" src="badbezan.js"></script>
```

Read it as you would any range: `input.value`, and the `input` and `change` events (dragging the fan fires them too).
To set it from code, set `input.value` and dispatch an `input` event, or use the API:

```js
import { badbezan } from './badbezan.js';
const f = badbezan(root);
f.value = 120;          // sets the input (and fires `input`); the fan opens to it
f.open;                 // how open the fan is now, 0..1 (moving, not the value)
root.addEventListener('badbezan:change', (e) => e.detail);   // { value, open }  open = the value's share, 0..1
f.hold(true); f.advance(.1); f.settle();                     // for stills: stop the loop, step it exactly, or land
f();                    // destroy: removes the canvas and listeners; leaves the plain markup
```

Without JS it is the photograph of the open fan over a native slider with its label and output.

## In life, and here

| In life | Here |
|---|---|
| A brisé fan has no leaf: its sticks are rigid, pinned at the base and tied by a ribbon. This one has twenty slips of wood, two guards and eighteen sticks, each painted in Tehran with its own cartouches of verse in a border of flowers, gilded and lacquered. | Each stick is cut from one Met photograph of the fan fully open, along its own gilt rim. The eighteen inner sticks were cut to one pattern, so their leading edges were fitted as one curve turned to each stick's angle (sticks 7.3° to 10.2° apart), then each refined on its own. Nothing is drawn: every stick is the photograph's own pixels, turned rigidly. |
| The sticks stack in one order: the bottom guard lowest, each stick lying on the one before it, the top guard over all. Closing slides each stick back over the one below. | They are drawn in that order, each showing what the photograph shows of it. Closing only ever hides more of each stick, so no pixel that wasn't photographed is needed. The Met's older photograph of the same fan half closed confirms the order. |
| All twenty turn on one brass pin through a mother-of-pearl washer. | The pin is a circle fitted to its own edge (r 12.45 px at 3907 px, 0.17 px residual), and every stick turns about it. The washer is its own piece on top and does not turn. |
| You hold the bottom guard and push the top one round with a thumb. The red silk ribbon, threaded through two slots in every stick, pulls each open after the one above it, and stops them spreading further than it allows. | The bottom guard stays put; the top guard is the slider's thumb (163° from closed to open). Each inner stick springs toward its share of the opening, the top ones a little quicker, and the ribbon is a hard limit: no stick lies further from the one below than it does fully open, and none passes the one below. So a quick flick deals them out from the top, a slow push opens them together, and nothing bounces past fully open. |
| The ribbon shows between the slots, on the face of each stick. | Those lengths of ribbon are part of the stick they lie on and move with it, hidden by the sticks above as the fan closes. Never redrawn. |

Simplified, and why:

- In life the ribbon slackens and bunches as the fan closes. Here each visible length stays flat on its stick; where
  it would bunch, it is under the stick above.
- Each stick's own shadow on the one below is in the photograph, so it stays with the stick below. As the fan closes
  the stick above slides over it, so it is never in the wrong place, but the moving edge carries no new shadow.
- The inner sticks run a few pixels longer and wider than the top guard in places, so closed, slivers of their gilt
  edges show past it. That is this fan's own geometry.
- The sticks are flat. Their thickness shows only as the stack of real gilt edges you see as the fan closes.

## How it was cut (offline, `tools/`)

Python, `./tools/run.sh <stage>.py`, or `./tools/run-all.sh` for the lot (about ten minutes). The source goes in
`tools/engine/jobs/fan-src/443577-0.jpg` (see `assets/credits.json`); work files go to `tools/engine/jobs/fan-work/`.

1. `rivet.py`: the pin and washer, circles fitted to their radial edges. Also a polar unwrap of the fan about the
   pin, to look at.
2. `geometry.py`: the outline. The Met's ground is exactly neutral (R = G = B) and lacquer never is, so the fan is
   what is saturated, holes filled.
3. `rimscore.py`: in polar coordinates about the pin, a matched filter for a stick's leading edge: going clockwise,
   a thin dark line (the gap, and the shadow on the stick below), then about 8 px of plain gilt rim. Its widths are
   in pixels, so it is the same filter at every radius.
4. `edges.py`: one curve for the inner sticks' shared pattern, by dynamic programming over radius on the summed rim
   score of the eleven clearest sticks; each stick's angle fitted to it; then each stick refined alone within 0.6°
   and smoothed (hand-cut wood is not exact). The top guard has its own outline and is traced alone. Near the pin,
   where an edge sweeps through many degrees per pixel, each edge goes on along the straight line its neck runs on.
   Past a stick's tip the edge holds its angle, so the rounded cap above belongs to the stick.
5. `cut.py`: a label for every pixel (which stick it shows), any island joined to the stick it borders most, an
   antialiased leading edge per stick, and the outline's alpha solved from saturation against the neutral ground.
6. `export.py`: at half size, `fan.webp` (the photograph cut off its ground: the page's `<img>`), `sticks.webp`
   (an atlas of the twenty faces as they lie in the photograph, each running 4 px on under the stick above, plus the
   rivet) and `fan.json` (pin, each stick's place and angle). The colour at the outline is the nearest solid pixel's.
7. `box.py`: the box the fan sweeps while it closes (14 px past the photograph on the left).
8. `preview.py`: renders the fan from the assets at any opening, the way the runtime does. Fully open it matches
   `fan.webp` to within webp noise (mean 4/255). `look_polar.py` draws the traced edges on the unwrap.

The pipeline lifts `common.py` (polar sampling, circle fitting) and the stage layout from `components/dragon-volvelle/tools`.

## Runtime

Canvas 2D, about 330 lines, no libraries. At its size the canvas resamples each stick once to device pixels (by
halves for big reductions), each at the sub-pixel offset that puts it exactly where the photograph has it, so a frame
is twenty rotated blits and the rivet. The loop runs only while something moves and the fan is on screen; fixed
240 Hz substeps. The guard follows a value on a critically damped spring (13 rad/s, `data-open`) and a hand at
38 rad/s; the inner sticks settle at 7 to 15 rad/s.

## Options

| Option | Attribute | Default | |
|---|---|---|---|
| `format` | `data-format` | `{value}` | What the `<output>` says. `{value}` is the input's value. |
| `open` | `data-open` | `13` | How briskly the guard follows a new value (rad/s). |
| `src` | `data-src` | `fan.json` beside the image | Geometry; `sticks.webp` sits beside it. |

`min`, `max`, `step` and `value` are the input's own.

Layouts: by default the fan sits above its label and output, centred. `.bz-compact` puts a small fan
(`--bz-height`, 44 px) and its words in a row.

## Theming

Uses `--ink`, `--ink-3`, `--accent` (the focus ring), `--serif`, `--sans`.

| Variable | Default | |
|---|---|---|
| `--bz-width` | `min(100%, 640px)` | The fan's width (its box is 1704 × 913). |
| `--bz-height` | `44px` | `.bz-compact` only: the fan's height. |
| `--bz-size` | `26px` | The output's size. |
| `--bz-gap` | `14px` | Between the fan and its words. |
| `--bz-shadow` | two soft drop-shadows | The fan's shadow on the page (a CSS filter on the image and canvas). |

## Accessibility

The `<input type="range">` stays in the accessibility tree with its label, value and keys (arrows, Page Up/Down,
Home, End); once the script is ready it is visually hidden and the fan is its picture, with the focus ring drawn
round the fan. A pointer on the fan focuses the input, so the keys work after a drag (no focus ring for pointer use).
The `<output>` is the visible value. The canvas is `aria-hidden`; the decorative images in the demo have `alt=""`.
In forced colours the canvas is hidden and the photograph stays.

On touch the fan lets vertical swipes scroll the page (`touch-action: pan-y`): a finger sets the value once it
moves sideways or lifts as a tap, and a touch that turns into a scroll puts the value back.

**Reduced motion:** nothing moves by itself. A new value puts every stick straight where it comes to rest. A hand
on the guard still turns it, and the sticks keep their places beneath it.

## Cost

Assets about 1.4 MB: `fan.webp` 626 KB (it is also the page's image), `sticks.webp` 764 KB, `fan.json` 2 KB. Every
fan on a page shares them. Idle: nothing runs. Moving: twenty rotated sprites a frame, DPR capped at 2.

## Credits

*Fan with Poetic Verses*, Iran, Tehran, dated 1301 AH / 1883–84 CE. The Metropolitan Museum of Art, 90.2.65, The
Moses Lazarus Collection, Gift of Josephine and Sarah Lazarus, in memory of their father, 1888–95. Open Access, CC0.
The pick, with its shortlist and contact sheets, is in `assets/PICK.md`. In the demo: Hafiz, ghazal VIII, in
Gertrude Lowthian Bell's translation (*Poems from the Divan of Hafiz*, 1897, public domain, Project Gutenberg 74883);
a Common Nightingale recorded by Marie-Lan Taÿ Pamart (xeno-canto XC473316, CC BY-SA 4.0, via Wikimedia Commons).
See `assets/credits.json`.

# volvelle-button

A button with Peter Apian's paper volvelle in it. Press it and a thumb takes the disc by its tab: the printed disc with the dragon turns a few degrees on its ring of the zodiac. While the work is done it turns on, slowly. When the work is finished the button says so at once, and the disc comes to rest on the next sign.

This is the button part of `dragon-volvelle` and nothing else: the inline loader inside a real `<button>`, at three sizes. There is no plate, essay, readout or drag-to-turn. The roundel is the paper disc and the ring of the mater it turns on, cut round from the plate's own pixels. The turning is drawn by the original engine, `dragon-volvelle.js`, which is unchanged. `volvelle-button.js` gives it a button (states, words, aria, a polite status line, the press) and a calm pace.

## Markup

```html
<link rel="stylesheet" href="dragon-volvelle.css">
<link rel="stylesheet" href="volvelle-button.css">

<button type="button" class="vb" data-volvelle-button>
  <img class="vb-face" src="assets/face.webp" width="384" height="384" alt="">
  <span class="vb-label"><span class="vb-say vb-on">Upload scans</span><span class="vb-say" data-say="working"
    aria-hidden="true">Uploading</span><span class="vb-say" data-say="done" aria-hidden="true">Uploaded</span></span>
</button>

<script type="module" src="volvelle-button.js"></script>
```

That is the full form, and the one the demo uses. Without JS it is already the finished pill: the roundel at home, the
resting word, and the pill as wide as its widest word, so nothing moves when the script starts (measured in the demo:
0.00 px for every button). The short form works too, and the script builds the rest:

```html
<button type="button" class="vb" data-volvelle-button data-working="Uploading" data-done="Uploaded">Upload scans</button>
<button type="button" class="vb vb-sm" data-volvelle-button>Sync now</button>           <!-- a 48 px row button -->
<button type="button" class="vb vb-lg" data-volvelle-button>Make 24 proofs</button>     <!-- 76 px -->
<button type="submit" class="vb vb-solid" data-volvelle-button>Rebuild index</button>   <!-- the primary, in ink -->
```

`volvelle.json`, `ring.webp` and `disc.webp` must sit beside `face.webp`.

## Driving it

A press starts it. The button goes busy and says its working word, and the disc turns on. Your code does the work
and reports it:

```js
const btn = document.getElementById('upload');
btn.addEventListener('volvelle-button:start', async () => {
  const vb = btn.volvelleButton;
  try {
    for await (const share of upload()) vb.progress(share);   // 0..1 of the job: the disc follows it
    vb.done();                // the button says "Uploaded" now; the disc settles on the next sign
  } catch {
    vb.reset({ say: 'Could not upload' });                    // back to rest now; the disc stops where it is
  }
});
```

```js
import { volvelleButton } from './volvelle-button.js';
const vb = volvelleButton(btn, { working: 'Sending', done: 'Sent', reset: 2600 });
vb.start();          // busy, no value yet (a press does this for you). false if it is busy, disabled or aria-disabled
vb.progress(0.4);    // forwards only; 0 keeps it waiting
vb.done();           // or done({ stay: true }) to keep the done word, done({ say: '3 more scans' }) to announce that
vb.reset();          // back to rest now (gives up a job: stop calling progress). reset({ say }) says why
vb.state;            // 'idle' | 'waiting' | 'working' | 'done'
vb.loader;           // the dragon-volvelle handle underneath
vb.destroy();        // removes everything it added; the button is its own markup again
```

After `destroy()` the handle does nothing: a late `progress()`, `done()` or `reset()` from a job that outlived
the button is ignored, and a second `destroy()` is a no-op, even after the button has been set up again.

### Options (data attributes or the options object, which wins)

| | default | |
|---|---|---|
| `data-working` | the word | the word while busy ("Uploading"), when the label is not written in the markup |
| `data-done` | the word | the word once the work is done ("Uploaded"), likewise |
| `data-reset` | `2600` | ms showing the done word before the button comes back to rest; `0` stays done until `reset()` |
| `data-auto` | `true` | `false`: a press does not start it, so call `start()` yourself (after validating a form, say) |
| `data-status` | none | the id of an element to speak through instead of the status line the script adds after the button. Give it `role="status"` (the script adds it if there is neither a role nor `aria-live`, and takes it off in `destroy()`). Use it when the button may be removed, so its last word is said from an element that stays |
| `data-turn` | `24` | seconds a turn while it waits with no value yet: 15° a second |
| `data-speed` | `36` | the most degrees a second the work ever turns it. Lower is calmer; do not raise it for quick actions, which no longer wait on the disc at all |
| `data-face` | `assets/face.webp` beside the script | the roundel image; its geometry and the disc and ring are read from beside it |

### Sizes

Size is the class. The roundel sits concentric with the pill's round end.

| class | button | roundel | where |
|---|---|---|---|
| `.vb-sm` | 48 px | 40 px | settings rows, toolbars, a list's Load more |
| none | 56 px | 48 px | a form footer, an upload field |
| `.vb-lg` | 76 px | 64 px | a share sheet or an empty state |

**The floor is a 40 px roundel in a 48 px button.** Below 40 px the dragon is a pink and green smudge on yellow
(see "Can you read it", below), so the CSS never draws the roundel smaller, whatever `--vb-disc` says, and the
button is never shorter than the roundel and its margin. For a 32 to 40 px toolbar this is not the right button:
use a plain one there.

`.vb-solid` is the primary in ink. `.vb-block` makes it fill its row. A larger size: set `--vb-h` (the button),
`--vb-disc` (the roundel) and `--vb-pr` (the padding after the word) on the button. The words for every state are
stacked in one cell as wide as the widest, so the pill is the same size in every state and nothing beside it reflows.
Each word starts the same distance from the roundel, so the two read as one thing, and a shorter word's spare room is
end padding: where there is room, **make the resting word the longest** ("Sync now", "Upload scans", "Rebuild index",
"Make 24 proofs") and the pill hugs it at rest. Theme with `--paper`, `--ink`, `--ink-2`, `--ink-3`, `--rule` and
`--sans`; `--vb-paper` is the button's face (the demo's cards set it to their sheet colour).

The parts the script adds are guarded: their geometry is `!important`, so a page's own rules (`.row span
{ display: block }`, `img { height: auto }`, `.bar span { width: 100% }`) cannot stretch the roundel, squash it, or
unstack the words. Tested with all of those on the demo: every roundel stays round at its size.

### Events (all bubble)

| | when |
|---|---|
| `volvelle-button:start` | pressed (or `start()`): your cue to begin the work |
| `volvelle-button:state` | every change, `detail: { state, from }`: idle, waiting, working, done, idle |
| `volvelle-button:done` | at `done()`: the done word is showing and has been said. The disc may still be settling |

### States

| | the button | the disc |
|---|---|---|
| idle | its word | where the last job left it, on a sign (on first load: home, as printed, which is the `<img>`) |
| pressed | the outline face sinks a pixel and darkens a touch; the ink face lifts a clear step toward the paper instead, since near-black cannot darken much. The main mouse button, a held Space, or a touch (after 90 ms, in case it is a scroll; a quick tap shows it a moment). Slid off the button, it lets go (releasing there does nothing); slid back on, it presses again | a mouse or a held Space: a thumb takes CAPVT's tab as it goes down, and the disc turns 5° in about 0.15 s and is held there. Once per press: sliding off and on does not take it further. Let go off the button, it stays where the hand left it, as paper does. A finger takes the tab as the press lands (its click, as it lifts): until then a touch can still turn into a scroll, and the disc only turns forwards, so it could not give the turn back. A scroll that starts on the button, however long the thumb rests first, leaves the disc exactly where it was |
| waiting | the working word, `aria-disabled` | turns on at 15° a second, easing in |
| working | the working word | follows the work's share of its turn about 0.8 s behind it, never faster than 36° a second, never ahead of the work. At 100% it would be home |
| done | the done word, at once | carried on to the next sign it can stop on calmly, and rests there. Long work, that the disc could keep up with, ends at home. After `data-reset` ms the button is back at rest |
| given up (`reset()` while busy) | at rest at once | brakes to a stop where it is, in about half a second |
| disabled | grey words, `disabled` (or the page's own `aria-disabled="true"` at rest) | still, pale |

## How it turns

- **The word follows the work, never the disc.** `done()` shows the done word, says it, fires `volvelle-button:done`
  and starts the `data-reset` timer at once, in the same call: no animation frame, no timer, so a hidden tab or a
  stalled frame cannot hold it back. Traced at 1440 @2 (`tools/engine/jobs/volvelle-button-fix1-last/trace.py`): a
  150 ms Sync, a 2 s job reporting every 100 ms, 3 s with no progress at all, a jump to 90%, and a 13 s job all
  changed the word 0 to 0.3 ms after their work ended, and showed it in the next frame.
- **A sign at a time.** The zodiac round the disc is twelve signs of 30°, and the moon's node goes back through them.
  When the work is done the disc does not lap home: it is carried on to the next sign it can stop on calmly, and rests
  there. Quick work sets it one sign on (the 150 ms Sync: 25° of settling, over 1.7 s, after the word); a 2 s job
  three; long work, that the disc could follow, brings it home (the 13 s job: home, the `<img>` again, 1.5 s after
  the word). It never makes a turn on its own.
- **Calm.** The work's progress comes in steps; the disc does not. The button plans the disc's pace and only ever
  changes it gently (by at most 40° a second in a second speeding up, and 50 slowing down); the disc follows the plan
  on a stiff, critically damped spring, never past it, only forwards. Traced through those five jobs and a give-up:
  the turn was at most 36.5° a second (13 px a second at the rim of the row button), never more than 0.85° in a
  frame, and never backwards. A stalled frame pauses it rather than making it catch up (at most 1/30 s of turn is
  taken up in one frame). The press's own 5° nudge peaks at 51° a second for a tenth of a second: that is the hand,
  not the work.
- **The press answers at once.** The first device pixel of movement at the rim came 41 to 62 ms after a mouse press
  (`tools/engine/jobs/volvelle-button-fix1-last/trace.py`, 1440 @2); Enter (which clicks on the key going down) takes
  the tab with the start, and moved it 2.9° within 60 ms (`keys.py`). A finger: the face sinks 90 ms after the touch,
  and the disc takes its 5° as the press lands, its first movement about 30 ms after the lift (`touch.py`, 390 @3).
  Scrolls that start on the button, quick or after a rest of 150 or 400 ms, and a sideways slide: 0° every time, and
  the face back up as the scroll begins (`touch.py`, `swipes.py`: four rested scrolls on Sync, 0° each).
- **Given up** (`reset()` while busy): the button is at rest at once, and the disc stops where it is: about 9° of
  travel, over 0.8 s, in the trace. It does not go on to a sign, since the work did not finish.
- **Off screen** nothing runs: no animation frame and no drawing, while it waits, works, settles or stops. The button
  works out where the disc would have got to when it matters: before the plan changes, and as the roundel comes back
  within a quarter of a screen of view, so the first frame it is seen in is already in place. A jump straight back
  into view (Tab to the button, a link, `scrollIntoView`) is painted before an observer can say so, so while a disc
  out of sight has turning to catch up the button keeps one passive scroll listener, and puts the disc in place before
  that first frame. Measured in the first animation frame after the jump (`jump.py`, 390 @3): a job ended unseen
  showed its sign at once (60°, where the old frame had 9.7°), Tab to Sync likewise (30°), and under reduced motion
  home. A job that ends unseen is on its sign when it is seen again. The same in a hidden tab.

The engine does the drawing: each frame the button gives it the disc's angle (as the share of its turn, which the
engine reads as forwards only) and steps the engine's own spring until the disc is there. The engine's own loop is
held off, so the disc is drawn once a frame, and not at all at rest.

## Can you read it at button size?

Tested by shooting the roundel at 24 to 96 px at dpr 2 and 3 and looking at it pixel for pixel
(`tools/engine/jobs/volvelle-button-shots/legib/`):

| | dpr 2 | dpr 3 |
|---|---|---|
| the dragon reads as a winged dragon | from 40 px (36 px is a winged blur, 32 px a pink and green blot) | from 32 px (28 px just) |
| CAPVT and CAVDA read as two tabs (yellow pointers on the rim) | from 64 px | from 44 px |
| their lettering | not at any button size (about 150 px and up) | not at any button size |

So the row button uses 40 px, the smallest roundel in which the dragon reads at dpr 2. At dpr 1 a 40 px roundel is a
yellow coin with a pink blot whatever the cut.

**A tighter cut was tried** (`tools/engine/jobs/volvelle-button-fix1-shots/crop/`): cut just outside the tabs'
tips (r 748 on the 1600 px plate, against the zodiac's outer rule at r 781.5), from the same pixels. It makes the
dragon 4.5% larger, which does not change the blot at 1x, and it takes away most of the printed zodiac, the fixed
ring the turning disc is read against: at row size that ring is 2.1 px wide in the current cut and 1.3 px in the
tight one, so the turn reads even more like a coin going round. The current cut stays.

Resting a sign on, the disc is the engine's canvas, not the `<img>`. Measured inside the disc
(`tools/engine/jobs/volvelle-button-fix1-last/sharpk.py`): at 2x the same detail as the `<img>` (+10% and -4% by a
Laplacian measure, for the 40 and 64 px roundels), at 3x a little less (-7% and -17%). Its lettering still reads
where the `<img>`'s does. At 3x, drawing the canvas at the screen's own pixels (one resample, the turn, and no 2:1
step down) was tried: clearly softer (-35% and -39%, the dragon visibly blurred), so the canvas stays at twice the
screen's pixels (`tools/engine/jobs/volvelle-button-fix1-last-shots/sharpk/`). Drawing it at more than twice is
crisper by the measure but grainier to the eye (it skips pixels on the way down), and is not used.

## Accessibility

- A real `<button>`. Its name is the visible word, which changes with the state (Upload scans, Uploading, Uploaded).
  Only the word on show is in the name: the others are `aria-hidden`, and hidden once faded. The old word fades out in
  0.08 s, fast first, and the new one in over 0.2 s from 0.06 s, so the two never read as one garbled word.
- The roundel is `aria-hidden` (a button's children are presentational anyway). A polite `role="status"` after the
  button says the start, then a step of ten at most every three seconds, then the end, or the word given to
  `done({ say })` or `reset({ say })`. The engine's own live region is taken out of the button (nothing would read it
  there, and a `<p>` may not sit in a button).
- While busy it stays focusable and is `aria-disabled="true"`. A second press, Space or Enter does nothing, so a
  form is never sent twice (the demo's Rebuild index, a submit button, pressed by Enter and then Enter, Space and a
  click while it runs: one submit). Focus is never moved.
- The page's own `aria-disabled="true"` (the focusable disabled pattern) is the page's at rest: the script never
  writes it then, so the page can set and clear it whenever it likes. While it is "true", a press does nothing (no
  start, no form submit, no pressed look and no turn), `start()` returns false, and the button looks disabled (grey
  words, a pale roundel). The page's own click listeners still hear the press, with `defaultPrevented`, so the page
  can say why: the demo's Export PDF, pressed before any scan is chosen, says "Choose scans first". From a press to
  the rest after done, `aria-disabled` is the script's ("true"); whatever the page writes meanwhile is kept, and is
  what the button goes back to at rest, and at `destroy()`. A press that starts the button writes its "true" only
  once the click has been dispatched, so a page listener asking "is it aria-disabled?" hears the page's answer, not
  the script's. Tested with the page enabling the button after load, disabling it during a job, writing "false",
  writing in the same task as `reset()`, and `destroy()` busy and at rest (`aria.py`, `author.py`).
- Visible focus: a 2px ring, 3px off the pill. Hover styles only apply where there is a real hover, and only when a
  press would do something.
- `disabled` (or a disabled `<fieldset>`) works as on any button: no press, no focus, grey words and a pale roundel,
  and `start()` returns false.
- **Reduced motion:** nothing moves by itself. A press does not turn the disc (the face still changes colour, and
  does not sink). Waiting, the disc stays where it is; each step of the work sets it a sign further at once, never
  swept; done and given up put it home at once. The words change at once.
- No JS: the finished pill with its resting word and the roundel at home (with the label written in the markup, as
  above).
- Forced colours: the engine's canvas is hidden and the roundel shows as printed. The pill is drawn in the system's
  colours: ButtonText, and GrayText for its border and words when it is disabled or the page's `aria-disabled`.

## In life, and here

| In life | Here |
|---|---|
| Apian printed the plates from woodblocks, had them coloured, and cut and assembled the paper instruments in his own workshop. On the dragon volvelle one paper disc, tied at its centre, turns over the mater, the printed base with the zodiac. | The roundel is the plate's own pixels inside the outer rule of the printed zodiac: the disc and the ring of the mater it turns on, nothing else of the page. The disc turns as one rigid piece about the centre printed on it, over the mater restored where the disc's tabs had hidden it. |
| The reader took the disc by its two tabs, CAPVT and CAVDA, and turned it to set the dragon's head against the node's place in the zodiac. The nodes go backwards through the signs, one turn in about 18.6 years. | A press is the thumb on CAPVT's tab: the disc turns a little and is held. The work then turns it clockwise on the page, backwards through the signs, and only ever forwards, slowly. Done, it is set on the next sign, as a reader would leave it; a job long enough to follow brings CAPVT home to Scorpio, where it was printed. |
| A paper disc stays wherever the hand leaves it. | So does this one: it rests on its sign until the next job, and a press let go off the button leaves it where the thumb did. |

## Files

- `dragon-volvelle.js`, `dragon-volvelle.css`: the engine and its stylesheet, byte for byte from
  `components/dragon-volvelle` (the plate layout rules in the CSS are unused here).
- `volvelle-button.js`: the button part (states, words, aria, the status line, the press, the pace, the API).
- `volvelle-button.css`: the button, its three sizes and floor, the ink primary, the pressed, busy, done and disabled
  states, and the guards on the roundel. It also sizes the engine's canvas: the engine draws at most 2x, so the
  script sets `--vb-k` and the plate is laid out `--vb-k` times larger and scaled back down, and the canvas is drawn
  at twice the screen's pixels on any screen. The engine itself is not changed.
- `assets/face.webp`, `ring.webp`, `disc.webp`, `volvelle.json`: the roundel, 384 px across, cut and scaled from
  the original's assets by `tools/face.py`. 127 KB together.
- `tools/face.py` (offline): `./tools/run.sh face.py [--r 781.5] [--n 384] [--out ../assets]`. It reads
  `dragon-volvelle`'s own cut (`plate.webp`, `ring.webp`, `disc.webp`, `volvelle.json`), by default from the sibling
  folder `../../dragon-volvelle/assets`. In a copied folder, point `--src` at a copy of those four files. The mater's
  printed centre it cuts about is the constant `MATER`, from dragon-volvelle's own cut stage. A recut at the default
  radius reproduces `face.webp` byte for byte.

## Cost

Idle, nothing runs: no animation frame at rest, after a job, or out of sight
(`tools/engine/jobs/volvelle-button-fix1-last/idle.py`, rAF and drawImage counted by caller at 390 @3: 0 and 0 at
rest, 0 and 0 for a job worked and finished scrolled away, and in a hidden tab). While the disc turns on screen: one
animation frame and one engine draw (its base and the turned disc) a frame, for that button only, and a few lines of
arithmetic. A disc out of sight with turning to catch up keeps one passive scroll listener (a rectangle read per
scroll event), gone as soon as it is seen; at rest and up to date there is none. The roundel and its two sprites
are 127 KB, fetched once for the whole page; each button reads the 0.8 KB geometry, from the cache after the first.

## Credits

*Astronomicum Caesareum*, Petrus Apianus, Ingolstadt 1540, the first dragon volvelle. The copy in the National
Library of Poland (Polona), public domain, via Wikimedia Commons. The roundel is cut from `dragon-volvelle`'s own
cut of that scan (see its `assets/PICK.md` and `tools/`). The demo sets its words in Inter and Cormorant
Garamond from Google Fonts (SIL Open Font License). See `assets/credits.json`.

# _chat: the chat kit

Shared by `demo/chat` (a chat-first product: the page is the conversation) and `demo/mcp` (an MCP server: a toured
text chat with an agent that uses it). Two files:

| file | what it is |
|---|---|
| `chat.css` | the look: rows and their arrival, person bubbles, agent text, typing dots, tool-call blocks, cards (choices, a chart, a file, fields, an image grid, quick replies, a before/after swap, the CTA card), the header and the composer. Tokens on `.ck-app`: `--ck-bg`, `--ck-card`, `--ck-me`, `--ck-line`, `--ck-accent`, `--ck-radius` |
| `chat.js` | `prepare(win)`, `conversation(win, thread, o)`, and page helpers `copyButtons`, `tabs`, `foldable` |

It is our own calm house design. Don't restyle it to look like any real product's chat; restyle it to look like
**yours** (your tokens, your card components).

## The thread is the script

```html
<div class="ck-thread" data-ck-thread data-tour-follow>
  <div class="ck-row" data-tour="hi">                                   <!-- an agent message (data-from="agent" is the default) -->
    <div class="ck-pad"><div class="ck-text" data-stream><p>Hi, I'm …</p></div></div>
  </div>
  <div class="ck-row" data-from="person" data-tour="ask">              <!-- typed into the composer, then sent -->
    <div class="ck-pad"><p class="ck-bubble">Find an hour next week</p></div>
  </div>
  <div class="ck-row" data-kind="tool" data-run="1.1">                  <!-- a tool call: running, then done -->
    <div class="ck-pad"><div class="ck-tool">
      <button class="ck-tool-head" type="button"><i class="ck-tool-state"></i>
        <span class="ck-tool-name"><b>server</b> · tool_name</span><span class="ck-tool-meta" data-done="3 found · 0.6 s">running</span></button>
      <div class="ck-tool-body"><pre class="ck-args">{ … }</pre><div class="ck-out"><p>…</p></div></div>
    </div></div>
  </div>
  <div class="ck-row" data-tour="slots">                                <!-- text, then a card whose parts settle in -->
    <div class="ck-pad"><div class="ck-text" data-stream><p>…</p></div><div class="ck-card" data-ck-in>…</div></div>
  </div>
</div>
```

`prepare(win)` (once, before `new Tour()`) names rows that have no `data-tour`, marks every row `data-tour-grow`
(the engine measures its height so it can arrive smoothly), splits `[data-stream]` text into words, copies the
`[data-ck-avatar]` beside each agent turn, and puts a typing-dots row before each agent turn.
`conversation(win, thread, o)` returns the steps, one beat per row, each starting with `mark(rowName)`:

| row | what plays |
|---|---|
| `data-from="person"` | the text is typed into the composer (`@ck-input`), Send is clicked (`@ck-send`), the bubble arrives |
| `data-from="person" data-via="@chip"` | a tap on that element (a quick reply, a button) sends it |
| `data-from="person" data-via="inline"` | the text is typed in place (`[data-said]`), with a caret (mcp) |
| agent, first of a turn | the typing dots for `data-think` s, then the row |
| `[data-stream]` text | arrives word by word |
| `data-kind="tool"` | spinner for `data-run` s, then done (`data-done` becomes the meta text). `data-open`: the arguments show and the result streams in line by line, then it folds after `data-hold` s (`data-fold="off"` keeps it open) |
| `[data-ck-in]` | a card's parts settle in one after another |
| `[data-ck-grow]` | bars and meters grow (`--g` 0 → 1) |

Every row takes `data-read` (seconds held after it; the default follows its length). Options on `conversation()`:
`chapters: { rowName: ['01 / 04', 'Title with one <em>word</em>', 'One line.'] }`, `before` / `after:
{ rowName: [steps] }` for taps inside a card or a push-in, `composer: { field, input, send }`, and `prefix` for marks.

A card with two states (pick a time, then "Booked") is `[data-ck-swap]` with two children; tween `--swap` 0 → 1 on
it after the tap, and the first state gives up its height as the second fades in.

Visitors can click a tool call's head to fold it open or shut (`foldable(win)`); `copyButtons(root)` makes any
`[data-ck-copy="#id"]` copy that element's text; `tabs(root)` runs `[data-ck-tabs]` tab lists.

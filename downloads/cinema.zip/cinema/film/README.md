# Film layouts

Same code tours, in different page shapes; drop in a recording if you have one.

Each layout is a whole page shaped around its film: a full-bleed loop, a run of feature clips, a scrubbed
walkthrough, phone stories, a chaptered long film, a trailer with a grid. None of them needs a video. Every
place that would hold a `<video>` plays a **code tour** instead, like monetshot.pages.dev: the product's
real screens in a window, a scripted cursor (or a fingertip, on a phone) clicking through them, the camera
pushing in, captions where the layout has captions. The tour engine is
`templates/scaffolds/sections/demo/tour/` (`tour.js`, its `README.md` and `AGENT.md`).

| layout | shape | its films | JS lines |
|---|---|---|---|
| `cinema/` | One full-bleed loop, the name, one line, one button. "Watch the full film" opens the whole tour, with chapters, captions and a play bar. | `highlights` (loop), `film` | 21 |
| `reel/` | Short feature tours down the page, one line beside each, each playing only while on screen, each with a pause button. | `create` `settings` `open` `search` `share` | 8 |
| `scrub/` | One tour pinned to the page; the scroll drives its clock, forwards and back, and a chapter timeline fills as you go. | `film` | 39 |
| `stories/` | 9:16 stories you tap, hold and swipe through. Each is a phone tour with fingertip taps; a story moves on when its tour ends. | `phone-open` `phone-create` `phone-detail` `phone-share` | 91 |
| `chapters/` | One long tour beside a chapter list that seeks it, with on-screen captions and a transcript, both built from the tour's caption steps. | `long` | 55 |
| `trailer/` | A looping hero, then a grid of mini tours that play on hover and open bigger, with captions, in a lightbox. | `highlights`, the six features | 60 |

## How a layout is built

```
_shared/film.js        mounts a tour (or a recording) into any slot and hands the page a small player
_shared/film.css       a tour filling its slot; imports the engine's tour.css and screens.css
_shared/tours.js       every tour the layouts play, one export per name
_shared/screens/       the placeholder product: app.html (desktop), phone.html, screens.css
<layout>/index.html    the page; each film is an element with data-film="<tour name>"
<layout>/script.js     mounts its slots and wires its own UI (pause, timeline, stories, lightbox)
<layout>/style.css     the page's look; tokens on :root
<layout>/AGENT.md      the brief for the coding agent
```

A slot is any element:

```html
<figure class="clip" data-film="create" data-autoplay data-loop data-fit=".86 .84"></figure>
```

| attribute | does |
|---|---|
| `data-film` | which tour (a key of `tours.js`) |
| `data-autoplay` | plays while half of it is on screen; never with reduced motion, and not after the visitor pauses it |
| `data-loop` | starts again at the end, through a short fade |
| `data-driver` | `manual` (default: the page drives it) or `play` (the engine's play bar, Space, arrows) |
| `data-captions` | `record` (default: only in `?record`) or `always` |
| `data-fit` | `"w h [y]"`: how much of a wide slot the window fills |
| `data-record` | the slot `?record` records |
| `data-src` | **a recording instead of a tour** (see below) |

`await film(slot)` returns a player with `play()`, `pause()`, `toggle()`, `seek(t)`, `rest()` (the
still frame), `t`, `duration`, `playing`, `chapters`, `captions` and `on('end', fn)`, the same for a
tour and for a recording, so a layout's code doesn't care which it got.

A phone tour (`chrome: 'phone'` in its script) gets a drawn glass and bezel (`.film-glass`; place it with
`--glass-y` and `--glass-h`) and the engine's fingertip (`pointer: 'touch'`).

## What every layout does

- Reduced motion: nothing starts by itself; each slot shows its tour's `still` frame, camera off, and the
  page's play buttons still play on request.
- No sideways scroll at 390 px; the play-bar films turn square on phones so window, caption and bar stack.
- `?record` renders one tour alone on the engine's record stage, for Monet Shot: the slot marked
  `data-record`, or `?record=<tour name>` for any other (`&ratio=16:9|1:1|9:16`, `&t=…` to check a frame).
- `?t=12` freezes every tour on the page at that moment.
- The house look: Newsreader and Inter Tight on warm paper (`#f5f3ef`), hairlines, few words.

## Making it yours

Follow the layout's `AGENT.md`. In short: harvest or rebuild the real screens into `screens/` (the
engine's `AGENT.md` and `snapshot.py`), point the hooks, rewrite `tours.js` for them, then the words.

To take a layout out of StyleFeatures into a product's repo:

```sh
python3 templates/formats/film/export.py cinema ~/their-product/site
```

It writes the layout, `film/` (this kit) and `tour/` (the engine and its docs), with the paths rewritten.

## Recordings (optional)

A team with Monet Shot recordings can use them slot by slot: `data-src="media/clip.mp4"` (plus
`data-poster`, `data-vtt` for a captions file, `data-sound` to leave it unmuted) and the slot shows a
`<video>` with the same player behind it. Where a layout reads chapter times from the tour (scrub,
chapters), a recording needs `data-at="seconds"` on each chapter instead. `tools/placeholder_video.py`
still makes sample MP4s for trying this.

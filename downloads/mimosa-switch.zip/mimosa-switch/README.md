# mimosa-switch

A switch that is one leaf of *Mimosa pudica*, the sensitive plant. On, the leaf
is open: the petiole raised, two pairs of pinnae spread like fingers, every
leaflet flat to the light. Switch it off and you have touched it. A signal runs
down the leaf from where your finger landed; the leaflets fold up in pairs as it
passes, the pinnae close together, and last of all the whole leaf drops at its
hinge. Switch it back on and it takes its time: the leaf lifts, the pinnae part,
the leaflets open one by one, not quite together. Toggle it too often and it
stops bothering, as the real plant does.

This is the exact switch the StyleFeatures site uses for its auto-scroll, file for file: `tools/curate/c/autodrift` runs it as `mimosaToggle(input, { size: 'compact', habituate: false, seed: 4 })`. The later version drawn from Henry Andrews' painted plate is `claude-2026-10-27 (set aside)/liked/mimosa-toggle`.

```html
<link rel="stylesheet" href="mimosa-toggle.css">
<label>Sync <input type="checkbox" role="switch" data-mimosa-toggle checked></label>

<!-- the large leaf on its plate -->
<input type="checkbox" role="switch" data-mimosa-toggle data-size="hero" aria-label="Leaf open" checked>

<!-- decoration only: a leaf you can brush (no input, aria-hidden) -->
<div data-mimosa-toggle data-size="hero" data-flower="false"></div>

<script type="module" src="mimosa-toggle.js"></script>
```

```js
import { mimosaToggle } from './mimosa-toggle.js';
const destroy = mimosaToggle(input, { size: 'compact', speed: 22, recover: 2400 });
input.addEventListener('change', () => { /* input.checked, as ever */ });
input.addEventListener('mimosa-toggle:fold', (e) => { /* e.detail.response 0..1, e.detail.strength 'full' | 'weak' | 'none' */ });
destroy.set(false);    // as if the person switched it (fires input and change, the leaf folds)
input.checked = true; destroy.sync();   // changed in code: the drawing jumps to match, no animation
destroy.response;      // amplitude of the last reflex, 1 = full
destroy.habituation;   // 0..1, decaying
destroy();             // remove everything, leave the plain checkbox
```

Without JS it is a plain pill switch (the checkbox drawn with gradients), so the
form still works and still looks like a switch.

## The leaf

The model is built the way the plant builds the leaf, in millimetres, and drawn
with a straight-on camera in front of the page.

```
            leaflets (pinnules), 12-25 pairs per pinna, each on a pulvinule
          ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱
   ┌──── pinna ─────────────── tip          two pairs of pinnae, digitate:
stem    ╲╲╲╲╲╲╲╲╲╲╲╲╲╲╲╲                    inner pair longest, outer pair set
  │   pinnar pulvinus                       a little lower and shorter
  ●══ petiole ══●╪═ pinna ───
  │  primary     ╪═ pinna ───
  │  pulvinus    ╪═ pinna ───
 stipules, prickles
```

- **Petiole** from a node on a prickly, reddish stem (with its stipules), a
  swollen **primary pulvinus** at its base. Hero size 30 mm, compact 13 mm.
- At its tip, **one or two pairs of pinnae** held digitately (like fingers), each
  on a **pinnar pulvinus**. The inner pair is longest (56 mm), the outer pair a
  little shorter and inserted a millimetre or two lower on the very short
  rachis. Each rachis curves slightly, the outer ones outward.
- Along each pinna **10 to 25 pairs of leaflets** (fewer and a little broader
  on the compact switch, so each one still reads at 1x), each on a **pulvinule**:
  linear-oblong, the base oblique with a small auricle on the back edge, the tip
  acute and turned forward, the midvein running close to the forward edge, the
  margins bristly. They are smallest at the base and the tip of the pinna and
  angled a little toward the tip when open.
- The large leaf also shows a flower head in the next axil, a globe of pink
  stamens on its peduncle, and the stem cut off below as on a herbarium sheet.

Three tiers of motor organ, three kinds of actuator: every leaflet has a fold
value `f`, every pinna a convergence `c`, the leaf a droop `q`, each 0 (open) to
1 (closed). Everything drawn is computed from those numbers every frame.

**Folding is upward.** A leaflet rotates about the rachis until it stands past
upright and meets its partner, *upper faces pressed together*, and at the same
time sweeps forward toward the pinna tip so the folded pairs lie overlapping
like tiles. So what you see of a closed pinna is the paler, greyer **lower
(abaxial) surface** of its leaflets, a narrow braid where there was a fan. Each
leaflet carries its own normal, and the face the camera sees is chosen from it,
so this falls out of the geometry rather than being painted on.

**The droop is a rigid rotation** of the whole leaf about the primary
pulvinus's hinge axis (horizontal, across the petiole), as the real pulvinus
bends. The petiole points a little toward the viewer, so a raised leaf stands
further off the paper than a fallen one.

## How it moves (and how honest that is)

**The signal.** Touching *Mimosa* starts an electrical signal (action
potentials, and with wounding a slower variation potential) that travels
through the leaf at a few centimetres a second, classically quoted at 2 to 3
cm/s. Here it travels along the only roads it has: along the touched pinna in
both directions, across the petiole tip, out along the other pinnae from their
bases, and down the petiole to the primary pulvinus. Each actuator starts
moving when the signal reaches it, at `distance / speed` plus a 40 ms latency.
That gives the order of events the plant shows: the touched pinna closes pair
by pair toward its base, its neighbours then close from the base outward, the
pinnae converge, and the leaf falls last. Where you clicked on the leaf is
where it starts; a key, a label click or `set()` starts it at all four tips.

**Time is compressed.** The default signal speed is 22 cm/s of leaf, about
nine times the real one, so the full collapse takes 0.6 to 0.9 s instead of
several seconds. A pulvinule takes about 140 ms to fold (a second or so in
life); the primary pulvinus 420 ms (one to a few seconds in life), with the
small bob of a stalk falling under its own weight. Recovery is compressed far
more: the default 2.4 s stands for several minutes to a quarter of an hour.
The *asymmetry* is the true part: folding is fast because the motor cells on
one side of each pulvinus lose turgor at once (potassium and chloride ions
flow out, water follows through aquaporins, the cells go slack), while reopening
waits for the ions to be pumped back and the cells to refill. In the primary
pulvinus it is the lower half that collapses, in the pulvinules the upper half,
which is why the leaf falls and the leaflets rise.

**Recovery is uneven.** The petiole lifts first, the pinnae part, and each
leaflet starts reopening at its own moment and its own rate (random within a
band, with a slight tendency for the base of each pinna to go first), so for a
second the leaf is ragged, half open, the way a real one looks.

**Habituation** (Gagliano et al. 2014). Potted *Mimosa* dropped repeatedly from
a short height stopped closing after a few dozen drops, kept the lesson for
weeks, and still closed fully for a different stimulus (shaking), so it was
learning, not exhaustion. Here each fold has an amplitude `1 - h`; each
stimulus pushes `h` halfway to 1, and it decays with a 12 s time constant
(enormously faster than the plant forgets: a UI convenience). Fold strength
scales the leaflets' fold, how far the signal reaches, and whether the pinnae
converge (above 0.25) or the leaf drops (above 0.5). Below 0.12 the leaf rests:
no reflex at all.

The checkbox value never lags. When a weak reflex leaves a switched-off leaf
half open, it then closes *slowly* (starting 0.9 s after the reflex, over about
1.5 s), the way the leaf folds at dusk (nyctinasty, a different, unhurried,
clock-driven movement) rather than by reflex. A signal already on its way is
never cancelled: switch it back on mid-fold and the wave finishes, then the
leaf reopens.

**The brush** (decorative leaves only). A light touch on the real plant closes
only the leaflets touched and a pair or two either side; a firm one sends the
signal through the leaf. Moving the mouse over a decorative leaf folds the
leaflets under the pointer and those within about 7 mm along the rachis, which
reopen on their own a second or two later. Pressing sends the full signal and
the leaf reopens by itself after a pause. Brushing is off on real switches,
because a switch that changes when you merely pass over it is lying about its
state.

## Options

Data attributes, or the options object (which wins).

| Option | Attribute | Default | |
|---|---|---|---|
| `size` | `data-size` | `compact` | `compact`: a settings-row switch (the box is `--mt-w` by `--mt-h`; the leaf overhangs it). `hero`: the large leaf on a sprig, filling its container at `--mt-aspect`. |
| `pinnae` | `data-pinnae` | `2` | Pairs of pinnae: `2` (four fingers) or `1` (two, as on young leaves). |
| `leaflets` | `data-leaflets` | 13 compact, 23 hero | Leaflet pairs on the longest pinna; the others scale with it. Clamped to 10..25. |
| `speed` | `data-speed` | `22` | Signal speed in cm of leaf per second. 2.5 is real time. |
| `recover` | `data-recover` | `2400` | Reopening time in ms (the leaflets' spread runs to about 1.25 times this). |
| `habituate` | `data-habituate` | `true` | `false`: every fold is a full fold. |
| `brush` | `data-brush` | `false` on inputs, `true` on decorative | Pointer-over folding of the leaflets under it. |
| `flower` | `data-flower` | `true` | The flower head on the hero sprig. |
| `seed` | `data-seed` | random | Fixes the leaflets' small differences in size, angle and tone. |

Events, bubbling from the input (or the decorative element):
`mimosa-toggle:fold` with `{ response, strength }` (`full` at 0.6 and above,
`weak` below, `none` when resting) and `mimosa-toggle:open`. The native
`input`/`change` events are the checkbox's own.

## Theming

Set on the wrapper (`.mt`) or any parent: the defaults are fallbacks, so a value
set higher up inherits. Colours are read once; call
`destroy.recolor()` after changing them on a live switch.

| Variable | Default | |
|---|---|---|
| `--mt-w`, `--mt-h` | `92px`, `40px` | Compact box (the hit area and the pill). |
| `--mt-aspect` | `5 / 4` | Hero aspect ratio. |
| `--mt-leaf` | `#335c22` | Upper (adaxial) leaflet green, sampled from the Midjourney reference (see Credits). |
| `--mt-under` | `#a3b98e` | Lower (abaxial) green, paler and greyer. Seen on folded leaflets. |
| `--mt-glow` | `#b4cf54` | Light coming through a leaflet from behind. |
| `--mt-stalk` | `#6f8a3c` | Petiole and rachis. |
| `--mt-pulvinus` | `#9a6a3e` | The swollen motor joints. |
| `--mt-stem` | `#7a4532` | The reddish stem. |
| `--mt-shadow` | `#2a2216` | Shadow colour on the page. |
| `--mt-track` | `#e5e6d8` | The compact pill when on; `--mt-track-off` (transparent) when off; `--mt-track-line` its border. |
| `--mt-ring` | `var(--ink)` | Focus ring. |

## How it is drawn

One 2D canvas per leaf (DPR capped at 2). Every leaflet is a polygon from a
unit template (6 points a side compact, 11 hero) placed by its attachment
point, length axis and width axis in 3D, then projected. Leaflets, rachises and
petiole are sorted back to front each frame, so folded leaflets standing toward
you cover the rachis and overlap each other in the right order.

Lighting is the house key light (the one wax-seal uses): one distant light
from the upper left, azimuth 225 degrees, elevation 44 degrees, in front of the
page, so the shadow falls down and to the right at 45 degrees.
Each leaflet is lit Lambert-fashion from its own normal; when the light falls
on the face away from the camera, a share of `--mt-glow` is added instead,
because a thin leaf passes light; the upper face gets a small waxy highlight.
Leaflets are drawn at 93% opacity (94% compact), so overlaps darken as they
do in a real leaf held up to the window. A folded leaflet is seen almost
edge-on, so it is also stroked in its own colour, which keeps a closed pinna a
visible line at 1x.

The shadow is the same geometry slid along the light onto the page (`z = 0`),
drawn as one silhouette into an offscreen canvas and composited once with a
blur that grows with the leaf's height (one blur per frame, not per leaflet).

## Accessibility

It is the real `<input type="checkbox" role="switch">`, transparent and laid
over the box: focus, Space, the label, `form` submission and `reset`, and the
screen reader's "switch, on/off" all belong to it. Nothing is announced in
addition, because the state the switch reports is the true one; the leaf's
lag is visual only. The focus ring is drawn around the box (`:focus-visible`
only). Enter toggles it too, as the switch pattern allows (Space is the
checkbox's own). The canvas is `aria-hidden`; decorative leaves are `aria-hidden` and
not focusable. A disabled input greys the leaf. In forced-colours mode the
native checkbox is shown.

## Reduced motion

`prefers-reduced-motion: reduce`: every change is instant (the leaf is simply
open or closed), there is no wave, no recovery, no brush. The pose still
follows the value, so it remains a legible switch.

## Tuning notes

- rAF runs only while an actuator is moving; idle there is no loop (checked: 0
  frames in 2 s at rest). Offscreen (IntersectionObserver) or in a hidden tab
  nothing is drawn; motion is time-based, so the leaf is just further along
  when it comes back.
- `fit()` measures the leaf open and closed and fits both into the box: compact
  lets the open fan and the fallen leaf overhang the pill (about 30% of its
  height above and below, shadow included: 12px at the default 40px), hero
  fits the whole sprig into its plate. Give a compact row at least
  `--mt-h` + 24px of height (64px by default) so the leaf never reaches the
  next row's text; the overhang takes no clicks.
- Timing constants live in `fold()` and `unfurl()`: latency 40 ms, pulvinule
  120 to 160 ms, pinnar pulvinus 260 ms, primary 420 ms (`EASE.drop`, a slight
  overshoot), habituation gain 0.5 and decay 12 s.
- Sound (off by default, the shared speaker button): a dry rustle of folding
  leaflets on a full fold, a smaller one on a weak fold, nothing when resting.

## Credits

No libraries. The demo's watercolour, Maria Edgar's *The Sensitive Plant*
(1808), is from The Metropolitan Museum of Art's Open Access collection (CC0).
The leaflet colours were sampled from Midjourney images generated for Taste;
their leaf architecture was wrong (eight pinnae), so the structure is modelled
from botanical descriptions instead. The rustle is synthesised. See
`assets/credits.json`.

References: M. Gagliano, M. Renton, M. Depczynski, S. Mancuso, "Experience
teaches plants to learn faster and forget slower in environments where it
matters", *Oecologia* 175 (2014) 63-72. T. Sibaoka, "Rapid plant movements
triggered by action potentials", *Botanical Magazine Tokyo* 104 (1991) 73-95.

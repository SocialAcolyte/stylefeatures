# jubako

Tabs that are the tiers of a Japanese food box. A *jūbako* of the 17th century (The Met 2015.500.2.31a–f) stands
beside the tab list, one tier to a tab. Choose a tab, or take hold of a tier and draw it up, and the tiers above lift
off along the box's own axis and hang there, so the tier you chose stands open and its panel comes out of the box's
side, level with it; choose a higher one and they come back down onto it. Every
tier is the Met's own photograph: the museum photographed this box five times from one camera, taking a tier off
each time, so every inside you see open is the inside the photographer saw.

For a menu by courses, a product page's details, a documentation section, a card with two to five views. The demo
is a New Year *osechi* order page, which is what jūbako are for: one course to a tier.

```html
<link rel="stylesheet" href="jubako.css">
<section class="jb" data-jubako aria-labelledby="about">
  <div class="jb-stage">
    <div class="jb-box" aria-hidden="true">
      <img class="jb-shadow" src="assets/shadow.webp" width="826" height="369" alt="" style="--x:-2;--y:675;--w:826">
      <img class="jb-tier" src="assets/tier-5.webp" width="750" height="540" alt="" style="--x:45;--y:479;--w:750">
      <img class="jb-tier" src="assets/tier-4.webp" width="771" height="499" alt="" style="--x:34;--y:351;--w:771">
      <img class="jb-tier" src="assets/tier-3.webp" width="789" height="484" alt="" style="--x:25;--y:218;--w:789">
      <img class="jb-tier" src="assets/tier-2.webp" width="803" height="464" alt="" style="--x:15;--y:82;--w:803">
      <img class="jb-tier" src="assets/tier-1.webp" width="813" height="383" alt="" style="--x:8;--y:2;--w:813">
    </div>
  </div>
  <div class="jb-panels">
    <header class="jb-title"> … </header>                         <!-- optional: beside the box, over the panel -->
    <section class="jb-panel" id="ichi"><h3 class="jb-head"><span lang="ja">一の重</span> Celebration</h3> …</section>
    <section class="jb-panel" id="ni"><h3 class="jb-head"><span lang="ja">二の重</span> From the grill</h3> …</section>
    <!-- … up to five; the first panel is the top tier -->
  </div>
</section>
<script type="module" src="jubako.js"></script>
```

Keep the six `<img>` exactly as above (bottom tier first): their places are measured (`assets/geometry.json`).

## What it does

- **A real tablist.** The JS makes a `role="tablist"` of `role="tab"` buttons from the panels' `.jb-head` headings
  (or uses a `.jb-tabs` you wrote), with `aria-controls`, `aria-selected`, roving `tabindex`; panels become
  `role="tabpanel"`, labelled by their tab and focusable. ↑ ↓ ← → move and choose (selection follows focus, as a tab
  set should when switching is instant), Home and End go to the first and last. The headings stay in the panels for
  screen readers and are hidden from sight; their markup (a `<span lang="ja">`) is carried into the tab.
- **Quicker than a plain one.** The panel swaps at once; the box moves beside it and never holds the reader up.
  Pointing at a tab, the tiers that would move give a little toward where they would go.
- **By hand.** Press a tier and draw upward: the tiers from it up come off in your hand, on a stiffer spring that
  follows it, and a little past the lift they resist. Let go past 40 % of the lift (or with a flick) and the tier
  under them is chosen; short of it, they settle back. Press a lifted tier and draw down to close the stack onto it.
  A press without a draw chooses the tier pressed. A finger rests 180 ms before it holds a tier (the tiers give a
  little to say so), so a swipe across the box still scrolls the page (`touch-action: pan-y`). A mouse holds at once.
- **The panel comes out of its tier.** In the aside layout the chosen panel's top is set level with the open tier's
  mouth, and it slides out from the box's side (0.5 s, settling). On a phone it drops in under the box.
- **Lacquer fits close.** As a stack comes off a tier, that tier is drawn up with it about 2 % of the lift and drops
  back, the way a snug lid takes the box with it for a moment.
- **Without JS** the box stands with its top tier open and every panel is shown under its own heading, in order.
- **Reduced motion:** the tiers are where they belong at once, the panel appears without sliding. A drag still moves
  what you hold.
- **The motion** is springs: each tier a mass (ζ 0.8, ω 19 s⁻¹, fixed steps at 240 Hz) whose target is the lift
  for the tiers above the chosen one and 0 for the others, or the hand's height (ω 34 s⁻¹ while held). A tier never
  sinks into the one below it: it rides on it.
  Changing your mind mid-lift is continuous. The loop runs only while something moves, and not off screen.
- **Two layouts, by measurement.** *Aside* (the component 760 px wide or more, and tiers at least 26 px apart): each
  tab sits beside its own tier, at the middle of the tier's band where it meets the box's right edge, and rides up
  with it; the panel is to the right, with an optional `.jb-title` above it. *List* (narrower: a phone, a card): a
  small box at the left with the tabs listed beside it in the tiers' order, and the panel under both.

## Options

| option | data attribute | default | |
|---|---|---|---|
| `selected` | `data-selected` | URL `#hash` if it names a panel, else 0 | index (0-based) or panel id to start on; lands without moving |
| `lift` | `data-lift` | `0.8` | how far lifted tiers rise, as a share of the top tier's open mouth (288 frame px) |
| `layout` | `data-layout` | `auto` | `aside` or `list` to force one |
| `align` | `data-align` | `true` | `false` keeps the panel at the top instead of level with the open tier |
| `hash` | `data-hash` | `false` | `true` writes the chosen panel's id to the URL (`replaceState`) |

Fewer than five panels: the tiers below the last tab stay closed under it (the demo's card has three). More than five
are ignored: the box has five tiers.

**Events** (bubbling, on the root): `jubako:change` `{index, id, tab, panel, by}`, `by` one of `tab`, `key`, `hand`,
`api`.
**API:** `const j = jubako(root)` → `j.select(i | id)`, `j.index`, `j.tabs`, `j.panels`, `j.hold(true|false)` and
`j.advance(seconds)` (for stills), `j()` destroys (listeners, observers, the tablist it made; the page reads as it does
without JS). Also on `root.jubako`.

## Theming

`--paper --ink --ink-2 --ink-3 --rule --accent --serif --sans` as everywhere. Component custom properties:
`--jb-box` (the box's width in the aside layout, default `clamp(280px, 31vw, 440px)`), `--jb-box-s` (in the list
layout, `clamp(104px, 40%, 184px)`), `--jb-gutter` (room for the tabs beside the box, `13.5em`). The chosen tab's rule
is `--accent`; the demo sets it to the red-brown of the box's own lacquered rims (#9a3b22). Japanese in a tab label
uses `--jb-ja` (default Shippori Mincho, then Hiragino Mincho).

## In life, and here

| In life | Here |
|---|---|
| A *jūbako* is a stack of square lacquered boxes, each fitting the one below, with a lid on top. At New Year *osechi* is packed into it a course to a tier, cooked beforehand so no fire is lit for the first three days, and stacked because good things should pile up: *ichi-no-jū* the celebratory small things, *ni-no-jū* the grilled, *san-no-jū* the simmered, then *yo-no-jū* (never *shi*, four, which also says death) the vinegared, and the fifth often left empty for the fortune still to come. | A stack of five tiers, one to a tab, the first tab the top tier: the demo's five tabs are those five tiers, the fifth "kept empty". Choosing a tab lifts every tier above it off, so the chosen tier's inside is open, as when you lift the upper tiers to reach the one you want. The lid (photographed in another campaign, against a different backdrop) is left off. |
| The tiers sit flush, outer walls aligned, each fitting over the rim of the one below, so the seams read as fine dark lines in the decoration, with a glint of the lower tier's red rim. | Each tier is cut along its own bottom seam, found where two of the Met's photographs stop differing (residual 0.4 px), and runs to the box's two vanishing points. Stacked, each covers the inside of the one below, and the five photographs together match the first to 1.8 % mean difference. |
| This box is black lacquer banded all round in stripes of gold and silver *hiramaki-e* (gold dust sprinkled into lacquer, low and flat), sheet lead, and *raden*, mother-of-pearl, with bands of scrolling arabesque between. The stripes run round the corners and across the seams, so the stack reads as one striped block. Its lid has Chinese figures in inlay. | The decoration is untouched: the Met's photographs at half their 4000 px scale, a registration resample (under a pixel for three tiers, 3 px and 18 px with a fraction of a degree for the last two) the only change. The stripes line up across every seam because every tier is the same lacquerer's band seen from the same camera. |
| Inside, each tier is plain black lacquer with a red-brown rim, so food sits on black. | The insides you see open are the Met's: each tier's from the photograph in which it was on top. The undersides of lifted tiers never show (the camera looks down on them), so nothing has to be invented. |
| The tiers are lifted straight up, by hand, and set down beside. A well-made tier fits so closely that the one below rises with it a moment before it lets go. | You can lift them by hand: hold a tier and draw it up, and everything above comes with it; let go and it settles open or back. The tier left behind rises a hair with the stack and drops back. The tiers hang rather than being set down beside, so the page doesn't reflow. The box's own photographed shadow stays on the floor under it; the lifted tiers cast none into the open tier, because no photograph shows that shadow and it would have to be drawn. |
| Each course has its meanings: black beans for health, herring roe for children, prawns for a long life, lotus root for seeing ahead. Hiroshige's *Uozukushi* (Every Variety of Fish, 1830s) printed these same fish, with comic verses (*kyōka*) above them. | Each panel carries a real print of what its tier holds: Hiroshige's sea bream, spiny lobster, and black and red sea bream with bamboo shoots (the Met, CC0), and a surimono of a basket of lotus root (LACMA). The fifth tier's panel has none. |

## Files

- `jubako.js` (about 450 lines), `jubako.css`: the component. No libraries.
- `assets/tier-1.webp … tier-5.webp`, `assets/shadow.webp` (about 350 KB together), `assets/geometry.json`,
  `assets/credits.json`, `assets/PICK.md` (the hunt, the shortlist, which photograph covers which state, and why
  the gold-lined second box was left out). `assets/prints/` (the demo's four prints, about 700 KB, lazy-loaded).
- `tools/cut.py`: register, matte, seams, export, from the Met originals. `tools/preview.py`: composite every state
  offline to check an export.

## Credits

The box: *Food Box with Striped Decoration and Chinese Figures*, Japan, Edo period, 17th century. The Metropolitan
Museum of Art, 2015.500.2.31a–f, Gift of Florence and Herbert Irving, 2015. Open Access, CC0. Photographs
`L1996_47_86_O2_sf` … `O6_sf`.

Prints: Utagawa Hiroshige, *Uozukushi*: "Medetai Fish and Sasaki Bamboo", "Ise-ebi and Shiba-ebi", "Kurodai and
Kodai Fish with Bamboo Shoots and Berries" (The Met, DP123587, DP123581, DP123580; CC0). "Basket of Lotus Root and
Single String Chin", surimono, Japan, 19th century (LACMA M.79.152.573, public domain). All via Wikimedia Commons.

Matting: this repo's asset engine (`tools/engine/stages/matte.py`, BiRefNet via rembg). Registration: OpenCV ECC.
The demo's restaurant, its prices and its addresses are invented.

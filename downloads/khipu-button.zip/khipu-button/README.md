# khipu-button

A "next option" button for anything that steps through a few alternatives, such as the versions of a chat reply or an editor's suggestions. The end of one of an Inka khipu's two-colour cords runs across the button from under its left edge and ends in its own knot. From behind it hang the ends of the khipu's real cords, one for each option. The one you are on hangs plumb, and a press draws the next one plumb as it lays the last aside. The words beside them ("2 of 3 ›") are part of its name.

This is the button part of `components/khipu` and nothing else. There is no conversation khipu, no tree and no essay. Every cord comes from one photograph: the Cleveland Museum of Art's khipu 1940.469 (CC0). Each cord on the button is one stretch of one real cord, cut in one piece on the photograph's own pixel grid (`assets/ends.webp`), with its own knotted or curled end. Nothing is drawn, straightened or joined. A cord only turns, as one rigid piece, about the point where it is tied on.

## Markup

```html
<link rel="stylesheet" href="khipu-button.css">

<!-- the button: the words are in the HTML; the script puts the cords in front of them -->
<button type="button" class="kb" data-khipu-button data-count="3" data-current="2" data-noun="version">
  <span class="kb-label">2 of 3</span><span class="kb-go" aria-hidden="true">›</span>
</button>

<!-- with its previous counterpart: its own framed button just before it, in a .kb-pair -->
<span class="kb-pair">
  <button type="button" class="kb-prev" aria-label="Previous version"><span aria-hidden="true">‹</span></button>
  <button type="button" class="kb" data-khipu-button data-count="3" data-current="2" data-max="4" data-noun="version">
    <span class="kb-label">2 of 3</span><span class="kb-go" aria-hidden="true">›</span></button>
</span>

<button type="button" class="kb kb-tool" data-khipu-button data-count="3" data-noun="draft"
        data-label="Draft {i} of {n}"><span class="kb-label">Draft 1 of 3</span><span class="kb-go" aria-hidden="true">›</span></button>
<button type="button" class="kb kb-lg" data-khipu-button data-count="4"><span class="kb-label">1 of 4</span><span class="kb-go" aria-hidden="true">›</span></button>
<button type="button" class="kb" data-khipu-button data-count="1" disabled><span class="kb-label">1 of 1</span><span class="kb-go" aria-hidden="true">›</span></button>

<script type="module" src="khipu-button.js"></script>
```

`[data-khipu-button]` starts by itself. Write the words in the HTML: without JS the button is a plain framed button that says "2 of 3 ›", with its words centred. The `›` says a press goes forward. It is `aria-hidden`, and the script adds it if you leave it out. Outside a form, a button with no `type` is given `type="button"`; inside one, give it `type="button"` yourself unless a press should also submit.

## Driving it

The button does not own your content. It tells you which option to show:

```js
const btn = document.querySelector('#versions');
btn.addEventListener('khipu-button:change', (e) => {
  const { current, count, from, dir, via } = e.detail;   // 3, 3, 2, 'next', 'pointer'
  showVersion(current);
});
```

```js
import { khipuButton } from './khipu-button.js';
const kb = khipuButton(btn, { count: 3, current: 2, noun: 'version' });   // null above 7 options: see below
kb.current; kb.count;          // 2, 3 (1-based, like the words)
kb.next(); kb.prev();          // step, as a press would
kb.set(1, { say: true });      // jump; say: true also announces it in the live line
kb.setCount(4, 4, { say: true });   // a fourth version arrived: its cord is tied on, and it is shown (false above 7)
kb.ready;                      // a promise: the cords are on
kb.state();                    // for tests: each cord's resting angle, and which one is on
kb.destroy();                  // removes the cords, the live line and every listener; the button is its markup again
```

`setCount` with a new count keeps every cord where it was. The new cord fades in at the next tie along the primary, and the primary does not change. Give `data-max` for the most options there may be, and the room for their cords is kept from the start, so the button never widens and its neighbours never move. Without it, the button widens by one tie. After `destroy()` the controller does nothing, and a second `destroy()` is a no-op. `destroy()` writes the current option and count back to `data-current` and `data-count`, so `khipuButton(btn)` carries on where it was.

**Seven options at most.** There is one cord for each option, and seven cords to cut, so keep a stepper's alternatives to seven. With more, `khipuButton()` leaves the button as it is (its own words, no cords, no steps) and returns `null`, and the auto-start does the same. `setCount()` above seven changes nothing and returns `false`, so you can stop offering more: hide or disable your Retry when it does. Both warn in the console.

## Options

Data attributes, or the options object, which wins.

| Option | Attribute | Default | |
|---|---|---|---|
| `count` | `data-count` | `2` | How many options, one cord each: **1 to 7**, because there are seven clean whole cord ends of one kind on the photograph. Above 7 the button is not taken over (see Driving it). |
| `current` | `data-current` | `1` | The option shown, 1-based. |
| `max` | `data-max` | the count | Keep room for this many cords, for options that may arrive later (`setCount`). |
| `noun` | `data-noun` | `option` | For the name and the live line: "2 of 3, next version", then "Version 3 of 3". |
| `label` | `data-label` | `{i} of {n}` | The visible words before the `›`. `{i}`, `{n}`, `{noun}` and `{Noun}` are filled in. |
| `wrap` | `data-wrap` | `false` with a previous button, `true` without | `false`: it stops at the last option (and the previous button at the first). There it stays focusable but is `aria-disabled`, its name says "the last version", its `›` fades, and its cords keep their colour, so you can still see where you are. `true`: from the last option a press goes round to the first. That, and a jump by `set()` or `setCount()`, is the only time more than one cord changes side, and they go a cord at a time (see By hand). |
| `prev` | `data-prev` | the `.kb-prev` in the same `.kb-pair` | The id of a "previous" button anywhere on the page. |
| `status` | `data-status` | a line after the button | The id of your own live region. Use it when the button may be removed, so its last word is said from an element that stays. |
| `src` | `data-src` | `assets/ends.json` beside the module | The cords' map. `ends.webp` sits beside it. |
| | `data-label-fixed` | | Keep your own `aria-label` (or `aria-labelledby`). |

### Sizes

Size is the class. The cords' box is most of the button's height. Its width follows from the number of options, and it never changes as you step.

| class | button | the khipu it holds, top to bottom | where |
|---|---|---|---|
| `.kb` | 32 px | 3.8 cm | **the row size**: a reply's footer, a form footer, a list row |
| `.kb-tool` | 44 px | 4.3 cm | a toolbar |
| `.kb-lg` | 64 px | 4.8 cm | a choice on its own |
| `.kb-xl` | 132 px (112 px on a screen 480 px wide or less) | 10 cm | **a hero**: the demo's opening line, with all seven cords (longer cords, not a larger picture) |
| `.kb-sm` | 26 px | 3.4 cm | dense desktop lists only: on a phone it is a small target, and its cords are about 1.3 px wide |

At every size up to `.kb-xl`, a 3x screen draws at most 0.82 of its pixels per pixel of the photograph, so the cords are never enlarged. Each size can show more of each cord (the larger, the longer), never a blown-up one. For any other size, set `--kb-h` (the button), `--kb-cords-h` (the cords' box), `--kb-fragment` (how much of the khipu the box holds, in the photograph's px, at about 44 to the centimetre) and `--kb-tie` (how far down that box the primary crosses, in the same px). A smaller fragment gives thicker cords. In a `.kb-pair` the previous button takes the height of the stepper beside it, at any size.

The stepper has a hairline edge at rest, like the buttons around it. `.kb-quiet` swaps the hairline for a faint face, for a row of quiet text buttons. Either way the edge shows, because the primary runs on under it: the button is a window on a longer khipu.

Theme with `--ink`, `--ink-2`, `--ink-3`, `--rule` (the edge), `--accent` (the focus ring) and `--sans`. `--accent` must reach 3:1 against the surface behind the button. The demo's clay `#c96f4a` gives 3.15:1 on `--paper` and 3.3:1 on its cards, but only 2.85:1 on `--paper-2`, so pick a darker accent there. The cords are the photograph's colours, so they are not themed. They sit best on warm paper, close to the cloth they were photographed on.

## Events (all bubble)

| | when |
|---|---|
| `khipu-button:change` | the option (or, after `setCount`, the count) changed. `detail: { current, count, from, dir, via }`: `dir` is `next` or `prev` for a step and `set` for `set()` or `setCount()`; `via` is `pointer`, `touch`, `key`, `api` or `other` (assistive tech, `el.click()`) |
| `khipu-button:ready` | the cords are on (`detail: { current, count }`) |

## By hand

- **Hover** (a real mouse only): the next cord lifts a little toward plumb, as if you had reached for it, and the edge darkens. The previous button does the same for the cord before. After a press the hint pauses for 0.7 s (after a sweep, until every cord is at rest), then comes back if the mouse is still there.
- **Press and hold** (mouse, a held Space, or a touch): the face darkens and the next cord is drawn about half-way to plumb and held there. Let go and it is drawn plumb (0.62 s, a damped spring from rest), while the cord you were on is laid aside a beat later (0.8 s). Nothing spins, swings round or jumps. A cord turns about 24 degrees in a step.
- **Touch** waits 100 ms before it takes hold, as the browser's own `:active` does, so a scroll that starts on the button never moves a cord. A tap steps on its click, as a native button does, so a tap that only stops a scrolling page stays inert, as theirs does. Until the click comes the cord stays as it is, so nothing starts back before it goes on. A touch held 0.45 s or more steps when it lifts on the button, because a long press may bring no click, and a click that still follows it is not counted again, however long your change handler takes.
- **Slide off before letting go**, or start a scroll on it: the cord goes back, the face goes back, and nothing happens.
- **Enter** steps at once. A held Enter steps once, not on and on.
- **More than one option at once** (round from the last to the first with `wrap`, the default only without a previous button, or a jump by `set()` or `setCount()`): the cords go a cord at a time, from the one let go toward the one drawn, 180 ms apart (closer on a long jump, so that every start falls within 0.72 s). Each turns into the room its neighbour has just left, so no two cross, and each takes as long as its turn needs to stay under 115 degrees a second; a plain step's drawn cord peaks at about 150. Measured on the list's wrap from 4 to 1: the two cords that change side pass plumb 0.2 s apart, never more than one is near plumb at once, the peaks are 114 to 115 degrees a second, and all are at rest after 1.6 s. A cord tied on by `setCount()` fades in on its turn.

## Accessibility

- It is a real `<button>`. Its name is the visible words, then what a press does: "2 of 3, next version". It starts with what is on screen, so "click 2 of 3" works with voice control. The name changes with each step. The `›` is `aria-hidden`.
- A polite live line (`role="status"`), right after the button or its pair, says each step: "Version 3 of 3". It changes what `+` and `:last-child` match in your CSS. If that matters, point `data-status` at a live region of your own.
- The cords are `aria-hidden`, and no canvas reaches the accessibility tree.
- **Previous**: a real button with its own name and its own frame, 4 to 8 px from the stepper, so the two are not easy to mis-tap. Write `aria-label="Previous version"` in the markup, so it has a name without JS too. The script names it "Previous {noun}" if you did not. Its face darkens while it is held, by touch as well.
- **Disabled**: with `disabled` it is out of the Tab order and ignores every press. Its words go grey and its cords pale. **At the end** (one option, or the last without `wrap`) it stays focusable but is `aria-disabled="true"`: a press does nothing, so focus is never lost, and only the `›` fades. Your own `aria-disabled` is left as you set it.
- **Focus**: a 2 px ring in `--accent`, 2 px off the face (see Theming for its contrast). Hover styles apply only where there is a real hover, and a tapped button does not stay lit.
- **Reduced motion**: the cords land on their new places at once, and a hover or a press does not move any cord. The face still darkens under a press.
- **Forced colours**: the cords are hidden, and the words and the edge stay in the system's colours.
- **No JS**: a plain framed button with its words, centred, at its size.
- **Touch**: 32 × 32 px at the row size, and the previous button the same.

## In life, and here

| In life | Here |
|---|---|
| A khipu is a primary cord with pendant cords tied on with half hitches. On Cleveland 1940.469 the primary is a thin tan cord, short and covered by its clustered pendants, and the pendants are 40 to 50 cm long, fanned out on the mount. | No whole pendant fits a button: at 32 px one would be about a tenth of a pixel wide. So the button holds a few centimetres of the khipu, as a window does, and shows **the ends of its cords**. The primary is the last 15 cm of one of its two-colour (black-and-white) cords, which ends in its own end knot and tuft. It runs on under the button's left edge. |
| A pendant ends in a frayed tail or an end knot. On this khipu, a group of mid-brown cords hang side by side at the bottom of the fan, each ending in its own knot or curl. | One of those cord ends hangs for each option, in order from left to right: the last 3 to 8 cm of a real cord (more at larger sizes), with its own end, exactly as it lies on the cloth, curve and all. Each hangs from behind the primary, its top tucked behind it, as a verso attachment seen from the front would show it. All seven are of one kind, because a button's options are of one kind. |
| A khipu is read by handling it, a cord at a time: one pendant is drawn out of the cluster and run through the fingers. | The option you are on is the cord drawn out: it hangs plumb, with its centre of mass straight under its tie. The others lie parted to either side, a little more the further out they are, as the khipu's own pendants lie fanned. A press passes the hold to the next cord. It is drawn plumb, and the last one is laid aside. |
| A slack cord lies in soft curves. | Every cord keeps the curves it has in the photograph. The pixels move only as rigid pieces, so a cord laid aside is turned, never bent. |
| Knots record numbers in base ten. | The knots are the cords' own end knots. They count nothing; the words carry the number. |
| Pendants were added to a khipu as more was recorded. | `setCount()` ties a new cord on at the next tie along the primary. The others keep their places. |

## How it is put together

Offline, once (`tools/`, rerunnable with `./run.sh cut.py` then `./run.sh export.py`). The tools need three things from outside this folder, each named by an environment variable: `KB_TIFF`, the museum's full TIFF (88 MB, from the link in `assets/credits.json`); `KB_CACHE`, the cloth model and cordness map that `components/khipu/tools/common.py` makes from that TIFF (`cache.npz`); and `KB_ENDS`, the folder the cut pieces go to and `export.py` packs them from. Each defaults to where it is in this factory (`tools/engine/jobs/khipu-hunt/cma/`, `khipu-work/`, `khipu-button-fix1/ends/`). The button itself needs none of them: at run time it loads only `assets/ends.webp` and `assets/ends.json`.

1. `cut.py` follows each cord along its ridge in the full TIFF, only to know where it is and where it really ends (the trace stops where the cord thins away to nothing). The matte is then computed on the photograph's own pixels in a window round that path, from how far each pixel is from the cloth's colour, and the colour is lifted off the cloth (`F = bg + (o - bg) / a`), as `components/khipu` does. Nothing is resampled, turned, straightened or joined.
2. `export.py` packs the eight pieces as they are into `assets/ends.webp`, and writes `assets/ends.json`: where each piece is, where it came from in the photograph, and its cord's centreline from its tip.

At run time, once per size:

1. Each piece is copied out of the atlas 1:1 into its own canvas.
2. A pendant is turned, as one piece, so that the stretch from its tip up to its tie hangs with its centre of mass straight under the tie. Everything above the tie (the rest of that cord) is left out, behind the primary. Each pendant is as long as fits in the box, fray and all.
3. The primary is turned so that its run under the ties lies level, its end knot to the right.
4. Each is scaled down once, in halves and then a last step with the browser's best filter, to the screen's own pixels, and placed on whole device pixels. From then on CSS only turns the pendants about their ties (`rotate`, `transform-origin` at the tie). The primary is in front.

## Not done, and why

- **No whole pendant.** The khipu's pendants are 40 to 50 cm long; at button sizes a whole one could not be seen. The button shows the ends of real cords (one piece each, with their own ends), and their tops run on behind the primary, which runs on under the button's edge. That is a window on the khipu, not the whole object.
- **The primary is not the khipu's primary.** The real one is thin, tan and hidden under its pendants. A two-colour cord of the same khipu stands in for it, as in `components/khipu`.
- **No white cords.** The old `data-cords="white"` is gone. The white cotton cords' frayed ends, cut whole, show the gaps between their fibres and a cloth-coloured fringe on an ink face at button sizes. A clean white set would need its own matte.
- **Seven at most.** There are seven clean whole ends of one kind of cord that lie apart enough to cut. More options would need more of them, so above seven the button is left alone rather than show a count its cords cannot keep.
- **A real Android long press** (a held touch past 500 ms) is handled on the lift (any touch held 0.45 s or more), and a tap that stops a fling is left to the browser, which sends no click for it, as for a native button. Both have been checked only in headless Chrome's touch emulation, not on a device.
- **No sound.** A cord makes almost none.

## Cost

- Assets: 85 KB (the atlas 62 KB, its map 23 KB), loaded once for every button on the page. (`cords.webp` and `cords.json`, 160 KB, are `components/khipu`'s atlas, kept here byte for byte as that piece's source. They are not loaded.)
- Per button: one small canvas per cord and one for the primary, built when it starts and again only if its size or the screen's density changes. They are drawn at the screen's density up to 3x, not the house cap of 2: they are drawn once and never animated (CSS turns them), they are small, and a cord is only a pixel or two wide.
- Idle: nothing runs. A press: CSS transitions only, and a few short timers (the touch wait, the wait for a tap's click, letting go of the press, the end of the pause in the hover hint, the end of a sweep).

## Files

- `khipu-button.js`: the button. It loads the atlas, hangs the cords, and handles the states, words, keys, touch, live line and API.
- `khipu-button.css`: the button, its sizes, the face states and the cords' turns.
- `demo.html`: in use. A chat reply's versions (with Retry, which ties on a fourth), an editor's suggestions in a form footer, a composer's toolbar, a newsletter's fields as a list, and a toast's opening line as the hero, with all seven cords.
- `assets/ends.webp`, `assets/ends.json`: the cords, whole. `assets/credits.json`: where they come from. `assets/cords.webp`, `assets/cords.json`: kept from `components/khipu`, unused.
- `tools/`: `cut.py`, `export.py`, `parts.json` (where each cord is), `run.sh`. Their inputs are named by `KB_TIFF`, `KB_CACHE` and `KB_ENDS` (see How it is put together).

## From components/khipu

Kept: the khipu, the idea of its small mark (a fragment of a primary with one cord per option, the one shown taut), the matte (the cloth model and cordness map of its `tools/common.py`), the rule that pieces turn but are never mirrored, and the cords' own colours.

Changed: the original lays every cord along a path each frame, from straightened runs, knots and tails joined end to end, and greys the cords that are not shown. Here every cord is one whole piece of one cord, as photographed, and only turns. Every cord keeps its photographed colour: which option is shown is carried by how the cord hangs. Added: the visible words and the name, the live line, the held press, the previous button, the end state and wrap, the sizes, and the events.

## Credits

*Inka Khipu (Fiber Recording Device)*, Peru, Inca period, c. 1400–1532, cotton and wool. The Cleveland Museum of Art, 1940.469, CC0. Cut by `tools/cut.py`. See `assets/credits.json`.

References: L. Leland Locke, *The Ancient Quipu or Peruvian Knot Record* (AMNH, 1923); Marcia and Robert Ascher, *Code of the Quipu* (1981); Gary Urton, *Signs of the Inka Khipu* (2003).

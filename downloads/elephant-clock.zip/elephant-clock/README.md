# elephant-clock

A countdown that is al-Jazari's Elephant Clock, simulated: the folio painted (probably in Syria or Iraq) in 1315 by
Farrukh ibn ʿAbd al-Latif for a copy of the *Book of Knowledge of Ingenious Mechanical Devices*, lying on the page as a
sheet, its own painted parts working as the machine the treatise describes. A float fills through its hole and
sinks inside the elephant, turning the scribe and drawing its chain down through the arch. When it floods, the chain
lets a gold ball go: it falls from the falcon's beak into a serpent's mouth, and the serpent, a balance on its axle,
bows under its weight to the vase, lifting and emptying the float as it goes. The ball tips the spoon in the
elephant's breast, so the driver's axe comes down and then his mallet. It rings on the cymbal, and the scribe turns
back. Every one of those is gravity, a lever or a pendulum stepped at 240 Hz, and every one can be handled: tip the
serpent, turn the bird, swing the cymbal, pull the axe, drop a ball into the vase.

Idle, it is the folio pixel for pixel: what you are looking at is the `<img>`. The digits are a real `<time>`.

```html
<link rel="stylesheet" href="elephant-clock.css">
<div class="ec ec-wide" data-elephant-clock data-duration="25m">
  <div class="ec-sheet"><img class="ec-folio" src="assets/folio.webp" width="1600" height="2281" alt="…"></div>
  <div class="ec-face">
    <p class="ec-label" id="t-label">Time left</p>
    <p class="ec-readout"><time class="ec-time" datetime="PT25M" aria-labelledby="t-label">25:00</time></p>
    <div class="ec-controls">
      <button type="button" data-ec="toggle">Start</button>
      <button type="button" data-ec="reset">Reset</button>
    </div>
  </div>
</div>
<!-- counting down to a moment, running from load ("sale ends in", "closes in"): small, beside the digits -->
<div class="ec ec-small" data-elephant-clock data-until="2026-11-30T18:00:00Z">…same sheet and <time>…</div>
<script type="module" src="elephant-clock.js"></script>
```

```js
import { elephantClock } from './elephant-clock.js';
const clock = elephantClock(root, { duration: '50m', cycle: '25m' });
clock.start(); clock.pause(); clock.toggle(); clock.reset();
clock.state;        // idle | running | paused | done
clock.remaining;    // ms
root.addEventListener('elephant-clock:tick', (e) => e.detail);   // {remaining, elapsed, progress, cycle} each second
root.addEventListener('elephant-clock:cycle', (e) => e.detail.index);
root.addEventListener('elephant-clock:done', () => {});
// the machine: :whistle (the float floods), :strike {force, with: 'axe'|'mallet'}, :cymbal {force}, :restart
clock.dropBall();   // a ball into the vase, by hand
clock();            // destroy: removes the canvas, live region, listeners and timers; leaves the plain markup
```

Without JS it is the picture with the digits as written in the HTML and the buttons doing nothing, so write the
starting time into the `<time>`. With JS but no canvas it is still a working timer.

## In life, and here

The treatise (Hill's translation, Category I, chapter 4, fifteen sections) describes the clock in more detail than
the painter could show. What is simulated:

| In life | Here |
|---|---|
| Inside the elephant, a hemispherical brass float (*tarjahār*) rests on the water. Water enters through an onyx-lined hole in its base, faster when the head of water outside is greater, until it sinks, in half a constant hour. The hole is widened with emery until it does. | The float is a hemisphere whose bowl and ball weigh a quarter of its full displacement. Its draft, the water inside it and the head between them are computed by the orifice law (flow ∝ √(2g·head)). The head falls from 0.44 to 0.17 radii as it fills, so the float sinks a little faster early in the cycle than late, up to 8% off a straight line, as a real one would. Its flow is calibrated, like the onyx, so that it floods on each cycle boundary. One cycle is `data-cycle`, by default the whole duration up to 30 minutes, and 30 minutes beyond that. With `data-until`, cycles fall on the real half hours of the day. |
| A 30-dirham bronze ball rides in the float on a string over pulleys in the dome. As the float sinks it turns the axle under the scribe, who turns slowly "to the left", the tip of his pen moving along an arc of 7½ degrees. | The scribe's angle is the float's depth: as it sinks he turns through 38°, drawn as the flat papier-mâché figure he is, foreshortened about his axle with the far side rising a little (the platform is seen from slightly above). When the float is lifted, he turns back "quickly to the right". |
| The float's own chain runs up through the dome, over the pulley on the serpents' axle, to the ring of a tilting channel in the castle. When the float floods and goes down, the chain pulls the ring, and one ball rolls. Air driven out of the sinking float through a whistle is the bird's voice. | The painted chain in the arch slides down link by link as the float sinks, about 3 links a cycle, and back up when it is lifted. At the rim the float floods (1.6 s, `elephant-clock:whistle`), sinks further, and the taut chain releases one ball. |
| The ball falls on a bladed wheel whose iron rod carries the bird on the cupola, so the bird turns "some rotations". It runs through a balance that throws the man on the balcony onto his other thigh, lifting his hand from the falcon's beak, and the ball rolls out of the beak. | The ball's knock on the wheel gives the bird's rod a turn. Friction at the wheel slows it, and it settles facing one way or the other. The balcony man, a damped rotor on his axle, is thrown 5° and settles back. The ball (gold, as this painter paints bronze) rolls out of the beak with the speed the channel gave it, and falls under gravity. |
| It drops into the open mouth of a serpent on an axle between the pillars. Made "like a balance that tilts with a small weight", the serpent slowly bows with it to the vase. A chain wound on its back lifts the sunken float, which tips on its hinges and empties. The ball drops into the vase, and the serpent rises. | The serpent is a rotor on its real axle (the knob its claws grip). Its own weight holds it raised, its centre of mass placed so that it is strongest when raised and weakest at the vase. The ball's weight acts at the mouth, about 300 px of lever when raised. The full float's weight resists through the chain at first, so it starts slowly and gathers pace, reaching the vase in about 3.3 s. Its head passes behind the driver. At the vase the ball rolls into the vase, and the counterweight brings the serpent back up in about 1.8 s. |
| From the vase the ball runs down a pipe into the scoop of a spoon in the elephant's breast. The spoon's handle is heavier than its scoop: the ball tips it, a rod brings the mahout's axe down on the elephant's head, a chain raises his mallet. The ball runs out of the breast onto the edge of a hanging cymbal, then into a tray between the legs, and the mallet falls. | The spoon is a lever: the ball's weight tips it in about 0.34 s, and the axe arm and mallet turn on their axles at the shoulders of the copper shift, through the linkage. When it tips far enough the ball rolls out, through the breast, and flies under gravity onto the cymbal, a pendulum on its cord. They collide (restitution 0.4) and the blow swings it. The ball goes on under the elephant. The spoon's handle brings the mallet down: two blows (`:strike` with its force), and `:cymbal` with its force. |
| The servant sets the clock going at daybreak: he lowers one serpent's head until its lip touches the vase, so the float is lifted and emptied, then lets go, and the serpent rises. | The folio shows exactly this: one serpent with its lip on the vase. That is the idle state (the servant's hand is on it). `start()`, or lifting the serpent and letting go, lets it rise, and the float is set on the water. `reset()` lowers it to the vase again, and the page is the painting once more. |

## By hand

The machine runs with or without you; while it runs you can also work it, and it answers the same way:

- **The serpent**: drag its head round its axle. Let go and its counterweight brings it back up. Hold its head at
  the vase for about a second and its chain lifts the float until it tips and empties, so the cycle starts again
  (`elephant-clock:restart`). This is how the clock was set, and the digits go back to the top of the cycle. Idle,
  lifting it and letting go starts the timer.
- **The bird**: flick across it to turn its rod (a flick gives at most about 1.5 turns a second; the wheel's
  friction stops it).
- **The cymbal**: push it and it swings on its cord. **The axe or the mallet**: pull it and the spoon tips. Let go
  and the heavier handle brings the mallet down.
- **The vase**: tap it to drop a ball in: the spoon, the blows and the cymbal follow.

Parts are found by their own painted outline (the atlas alpha, with a 7 px allowance for a finger). The sheet
keeps `touch-action: pan-y`, so a vertical swipe still scrolls the page and taps and sideways drags work the
machine. `data-touch="false"` makes it look-only.

Simplified, and why:

- The real clock has **two** falcons and serpents (right and left) and alternates them half hour by half hour,
  and the balcony man shifts from one to the other. The painter drew them overlapping in a single elevation, one
  serpent raised and one at its vase. The two are painted at different sizes, so only the one at the vase can turn on
  the axle and reach both the beak and the vase. Here it does the work every half hour, and the raised one waits, as
  painted.
- The 15-hole silver ring that counts the hours, and the tray of collected balls, are not painted on this folio, so
  they are not here either. The `cycle` index in the events carries the count.
- The falcon's hinged upper beak does not open, and the ball's run inside the castle (channel, wheel, balance) is
  hidden, as it is in the machine. Inside it is timed rather than rolled.
- The float's flow is regulated to land on the timer's boundaries, so the countdown stays exact. A real float could
  drift a little each half hour.

## How it was cut (offline, `tools/`)

Python, about 900 lines, `./tools/run.sh <stage>.py`. Sources go in the engine's job folder
(`tools/engine/jobs/elephant-clock-src`, see `credits.json` for the URLs).

1. `sheet.py`: the Met photograph (DP234075, 2522 × 3596) is cut off its mount by distance from the mount's flat
   colour, so the sheet keeps its own worn left edge and its repairs. It also builds the paper's local colour.
2. `cutparts.py` + `parts.py`: each moving part is a loop of waypoints. Where a part meets another painted thing
   (the serpent's neck against the pillar, its wing against the coil, its claw against the other claw), the boundary
   snaps to the painter's own ink line: a livewire, the cheapest path through a black-top-hat ink map. Where it meets
   bare paper, the loop is loose and the paper is subtracted, so the part keeps its own painted edge, whiskers
   included. The scribe's lead-white robe has flaked to the paper, so his whole silhouette is kept instead.
3. `clean.py`: what lay under the parts. All holes are filled at once. The left pillar is rebuilt row by row from its
   own plain shaft, cycled with cross-faded seams. The coil of the serpents' tails is restored in polar coordinates
   about its centre, carried round from the same radii a little further along the ring. Paper gets its slow tone
   from a membrane fill of the surrounding paper, and its fibre and mottle from bare paper of the same manuscript (this folio's margin
   and the margins of two sister folios, the mahout 55.121.13 and the Peacocks 55.121.15, at the same 126-134 px/cm),
   contrast-matched, in tent-blended patches. Only a band a few pixels wide beside painted edges uses OpenCV's frequency-selective
   reconstruction.
4. `export.py`: at 1600 px wide, each part's colour is solved so that `clean·(1−a) + F·a = folio` exactly, so a part
   at rest over the clean plate is the folio. Everything packs into one atlas with the clean patches, four occluders
   the ball passes behind (falcon's beak, vase, near foreleg, foot) and the mahout the serpent passes behind, plus
   the ball itself, from the Peacocks folio.

## Runtime

Canvas 2D, about 900 lines, no libraries. A fixed-step world (1/240 s) holds the float, the serpent, the spoon, the
cymbal, the bird's rod, the balcony man and any number of balls. Every part on the canvas is a rigid turn about its
pivot, or a card turn about a vertical axle (scribe, bird), applied to its atlas piece over a cached base (the folio
plus its clean patches, drawn once per size). The chain slides inside its own corridor. The animation loop runs only
while something is moving: a ball, a swinging cymbal, a hand, the serpent. Between half hours the canvas is redrawn
once a second as the float sinks. Offscreen or in a hidden tab it does not draw. Coming back after a long gap, the
machine is put where it would have come to rest. Time comes from the clock, not from frames.

Tests and screenshots: `clock.hold(true)` stops the loop, and `clock.advance(seconds)` steps the world and the timer
forward exactly. `clock.world()` exposes the state, and `clock.hit(x, y)` says which part is under a point.

## Options

| Option | Attribute | Default | |
|---|---|---|---|
| `duration` | `data-duration` | `25m` | `90s`, `25m`, `1h30m`, or ms. Counts down from `start()`. |
| `until` | `data-until` | | An ISO date-time. Counts down to it from load; no start/pause. |
| `cycle` | `data-cycle` | the duration up to 30 min, else `30m` | One sinking of the float (minimum 10 s). |
| `autostart` | `data-autostart` | `false` | Start a duration timer at once. |
| `touch` | `data-touch` | `true` | `false`: the folio is look-only. |
| `src` | `data-src` | `clock.json` beside the image | The clock's geometry. `parts.webp` sits beside it. |
| `doneText` | `data-done-text` | `Time is up.` | What the live region says at the end. |
| | `data-label-start/pause/resume/again` | `Start`, `Pause`, `Resume`, `Again` | The toggle button's words. |

Layouts: `.ec-wide` puts the folio and the digits side by side from 860 px; `.ec-small` makes the folio a thumbnail
beside the digits. Without either, they stack.

## Theming

Uses `--paper`, `--ink`, `--ink-3`, `--accent` (the digits at the end), `--serif`, `--sans`.

| Variable | Default | |
|---|---|---|
| `--ec-sheet` | `min(100%, 560px)` | The folio's width. |
| `--ec-size` | `clamp(48px, 13cqi, 96px)` | The digits. |
| `--ec-gap` | `clamp(18px, 4cqi, 40px)` | Between folio and face. |

## Accessibility

The digits are a `<time>` with an ISO `datetime`, updated each second. Label it with `aria-labelledby`. A polite live
region (role `status`) speaks only at sensible moments: on start, pause and reset, every 5 minutes, then every
minute in the last five, every half hour on long countdowns, and the done text. The buttons are real buttons, 44 px
tall, with `aria-pressed` on the toggle. The canvas is `aria-hidden`. Give the image real `alt` text, or `alt=""` on a
second copy. In forced colours the canvas is hidden.

**Reduced motion:** nothing moves by itself. Every step the machine is put where it would come to rest: starting
sets the serpent raised at once, each half hour happens with no ball in flight, no turning bird and no swing, and the
scribe still shows the progress as the float sinks. Your own hand still works the parts.

## Cost

Assets 1.3 MB: the folio 720 KB (it is also the page's image), the atlas 310 KB, the JSON 3 KB, two sounds 255 KB
(loaded only if the visitor turns sound on). Idle: nothing runs and no canvas is shown. Running between half hours:
one redraw a second. While anything moves (about 8 s each half hour, or while a hand is on it): up to 60 physics
steps and one draw a frame (a cached base blit and about 12 sprites), DPR capped at 2.

## Credits

The folio: *The Elephant Clock*, folio from a *Book of the Knowledge of Ingenious Mechanical Devices* by al-Jazari,
Farrukh ibn ʿAbd al-Latif, probably Syria or Iraq, dated 715 AH / 1315 CE. The Metropolitan Museum of Art, 57.51.23, Bequest of Cora
Timken Burnett, 1956, CC0. The ball: the gold disc of *Design for the Water Clock of the Peacocks* from the same
manuscript, Met 55.121.15, CC0. Sister folios 55.121.13 (the mahout with his pivoted arms and the spoon) and
55.121.11–14 were references for the mechanism and the hand. See `assets/credits.json`.

Sounds (off until turned on, `sound.js`): the cymbal is earshot's `fit/bell/small_bell`, fitted from "Small Bell #2" by
steffcaffrey (CC0); the blows are `fit/hit/bamboo_tok`, fitted from "Bamboo hit" by michorvath (CC0). See `sounds.json`.

Reference: Ibn al-Razzaz al-Jazari, *The Book of Knowledge of Ingenious Mechanical Devices*, translated and
annotated by Donald R. Hill (Dordrecht: Reidel, 1974), Category I, chapter 4.

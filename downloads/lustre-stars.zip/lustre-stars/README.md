# lustre-stars

A rating made of real Kashan lustre tiles. The picture is one photograph of five eight-pointed star tiles and the
four cross tiles locked between them (13th–14th century, The Met). Each star is a radio button. Choose a value and a
lamp held by someone standing to your left lights the tiles up to it. Their lustre, the metallic film fired onto
the glaze, flashes gold and copper the way it does as you walk past a real wall. Tiles past the value stand in the
shade. Nothing moves but the light.

```html
<link rel="stylesheet" href="lustre-stars.css">

<fieldset class="ls" data-lustre-stars>
  <legend class="ls-legend">How was it?</legend>
  <div class="ls-frieze">
    <img class="ls-img" src="assets/frieze.webp" alt="" width="2400" height="766">
    <input class="ls-in" type="radio" name="rating" value="1" id="rate-1" required><label class="ls-t" for="rate-1"><span>1 of 5, poor</span></label>
    <input class="ls-in" type="radio" name="rating" value="2" id="rate-2"><label class="ls-t" for="rate-2"><span>2 of 5, fair</span></label>
    <input class="ls-in" type="radio" name="rating" value="3" id="rate-3"><label class="ls-t" for="rate-3"><span>3 of 5, good</span></label>
    <input class="ls-in" type="radio" name="rating" value="4" id="rate-4"><label class="ls-t" for="rate-4"><span>4 of 5, very good</span></label>
    <input class="ls-in" type="radio" name="rating" value="5" id="rate-5"><label class="ls-t" for="rate-5"><span>5 of 5, excellent</span></label>
  </div>
  <output class="ls-say" aria-live="polite"></output>
</fieldset>

<!-- read-only: a partial value lights part of the last tile -->
<div class="ls ls-read" data-lustre-stars data-value="4.2" role="img" aria-label="Rated 4.2 out of 5">
  <div class="ls-frieze"><img class="ls-img" src="assets/frieze.webp" alt="" width="2400" height="766"></div>
</div>

<script type="module" src="lustre-stars.js"></script>
```

The radios are real. Keep them in this order: input, then its label, five times. The CSS places each label over
its own star, and the value posts with the form. Or call `lustreStars(root, options)` yourself. It returns
`destroy()`, which also carries `hold(value, x)` (light the frieze as if that star were hovered, the lamp aimed at
`x` in 0–1; `hold()` releases) and, on a read-only frieze, `set(value)`.

## In life / Here

| In life | Here |
|---|---|
| Kashan potters (the Abu Tahir family among them) painted lustre over an opaque white or cobalt-and-turquoise glaze and fired it a second time in a smoky, reducing kiln, leaving a film of silver and copper particles well under a micron thick. | The tiles are photographs of real ones: five stars (41.165.20, .23, .18, .11, .13) and four crosses (.37, .32, .33, .39), The Met, cut from one photograph along their own joints. Nothing is drawn. |
| Stars and crosses were set together in dados and on tomb walls (Imamzada Yahya at Varamin, 1262; the Ilkhan palace at Takht-i Sulaiman, 1270s). The crosses' arms fit between the stars' points. Each tile was set by hand, a degree or two off its neighbours. | The setting is the panel's own, photographed square-on. Each tile is given a small random tilt (σ ≈ 1.7°) and a rounded rim from its own outline, so no two tiles catch alike. |
| No two tiles are alike: animals, trees, palmettes, interlace, with verses (often from the *Shahnameh*) or Qur'anic text round the border. | Five different stars: an arabesque, a dappled ass, an interlace, a flowering tree, a palmette. The inscription bands are as photographed. |
| Lustre is dull brown in flat light and flashes metallic when a lamp or window reflects off it at the right angle: gold on olive and amber film, copper on red-brown, with a blue-violet sheen at the edge of the reflection. The bare glaze gives back a small white glint. | Per pixel, where the painter laid film (and how thick it looks) was baked offline. The shader reflects a lamp off each tile: the film in its own colour pushed toward metal, a faint blue-violet shoulder, and a white glint on bare glaze. The colours were set against The Met's own low-angle photographs of these tiles. |
| A person with a lamp standing to the left lights the near tiles and not the far ones. | The chosen value is how far the lamp's light reaches. The edge falls between stars, across the cross between them, soft like a door jamb's shadow. Hover previews another value, and the lamp follows the pointer. |

No transformation: the tiles are never "fired" or gilded on the page. The light only reaches them, or doesn't.

## Options

| attribute | option | default | |
|---|---|---|---|
| `data-tiles` | `tiles` | `<img name>-tiles.png` | the baked data (same origin) |
| `data-value` | `value` | — | read-only frieze: the value, 0–5, fractions allowed |
| `data-lamp` | `lamp` | `1` | 0–2, the lamp's strength (the demo's small read-only friezes use `.55`) |
| `data-distance` | `distance` | `1.6` | how far away you stand: `distance` × 1.2 frieze widths, at every size, so a phone's pools are a desktop's. Nearer = the lamp's reflection is a smaller pool that travels further across the tiles as you move |

The options object wins over the attributes.

## Theming

| variable | default | |
|---|---|---|
| `--ink` | `#141312` | the focus mark under a star |
| `--ink-3` | `#8a857d` | the stated value (`.ls-say`) |
| `--sans` | system | the stated value's font |

Size it by its width: the frieze keeps the photograph's ratio (2400 × 766). Each star is 20% of the width, so keep
the frieze at least 230 px wide where it is a control: 44 px targets at 220 px. The demo's form frieze is
`max-width: 640px` and full column width on a phone (~354 px, stars ~72 px).

## How it works

**Offline** (`tools/`, Python, not loaded by the page; `tools/bake.sh` reruns it).
- **The cut.** Tiles vs wall from chroma and texture against the grey wall's own colour. Each star is fitted as an
  affine eight-pointed star (two squares), and each of its sixteen straight edges is snapped along its normal to
  where the glaze's bright rim drops into a neutral gap. A compact watershed on "neutral darkness" (the joints are
  grey shadow; the painting is coloured) then separates all fourteen tiles. Each kept region is clipped to its
  fitted shape. The crosses' edges that met the removed top row are snapped inward to their own rim. Checked at
  1:1 on every joint.
- **The shadow.** The wall's own darkening in the photograph, relative to a smooth fit of the lit wall. It is kept
  only where a kept tile could have cast it (the photograph's light is upper left), and filled where the brass
  hanging tabs had been.
- **The data**, one lossless grayscale PNG, two images of the albedo's size (2400 × 766) stacked (0.81 MB):
  - top: height, 1/32 px a step: a rounded rim from each tile's own distance-to-edge (1 − e^(−d/9 px)) plus the
    glaze's relief, band-passed from the photograph (σ 2.2–10 px). The runtime takes its slope as the normal.
  - bottom: tile id in the high nibble (0 = wall, 1–5 the stars left to right, 6–9 the crosses); lustre density in
    the low nibble.
  - Each tile's hand-set tilt (σ 0.03) is nine numbers, `TILT` in the runtime. Density is how far a pixel sits below its own tile's bare glaze (each tile's 93rd-percentile
    lightness, since these glazes photograph warm), excluding the in-glaze cobalt and turquoise by hue.

**Runtime** (`lustre-stars.js`, one fragment pass, WebGL 1).
- At each size the photograph is resampled once to the canvas. The data is box-filtered on the CPU to the same size
  (height and film averaged, tile id by majority) and the normal taken from the height's slope there, so the relief
  never aliases into sparkle.
- **Reach.** Each tile has a start along the value: star *k* at *k* − 1, each cross half a step before the star to
  its right. The light's edge sweeps across a tile as the value passes through it. The fraction is mapped by area
  (f + 0.1 sin 2πf), so 4.2 lights a fifth of the fifth star's face. The edge is soft over about 1% of the width: a jamb's shadow, not a fade.
- **The lamp.** The eye stands 1.6 × 1.2 frieze widths out, drawn a quarter of the way toward the middle
  of the screen, so the sheen slides as the page scrolls. The lamp stands at the same distance, opposite the eye
  about the point it is aimed at, so its reflection pool falls there. Unpointed, it aims at the middle of what it
  reaches; hovering, at the pointer (clamped to the lit part).
- **Materials.**
  - Film: a lobe on the half-vector of width² 0.0022, narrower than the tiles' spread of tilt, so some tiles catch
    and some don't. It reflects in the film's own colour pushed toward gold or copper. Add to that a faint broad
    sheen (width² 0.05) and a blue-violet shoulder (width² 0.012) where the film is thick.
  - Bare glaze: a white glint (width² 0.0007).
  - The lit tile is the photograph at 0.98–1.04; past the reach it is the photograph at half the exposure, and no
    lobe of any kind (they are multiplied by reach², so the penumbra never glints, whatever the tilt). Highlights
    roll off toward white instead of clipping.
- **Springs.** The value and the lamp's aim each run on a critically damped spring (periods 0.42 s and 0.6 s) at a
  fixed 120 Hz step.
- **Phone.** A tap checks the radio. Tilting the phone turns the wall under the lamp (up to 0.12 rad, via
  `tilt.js`), so different lit tiles catch; tiles past the value never do.

## Behaviour and cost

- Draws only while something moves (the value or the lamp easing, a scroll, the tilt), and only on screen. Idle,
  nothing runs.
- Assets: `frieze.webp` 0.61 MB, `frieze-tiles.png` 0.81 MB (downloaded once and cached; each frieze reads it).
  The data is box-filtered once per size (about 20–60 ms for a desktop-size frieze).
- Canvas DPR is capped at 2 and never finer than the photograph.
- One WebGL context per frieze. The demo has four.

## Accessibility and reduced motion

- A `<fieldset>` with a `<legend>` and five native radios. Tab enters the group, arrow keys change the value, and
  it posts with the form (`required` works). Each label's text ("3 of 5, good") is in the tree.
- The `<output aria-live="polite">` states the value in words.
- Focus shows as a short ink rule under the focused star, never as an outline or glow on the tile.
- The value reads without the light: the stated value, the labels, and the radios themselves. In forced-colours mode
  the real radios and their text appear in a row under the picture.
- Without JS, WebGL or the data: the photograph stays, and the stars past the choice stand in a quiet CSS shade cut
  to each star's own outline (`clip-path`, measured).
- `prefers-reduced-motion: reduce`: the value lands at once, with one still frame and the lamp aimed at the middle
  of its reach. Pointer and tilt don't move the light.
- The images are `alt=""`, the canvas is `aria-hidden`. A read-only frieze is `role="img"` with an `aria-label`.
- Print shows the photograph.

## Honest limits

- The panel itself is a museum assembly (The Met, 1974). The tiles are 13th–14th-century Kashan, but this
  arrangement of these nine is the museum's, not a building's. The star-and-cross setting is right.
- The tilts and the rim are modelled, not measured: these tiles were photographed once, square-on. Lustre density
  is read from colour, so a very dark cobalt can pass for thin film in places.
- A fifth of a star's area is its left point and a little more (28% of its width), so a partial value wants the
  frieze at 280 px or wider to read. The read-only frieze at 150 px is small for the drawing. It works as a pattern of light, not as five pictures.

## Credits

See `assets/credits.json` and `assets/PICK.md`.
- Photograph DP231256: The Metropolitan Museum of Art, the 91.1.106 panel group, tiles from the H. O. Havemeyer
  Collection, Gift of Horace Havemeyer, 1941 (41.165.11, .13, .18, .20, .23, .32, .33, .37, .39). CC0.
- Lighting structure from `components/gold-ground` (per-pixel material baked offline, one fragment pass,
  drawing only while something moves); `tilt.js` from the same piece.

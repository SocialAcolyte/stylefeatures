# handscroll

A Chinese handscroll that you read the way one is read: right to left, an arm's length at a time. The scroll is Zhou
Chen's *Beggars and Street Characters* (周臣, 流氓圖), painted in Suzhou in 1516 and now in the Cleveland Museum of Art
(1964.94, CC0). Zhou painted it as an album of twenty-four figures, one to a leaf; it was later mounted as two
handscrolls, and Cleveland's half holds twelve leaves, his own inscription, colophons by three later readers and a
frontispiece. Those are the slides: the scroll's own sections, each a real `<img>` cut at the scroll's own seams.
A page can mount leaves of its own between them, with its own words, links and lists on them.

Two ways to use it:

- **A scroll scene** (`data-mode="scene"`). In the page the scroll lies closed, its brocade wrapper and Zhao Heqin's
  title slip up and its ribbon beside it. As you reach it and keep scrolling, it pins and opens. The closed scroll
  rolls to the left until its free edge comes round underneath, lays the start out to its right (the damask, the
  gold-flecked strip, the silk), and the stave begins to wind the start into a right-hand roll. After that, the page
  scroll unrolls it section by section. The page's own leaves (an About, a list of books, opening hours, a colophon
  with the contact address) are mounted between Zhou's openings and roll out with it.
- **A carousel** (`data-mode="carousel"`, the default): it lies open, and Unroll, Back, dragging the paper,
  tapping a roll or the arrow keys move it a section at a time.

The flat paper you look at is always the `<img>`s, and the page's leaves are HTML. Only the rolls and the ribbon are
drawn, on a WebGL2 canvas over the ends: each roll is a strip of the scroll's own paper wound on a cylinder, in the
light measured on Cleveland's photograph of this scroll rolled up. For its first turn the strip is the brocade wrapper
and title slip as Cleveland photographed them laid flat; after that it is the end paper.

```html
<link rel="stylesheet" href="handscroll.css">
<section class="hs hs-scene" data-handscroll data-mode="scene" data-title="Zhou Chen, Beggars and Street Characters, 1516"
         aria-roledescription="carousel" aria-label="Beggars and Street Characters">
  <div class="hs-stage">
    <div class="hs-scroll" role="group" aria-label="The scroll. It reads from right to left.">
      <ol class="hs-track">
        <!-- the start of the scroll, first: part of it, not a slide -->
        <li class="hs-start" style="--w:2970" aria-hidden="true"><img src="assets/s/start-900.webp" srcset="… 2x" alt=""></li>
        <!-- the scroll's sections, in reading order; --w is each one's width in the 1600 set -->
        <li class="hs-slide" style="--w:3614" aria-roledescription="section" aria-labelledby="c00">
          <img src="assets/s/00-900.webp" srcset="assets/s/00-900.webp 1x, assets/s/00-1600.webp 2x" width="3614" height="1600" alt="…">
          <span class="hs-label" id="c00">Title, written by Zhao Heqin in 1962</span>
        </li>
        …
        <!-- a leaf of the page's own, between two of Zhou's openings (keep --w at about 1100 or less) -->
        <li class="hs-slide hs-sheet" id="about" style="--w:1100" aria-roledescription="section" aria-labelledby="about-l">
          <div class="hs-words"><p class="hs-mark">About</p><h2>We publish slowly</h2><p>…</p></div>
          <span class="hs-label" id="about-l">About</span>
        </li>
        …
      </ol>
    </div>
    <div class="hs-bar">
      <button class="hs-btn" type="button" data-hs="next" aria-label="Next section">… Unroll</button>
      <p class="hs-caption" aria-hidden="true"><span class="hs-count"></span><span class="hs-title"></span></p>
      <button class="hs-btn" type="button" data-hs="prev" aria-label="Previous section">Back …</button>
    </div>
  </div>
</section>
<script type="module" src="handscroll.js"></script>
```

Links anywhere on the page to a leaf (`href="#about"`) scroll the page to where the scroll lies open at it.
`demo.html` is a small press's site built this way; `carousel.html` is the carousel.

```js
import { handscroll } from './handscroll.js';
const hs = handscroll(el);                  // also auto-starts on [data-handscroll]
hs.next(); hs.prev(); hs.go(5); hs.index;   // carousel: moves it; scene: scrolls the page to that section
el.addEventListener('handscroll:change', (e) => e.detail);   // {index, count, label}
hs.destroy();                               // removes the canvas, listeners and observers; back to the plain row
```

Without JS it is the row of sections, scrolling sideways and starting at the right end. Laid edge to edge, the
sections are the scroll again, with the page's leaves in it. Without WebGL2 it is the same row with the buttons
working. With reduced motion, a scene is the carousel: nothing pins and nothing moves by itself.

## In life, and here

| In life | Here |
|---|---|
| A handscroll is read on a table, from right to left. The left hand unrolls about an arm's length (some 60 cm); the right hand rolls up what has been seen. The picture comes in parts, as a journey. | On a desk the window is about an arm's length of this scroll; on a phone it is one leaf and a little of the next. In the scene the page scroll does the unrolling. In the carousel Unroll does (it is on the left, because the scroll is read leftward); pull the paper to the right to unroll it, or tap a roll. ← unrolls and → rolls back. |
| Closed, the scroll is wound on its roller, the start outermost. A brocade wrapper covers that outside, with the title slip pasted on it and the ribbon tied at the stave. | The closed scroll is the wrapper as Cleveland photographed it laid flat (alt13): brocade, Zhao Heqin's slip (周臣流氓圖, 1962) and the stave's folded edge, wound once round a cylinder of the measured size, slip up. The ribbon beside it is cut from Cleveland's photograph of the closed scroll (alt18), and lies where it falls in that photograph. Cleveland's rosewood weight lay on the wrapper's bottom corner; that corner is restored from the same weave one repeat away (the brocade is a regular weave), with the title slip clear of it. |
| To open it, the closed scroll is rolled away from you along the table, here to the left. Its free edge comes round underneath and is laid down, and the start of the scroll lies out to the right as the roll goes on. | That, as you scroll: first the closed scroll rolls as one piece until its free edge is under it (the title slip turns away over its left side), then it lays the start out to its right. It rolls over its own ribbon, which ends up under the paper, as it would. The view keeps the scroll centred, so the free edge travels right while the roll travels left. Then the stave starts winding the start up on the right. |
| The start is plain mounting: silk, a strip of gold-flecked paper, a length of damask. | The start is Cleveland's two photographs of it (alt15, alt14), from the same shoot as the full scan. They are matched to the scan and to each other by correlation (0.92 and 0.64), and each is scaled so its silk edges lie on the scan's. Where they meet the scan, one gain per channel, fitted on the white silk both show, brings them to the scan's colour. They are cut 3.4 cm short of the stave, where the weight lies on the damask in both. Cleveland's own whole-scroll stitch (alt12) puts the stave 9034 px beyond the scan; this start is 8516 px. |
| Zhou Chen painted twenty-four street people in 1516, "one to a leaf", as an album. It was later mounted as two handscrolls (Cleveland and Honolulu). | The twelve figure slides are the twelve leaves, cut at their own seams in Cleveland's scan. They were mounted in pairs, so the joins between album openings are strong and the folds within them faint. Both are visible in the scan, and both were found by measurement and then checked by eye. |
| A mounted scroll is a row of separate pieces: the frontispiece, the painting, the artist's own words, and the colophons later owners and friends wrote, each on its own paper between silk separators, with their seals. Albums often faced each painting with a leaf of writing (對題). | Zhao Heqin's frontispiece (1962), Zhou's inscription across the album's last opening (autumn 1516), and the colophons of Huang Jishui (1564), Zhang Fengyi and Wen Jia (1577) are sections of their own. The page's own leaves are mounted where a mounter would put them: between Zhou's openings, as facing leaves, and after the colophons, as the newest colophon. They are this scroll's own blank end paper between two strips of its own white silk, laid on the edges of the section they are joined to. Zhou's leaves stay untouched and in order. |
| Rolled up, the painting faces in: what shows on the outside of each roll is the back of the mounting. Each turn is the thickness of the mounting. | Both rolls are wound face in. Each roll's outside is the back of the paper wound last (on the right) or about to come off (on the left), and it moves with the paper, so the rolls turn as it moves. The wrapper is the back of the start, so the right roll begins in brocade and the left one sheds it. The size of each roll comes from how much scroll is on it. The closed scroll is 5.05 cm across in Cleveland's photograph, which gives 5.5 px of scan per turn. The page's leaves add their own length, so with them the closed scroll is a little thicker than Cleveland's and its wrapper a little longer. |
| The back of a mounted scroll is plain backing paper. | Cleveland photographed only a strip of this scroll's back, too narrow to wind. The rolls are wound in its blank end paper instead (alt11), at the scan's own scale. |
| The rolls catch the light. | The light across each roll is measured on the photograph of this scroll rolled up (alt18), below the title slip and clear of the stave's fold. Cleveland lit it from the left: the left flank is brighter than the crown and the right a little darker. Nothing else is shaded. |
| This scroll's roller has flush ends; its ribbon has no clasp. | So there are no knobs and no clasp: nothing is borrowed from another scroll. |
| The scroll's edges are its silk borders. | The table is matted out along the scroll's own silk edge. Cleveland's scan drifts about 40 px over its length. The scan is not straightened; each roll and each page leaf is set on the paper's own edge where it touches. |

## How it is made

From Cleveland's own files, all CC0: the full scan (64714 x 4862, 944 MB) and the photographs of the same scroll's
wrapper (alt13), start (alt14, alt15), end paper (alt11), closed scroll (alt18) and whole mounting (alt12, for its
lengths). See `assets/PICK.md` for the hunt and `assets/credits.json` for every file.

- `tools/sections.py` cuts the 17 sections from the full scan. The whole scroll is resampled once to 1600 and 900 px
  tall and cut at whole pixels at the seams and separators, so the sections laid edge to edge are the scroll again.
- `tools/start.py` makes the start from alt15 and alt14.
- `tools/wrapper.py` makes the wrapper strip (with the weight's corner restored) and the silk strip.
- `tools/rolls.py` makes the backing strip and the ribbon (as it lies, and turned for the carousel). It also measures
  the light across the roll, the paper's edges along the scroll and the scroll's build, and writes `assets/scroll.json`
  (keeping what the other two add).

## Runtime

About 580 lines, no libraries. The track of `<img>`s (and the page's leaves) is moved with a transform and clipped
to the window between the rolls; one WebGL2 context draws the rolls and the ribbon. Each roll is a textured strip
across the visible half of a cylinder. Every column of it is at the cylinder's projected x and carries the paper
position that lies there and the measured light, in runs that change texture where the wrapper ends.

- **Carousel stops** are worked out from the sections' own edges and the rolls' radii, so the section you go to starts
  exactly at the right roll. A critically damped spring takes it there.
- **The scene** sets its own height (the pinned runway) from the scroll's length and maps the page scroll straight
  to the paper: a short hold, the roll, the laying out, then the unrolling at 1.25 page px per paper px.
- **The loop** runs only while something moves, and not when the scroll is off screen.

## Options

| Option | Attribute | Default | |
|---|---|---|---|
| `mode` | `data-mode` | `carousel` | `scene`: closed in the page, opened and unrolled by the page scroll (pinned). |
| `start` | `data-start` | `0` | Carousel: the section to open at. |
| | `data-title` | | Scene: what the caption says while the scroll is still rolled up. |
| `src` | `data-src` | `../scroll.json` beside the images | The geometry. The textures sit beside it. |

## Theming

Uses `--ink`, `--ink-2`, `--ink-3`, `--accent` (focus), `--serif`, `--sans`.

| Variable | Default | |
|---|---|---|
| `--hs-h` | one leaf wide on a phone, up to 520 px on a desk | The scroll's height on the page. |
| `--hs-max` | `520px` | The tallest it gets. |
| `--hs-gap` | `clamp(14px, 3cqi, 26px)` | Between the scroll and its caption. |
| `--w` (on a leaf) | | Its width in the 1600 set. |
| `--paper-x` (on a page leaf) | `0%` | Which part of the end paper it is cut from (so neighbouring leaves differ). |

## Accessibility

A `section` with `aria-roledescription="carousel"` and a label. The sections and page leaves are a real ordered list,
each with its own label, and the figures each have a full `alt`. The buttons are real buttons, 44 px tall, disabled at
the ends.

- **Carousel:** the scroll itself is focusable (role `group`, labelled) and takes ←, →, Home and End. The caption is a
  polite live region ("3 of 17, A monkey trainer").
- **Scene:** nothing speaks while you scroll; the content is all in the page. Tabbing to a link on a page leaf, or
  following one, brings the page to where that leaf lies open.

The canvas is `aria-hidden` and hidden in forced colours. **Reduced motion:** the carousel, with each step landing at
once; dragging still moves the paper under your hand.

## Cost

Sections 1.5 MB at 900 px (1x screens) or 6.4 MB at 1600 px (2x and 3x), loaded a few at a time ahead of the paper.
The start is 1.3 MB at 1600 px or 0.36 MB at 900 px (damask weave does not compress), and the textures (wrapper, end paper, silk, ribbons) about 870 KB. Idle: nothing runs.
Moving: one transform and one canvas draw a frame (up to six strips and a quad), DPR capped at 2.

## Credits

Zhou Chen 周臣 (c. 1450–c. 1536), *Beggars and Street Characters*, 1516, handscroll, ink and light colour on paper,
31.9 x 244.5 cm. The Cleveland Museum of Art, John L. Severance Fund, 1964.94, CC0. Frontispiece and title slip by Zhao
Heqin (1962); colophons by Huang Jishui (1564), Zhang Fengyi and Wen Jia (1577). Translations of the inscriptions:
Cleveland's own record. The demo's press, Idle Window, is made up; its name is from Zhou's note ("閒窗", idle at my
window). See `assets/credits.json`.

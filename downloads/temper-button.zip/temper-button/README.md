# temper-button

A button with a face of ground steel: a click leaves a bloom of straw where you pressed, a longer press runs on through gold and brown to purple, and a moment later the face is rubbed bright again. As a hold-to-confirm button, it fires when the steel under your finger turns blue.

This is the button part of temper-run and nothing else. It comes in two kinds:
- a **plain button** (Save): it clicks like any button, and the steel shows where it was pressed;
- a **hold-to-confirm button** (Hold to discard): it fires only when the colour under the press reaches blue.

temper-run's bar, rule, frame and engraving are not here, and nor is its tilt (see [No tilt](#no-tilt)). The steel is temper-run's own engine, file for file and unchanged (`temper-run.js`, `temper-run.css`, `tilt.js`). `temper-button.js` and `temper-button.css` are this folder's own: they start the engine's button kind on `button[data-temper-button]` and add what a button needs that the engine leaves out (see [What temper-button.js adds](#what-temper-buttonjs-adds)).

```html
<link rel="stylesheet" href="temper-run.css">
<link rel="stylesheet" href="temper-button.css">
<!-- a still tilt for the engine (see "No tilt"); before any module script -->
<script type="importmap">{"imports":{"./tilt.js":"data:text/javascript,export default{x:0,y:0,active:false,listeners:new Set}"}}</script>
<script type="module" src="temper-button.js"></script>

<!-- a plain steel button -->
<button data-temper-button type="submit">Save</button>

<!-- hold to confirm: 1.4 s of held press runs the colour under the finger to blue -->
<button data-temper-button data-hold="1400" data-to="blue" type="button">Hold to discard</button>
```

The module starts every `button[data-temper-button]` on the page when it loads. Load `temper-button.css` after `temper-run.css`.

```js
import { temperButton } from './temper-button.js';
const t = temperButton(button, { hold: 1200, to: 'purple' });
t.state;                // cold | heating | coasting | resting | confirmed
t.speed;                // how fast this steel runs (a plain button's comes from its width)
t.reset();              // rub the face bright now
t.thicknessAt(.5, .5);  // oxide (nm) under a point of the face: 0..1 across, 0..1 down
t.step(1 / 60);         // advance by hand (tests, stills); the clock stays manual afterwards
t.engine;               // the temper-run handle underneath
t();                    // destroy (also t.destroy()): canvas, listeners, observers, live region and hint go; the plain button stays
```

`button.__temperButton` is the same handle, and calling `temperButton()` again on a live button replaces it.

## Sizes

A button sizes itself from its padding and font, like any button, and the steel follows.

| Class | CSS | Height |
|---|---|---|
| `tb-sm`, a row button (settings, toolbars) | `font-size: 13px; padding: 10px 15px 12px` | 37 px |
| none, normal | `font-size: 15px; padding: 15px 26px 17px` | 49 px |
| `tb-lg` | `font-size: 17px; padding: 20px 38px 22px` | 61 px |

- For another size, use a selector at least as specific as `button[data-temper-button].tb-sm`.
- Keep 2 px more padding below than above: the steel's narrow side face takes it.
- Bigger costs more. While it colours, the face is painted on the CPU every frame, about half a microsecond per device pixel (DPR capped at 2). Measured on a desktop CPU: Sign out (`tb-sm`, 84 × 37) 7 ms a frame and Save (90 × 49) 10 ms, both at 60 frames a second; Load more (`tb-lg`, 166 × 61) 21 ms, about 45; a `tb-lg` with a long label (233 × 61) 31 ms, about 30; a hero of 358 × 92 (26 px type) 70 ms, so its bloom steps at about 14 frames a second. A phone is slower. For a hero, use `tb-lg` with a short label, or accept a stepped bloom.
- Labels do not wrap (`white-space: nowrap`), so let the row around them wrap.
- The steel is a canvas inside the button. To change a label, change an element inside it (a `<span>`), never `button.textContent`, which would remove the canvas.
- A long press spreads over the face as the heat does, and a narrow face fills sooner. So a plain button's default speed follows its width (see `speed`): on Save (90 px) a click leaves pale straw under the press (13 nm), and half a second's press stays a band of straw and gold with bright ends (11 nm). After about a second of holding, a face under 100 px or so is straw to gold from end to end with a bronze to purple core. Wider ones keep bright ends for longer.

## Events and states

| Event | When |
|---|---|
| `temper-run:state` | Every change of state. `detail` is `{ state, from }`. |
| `temper-run:confirm` | A hold button: the colour under the press reached `data-to`. |
| `temper-run:cancel` | A hold button: let go before that. `detail.reason` says how: `release` (let go too soon), `slide` (slid off), `blur` (focus left it), `scroll` (the touch became a scroll: say nothing, and the face is rubbed bright straight after), or `click` (a click with no press behind it, as a screen reader in browse mode, voice control or `el.click()` sends: tell the visitor to press and hold). |
| `click` | A plain button clicks as any button does, and sliding a mouse or pen off it before you let go cancels the click. A hold button clicks once, on confirm: its native clicks (single clicks, Space, Enter, key repeat, implicit form submission) are stopped, so a hold button with `type="submit"` submits on confirm. If your `temper-run:confirm` handler disables the button, that click, and a submit, do not happen (a disabled button can't be clicked): act on `temper-run:confirm` itself, as the demo does, or disable it a moment later (`queueMicrotask(() => b.disabled = true)`). |

All of them bubble. The engine's own cancel has no detail, so the wrapper stops it at the button and sends this one: a capture listener on an ancestor would see both. The states, on `t.state` and as `data-state` on the button:
- `cold`: bright.
- `heating`: the heat is on: while it is pressed, and for at least a quarter of a second after a quick click. While the press lasts the button also has the class `tr--pressed` and sits a pixel lower.
- `coasting`: let go; the colours still run on the heat left in the steel.
- `resting`: the colours have stopped and stay as a record until the face is rubbed bright (`cold` again).
- `confirmed`: a hold button reached its colour. It stays confirmed until it is rubbed bright.

## Options

Data attributes, or the options object (which wins).

| Option | Attribute | Default | |
|---|---|---|---|
| `hold` | `data-hold` | off | Milliseconds of held press to confirm. A bare `data-hold` is 1200. A hold button doesn't act on a plain click: it sends `temper-run:cancel` with reason `click`. |
| `to` | `data-to` | `blue` with `hold`; `purple` without | Hold button: the colour at the press point that confirms. Plain button: how far a long press can take it. A colour name or nm. |
| `from` | `data-from` | `0` | Film already on the steel: `pale-straw` gives a warm blank. |
| `speed` | `data-speed` | plain: `1.4` to `2` by width; hold: `1` | How fast the steel heats and colours. A plain button's default follows the width of its face: 1.4 up to 100 px, rising to 2 at 140 px and wider (a button that starts hidden, or changes width, is retuned once its face is bright). At 1, the engine's own, a quick click leaves less than 12 nm of film, which still reads as bright steel. At 1.4 on a narrow face it leaves 13 to 15 nm, pale straw; at 2 on a wide one, about 19 nm, straw. At 2 a narrow face would be pale straw from end to end after half a second's press. A hold button confirms in `hold ÷ speed`, so leave it at 1 and set `data-hold`. |
| `reset` | `data-reset` | `1800` | Milliseconds after the colours stop before the face is rubbed bright. `0` keeps the record; a disabled one still dims once its colours stop (see [What temper-button.js adds](#what-temper-buttonjs-adds)). |
| `done` | `data-done` | `Confirmed` | Announced when a hold button confirms. `data-done=""` announces nothing: use it when the page says what happened itself, as the demo does. |
| `hint` | `data-hint` | `Press and hold to confirm` | A hold button's description for assistive tech. |
| `sheen` | `data-sheen` | `0.36` | Where the brushed highlight rests, 0..1 across. It follows the mouse (and the phone's tilt, if you bring it back: see [No tilt](#no-tilt)). |
| `seed` | `data-seed` | random | Fixes the grind marks. Give each hold button its own: the hint's id is made from it. |

Colour names, in the order the steel runs: `bright`, `pale-straw`, `straw`, `gold`, `brown`, `bronze`, `purple`, `dark-blue`, `blue`, `pale-blue`, `grey`.

Theming: on the button (a class on it), `--tr-ink` (`#1d1b18`) is the label colour and `--tr-fallback` (`#8c877e`) the no-JS edge. The steel's colours are not themeable: they are the physics.

## What temper-button.js adds

The engine is left as it is. Its wrapper adds:
- **Slide off to cancel.** The engine captures the pointer on a press, which would let a release anywhere still click the button and let a hold confirm while the mouse is held far off it. Once a mouse or pen goes more than 8 px off the button (a finger, 16 px), the wrapper lets the capture go, and the engine's own release runs: the heat stops, a hold button fires `temper-run:cancel`, and letting go there does not click. Slide back on and let go, and a plain button clicks, as a native one does. A finger usually pans the page first, which cancels the press too.
- **Why a hold was cancelled.** `temper-run:cancel` carries `detail.reason` (see [Events](#events-and-states)). A touch that becomes a scroll is not a press: the page can stay quiet about it, and the wrapper rubs the face bright 0.3 s later so scrolling past leaves no straw. A hold button stops plain clicks, so a click with no press behind it would otherwise do nothing and say nothing; it sends a cancel with reason `click`.
- **Busy.** With `aria-disabled="true"` the button keeps its focus and its place in the tab order. A press does not heat it, and its clicks (pointer, Space, Enter, implicit form submission) are stopped at the button, so its click listeners do not run. Use it while the work runs, as the demo's Load more does, and say so in the page: the demo's line reads "Loading…" and the cursor shows progress.
- **The colour is not dimmed.** `disabled` and `aria-disabled` dim the button to 55%, but not while its steel still shows a press: it dims, over 0.4 s, as the face is rubbed bright. A page that disables a hold button as it confirms (the demo's Discard) keeps the blue at full strength. With `data-reset="0"` the face is never rubbed bright, so a disabled one dims once its colours stop, and a confirmed hold button 1.2 s after it confirms, once its blue has been seen.
- **A visible click.** A plain button runs at 1.4 to 2 by its width unless you set `data-speed`.
- **Classes for the styles.** A hold button gets `tb--hold`, with its hold time (`hold ÷ speed`) in `--tb-hold`, and one that keeps its record (`data-reset="0"`, or `reset: 0`) gets `tb--keep`. `temper-button.css` uses them for the kept record's dimming and the forced-colours hold. They come off on destroy.
- **Buttons only.** `temper-button.js` itself starts only `button[data-temper-button]`. The engine it imports still starts any `[data-temper-run]` on the page, as temper-run does (a `<div>` becomes a steel rule), so don't use that attribute here.

## No tilt

temper-run moves its highlight with the mouse, and on a phone with the phone's tilt (`tilt.js`). A button keeps the mouse and leaves out the tilt, which costs more than it gives:
- Every small movement of the hand repaints every steel face on screen, on the CPU. In the demo at 390 px, with five buttons on screen and a hand drifting 1° every 3 s, that was 74 frames a second with long tasks of 50 to 67 ms (103 frames a second at 3° every 4 s). With the still tilt, nothing runs.
- On iOS, the first tap anywhere on the page (on Save, say) would open the system's motion-access dialog.

So the page hands the engine a still tilt, with the import map in the snippet at the top, as the demo does: `tilt.js` is not loaded and iOS does not ask. Put it before any module script. Its `"./tilt.js"` is read against the page, so it names this folder's `tilt.js`. From a page in another folder, give that file's path instead (`"/js/temper-button/tilt.js"`). If the page already has an import map, add the entry to it. If the page's Content-Security-Policy blocks `data:` scripts, or to make it permanent, replace `tilt.js` with the stub itself: `export default { x: 0, y: 0, active: false, listeners: new Set() };`. Keep the file: the engine imports it, and a missing one logs a 404. To bring the tilt back, leave the import map out.

## Accessibility

- A real `<button>`, in the tab order, named by its own text. The canvas is `aria-hidden`.
- Space and Enter press it like a finger, at the centre. Hold either key to confirm a hold button.
- A press can be taken back: slide a mouse or pen off before you let go (WCAG 2.5.2).
- A hold button is described by its hint (`aria-describedby`, added to any you set). The hint span is `aria-hidden`, so browse mode reads it once, as the description, not again as page text. The button announces `done` in a polite live region when it confirms. The page should still say what happened, as the demo's status lines do; then set `data-done=""` so it is not said twice.
- Screen readers in browse mode (NVDA, JAWS, VoiceOver's VO+Space) and voice control can only click, and a click doesn't confirm a hold button. It sends `temper-run:cancel` with reason `click`, so the page can say what to do (the demo says "Press and hold to discard"). To hold, a screen reader user switches to focus or forms mode and holds Space or Enter. Give an action that needs a hold another way back as well, as the demo's Undo does.
- The focus ring is a 1.5 px outline in `--tr-ink`, 5 px out, for keyboard focus only (Chrome draws it 1 px wide).
- `disabled` dims the button to 55% once its face is bright, and it can't be pressed. If the button has focus when you disable it, move focus first (the demo moves it to Undo, and to the list it loaded).
- Forced colours (Windows contrast themes): the steel is not drawn, and the button is a plain system button, with `GrayText` when disabled. While a hold button is held it turns `Highlight`, with a bar along its foot that fills over the hold time, so the press shows how far it has to go.
- The live region and the hint are spans placed right after the button, out of the layout. Selectors such as `:last-child` in its parent will see them.
- No motion prompt: with the still tilt (see [No tilt](#no-tilt)), iOS does not ask for motion access. Without it, the first tap anywhere on the page asks, because `tilt.js` moves the highlight with the phone and iOS hands over motion only after asking.
- Without JS it is a plain button with a quiet steel-grey gradient. A hold button then acts on a single click, so if a discard matters, confirm it on the server as well.

**Reduced motion:** nothing moves by itself. Holding still colours the face, because that is direct input. When you let go, the colours settle at once instead of running on, and the face is rubbed bright without the fade. A disabled button dims at once, with no transition; a kept blue (`data-reset="0"`) still has its 1.2 s at full strength first.

## In life, and here

| In life | Here |
|---|---|
| A hardened tool is let down: the smith rubs one face bright on a stone, warms it gently and watches. A skin of oxide grows on the bright face and shows as colour, running ahead of the heat: pale straw, straw, brown, purple, blue. | Your finger is the flame. Heat spreads through a small plate of steel (a css pixel is about 0.27 mm of it) and the film grows as real oxide does, so the colours spread from where you pressed and run on for a moment after you let go. |
| The colours are interference in a film thinner than a wavelength of light. It only ever thickens. | The colours are computed, not picked: magnetite on iron, seen by the CIE 1931 observer in daylight. They only thicken here too. |
| The smith takes the heat away at the colour the tool wants. Grind the face and the record is gone. | A hold button stops at its colour: `data-to` (blue) under the press confirms, at about `data-hold`. After `data-reset` (1.8 s), the face is rubbed bright again. |

## Cost

- **Files:** 74 KB of JS for the engine (the whole of temper-run, unminified; the bar, rule and frame code comes along unused), 8.7 KB for `temper-button.js`, 3.5 KB + 4.4 KB of CSS, and 2.8 KB of `tilt.js`, which is not loaded with the still tilt. No images, no libraries.
- **First button:** about 200 ms, once: the film-colour tables for three viewing angles, and the hold timing for each size.
- **Idle:** nothing runs (no animation frames at rest). The clock turns only while the steel is heated or still hot enough to colour, while a face is being rubbed bright, and while the highlight follows the mouse. Off screen, or in a hidden tab, it stops. With the still tilt, a phone moving in the hand runs nothing either (with `tilt.js`, see [No tilt](#no-tilt)).
- **While it runs:** the face is painted on the CPU every frame, about half a microsecond per device pixel (DPR capped at 2), so a big button costs more than a small one: see [Sizes](#sizes) for what that is at each size. Keep big labels short. On a slow phone each frame's clock is capped at 50 ms, so a hold then takes a little longer than `data-hold`.

## Credits

- The engine: temper-run, by Claude Code (`claude-2026-10-27 (set aside)/potential/temper-run`), copied unchanged. Its README has the physics in full.
- Optical data: iron, Johnson and Christy, *Phys. Rev. B* 9, 5056 (1974); magnetite (Fe3O4), Querry, CRDC-CR-85034 (1985). Both via refractiveindex.info.
- CIE 1931 2° colour-matching functions from CVRL (cvrl.org); the D65 illuminant from CIE 15.
- No images. The original demo's engraving (Asher B. Durand's banknote smith, The Met, CC0) is not used, so it isn't shipped and there is no `assets/` folder.

# pyramid-steps

A stepper that lays limestone. Each finished step is one course of a small pyramid, set block by block: the
blocks come up the ramp behind the back corner, over the edge onto the working bed, and are dragged across the
wet gypsum to their places, front corner first. The step you are on is the course being laid. Its bed lies open,
spread with mortar, and the low sun from the left throws the new blocks' long shadows across it. The courses still
to come are set out in hairline on the paper, as an elevation is drawn. Finishing the last step brings the capstone
up the same way and sets it. Nothing glows or changes; it is a stone set on stone. Going back lifts the top course
off again, the last block laid the first one lifted.

The capstone is the Met's pyramidion of Iufaa (Dynasty 26). Every block face is a cut-out of a real Giza block,
and every top is a weathered surface from Dahshur or Giza. Courses shrink upward by Petrie's measured course heights
of the Great Pyramid.

```html
<link rel="stylesheet" href="pyramid-steps.css">
<nav data-pyramid-steps aria-label="Application">
  <ol>
    <li>Account</li>
    <li aria-current="step">Details</li>
    <li>Address</li>
    <li>Payment</li>
    <li>Review</li>
  </ol>
</nav>
<script type="module" src="pyramid-steps.js"></script>

<!-- the same thing small, for a page header -->
<nav data-pyramid-steps data-layout="strip" aria-label="Checkout">…</nav>
```

```js
import { pyramidSteps } from './pyramid-steps.js';
const steps = pyramidSteps(nav, { layout: 'tower', revisit: 'done' });
steps.next();          // lay the current course and set out the next (or the capstone after the last)
steps.back();          // lift the top course off again
steps.go(2);           // any step (0-based); go(steps.length) = finished, capstone set
steps.progress(.6);    // share of the current course laid: tie it to fields filled in (the demo does)
steps.current; steps.length; steps.done;
steps.destroy();       // canvas, observers and listeners gone; the plain list as it was
nav.addEventListener('pyramid-steps:change', (e) => e.detail);   // { current, previous, complete }
```

Events (bubbling): `pyramid-steps:change` on every move, `pyramid-steps:select` when a step's label is pressed
(cancelable: `preventDefault()` keeps the component from moving, so your form can validate first),
`pyramid-steps:laid` `{ course }` when a course's last block is home, `pyramid-steps:capstone` when the capstone
settles. The last two are there for sound.

Without JS, or before the stone has loaded, it is the list: numbered, current step marked.

## Options

`data-*` on the element, or the options object (which wins).

| Option | Attribute | Default | |
|---|---|---|---|
| `layout` | `data-layout` | `tower` | `tower`: the pyramid with its labels beside it, each on a hairline leader at its own course. `strip`: a small pyramid before a row of labels, for a header. |
| `current` | `data-current` | the `li` with `aria-current="step"`, else 0 | Starting step, 0-based; `length` = finished. |
| `progress` | `data-progress` | `.35` | Share of the current course laid at rest. |
| `revisit` | `data-revisit` | `done` | Which labels are buttons: `done` steps, `all`, or `none`. The others are plain text, never disabled buttons. |
| `face` | `data-face` | from the seed | Which of the capstone's four faces looks at you (0-3). |
| `seed` | `data-seed` | random | Fixes the bond, the choice of stones and the capstone's turn. Use the same seed on two navs to show the same pyramid. |
| `speed` | `data-speed` | `1` | Multiplies how fast blocks are hauled and set. |
| `assets` | `data-assets` | `./assets/` beside the module | Where `blocks.webp`, `blocks.json`, `capstone.webp` and `mortar.webp` live. |

A label that already contains an `<a href>` or a `<button>` is left as it is. The component only adds the class
and fires `select`. Plain-text labels become buttons when revisitable.

## Theming

| Variable | Default | |
|---|---|---|
| `--ps-h` | `clamp(240px, 52vw, 460px)` | Tower height. The pyramid is about 0.74 as wide as it is tall. |
| `--ps-strip-h` | `46px` | Strip height. |
| `--ps-ink`, `--ps-ink-2`, `--ps-ink-3` | `--ink`, `--ink-2`, `--ink-3` | Current, done and coming labels. |
| `--ps-rule` | `--rule` | Leaders. The setting-out lines are a fixed warm grey. |
| `--ps-font` | `--sans` | Labels. Step numbers are italic `--serif`. |

The stone is not themeable. It is the stone.

## The real thing

| In life | Here |
|---|---|
| A pyramid's core is laid in horizontal courses of local limestone, quarried beside it. At Giza that is the Mokattam formation, a buff, shelly (nummulitic) limestone that weathers to honey and grey, with pits and honeycomb where the softer beds go. | Every block face is a cut-out of a real block in three photographs of the Great Pyramid's lower courses. 26 faces are kept out of 43 cut, each cut along its own dark joints, so its weathered outline is its own. They are half-flattened to one light and toned toward one stone, keeping a third of each block's own colour. |
| Course heights are not equal. Petrie measured all 203 surviving courses of Khufu's pyramid: about 1.49 m at the foot, about 0.55 m near the top, thinning upward in runs, each run starting again with a thick course (1, 35, 44, 67, 90, 98, 118…). | Khufu's 203 courses are split into as many bands of height as there are steps. Each course here is as tall as the mean course in its band, so five steps give 86, 77, 70, 62 and 55 cm, in proportion. The runs are averaged out. |
| Blocks in the core are roughly squared, about 1 to 1.5 m long, set on a bed of gypsum mortar that served more as a lubricant than a glue: the block was slid on it and levered against its neighbour. Joints are rough and wide inside, tight at the faces. Petrie noted that the corner and middle stones of each course were set with special care, as guides. | Blocks are 0.7 to 1.3 times a course long and about as deep as a course is tall. They are dragged on, decelerating as on wet mortar, and stop dead against their neighbours. Joints show the stone's own shadowed edge. The bed of the course being laid is spread with the Met's mortar sample from the Great Pyramid. |
| Courses are bonded: blocks of one course straddle the joints of the course below, and headers (ends) and stretchers (sides) alternate. | Alternate courses run their lanes the other way, so one face shows block ends where the course below shows long sides, and vertical joints never line up. |
| Blocks came up on sledges by ramps (straight, or along the faces; how is argued over). Papyri of the inspector Merer (Wadi al-Jarf, Year 27 of Khufu) record boatloads of fine limestone from Tura for the casing. | Every block comes up behind the back corner, where the pyramid hides it, crests the edge, and is dragged across the bed. Courses fill from the front corner back, so no block is ever dragged through one already set. |
| The top of a pyramid is a pyramidion, often of finer stone, sometimes inscribed. Late Period private pyramidia like Iufaa's carry the owner adoring the sun: the scarab Khepri in his barque at dawn on one face, the disc on another, Iufaa kneeling under the jackal on the other two. | Iufaa's pyramidion, from the four Met views that look straight at each face. Each face is matted and fitted by its own measured corners and apex onto the true triangle. The two sun faces are taken as east and west, opposite each other. The seed decides which pair you see. |
| A pyramidion matches its pyramid's slope. Iufaa's rises at atan(35.5 / 13.4) = 69.3°, much steeper than Khufu's 51.8°, as the small steep private pyramids of the New Kingdom and Late Period were. | The whole pyramid takes the capstone's 69.3°, so the arrises run straight into it (Connor's choice, over bending the capstone or keeping Giza's slope with a kink). Each course steps in by the slope's run, and the capstone's base is exactly the top course. The capstone is drawn about twice the top course's height, as Khufu's lost one would have been. |
| Low sun rakes across the stone and shows every pit and arris; the shaded faces are lit by the sky and the sand. | One sun, 26° up and from the front-left, nearly along the left face. Faces are lit by their own orientation (sun, sky and sand bounce, normalised so the sunlit face is the photograph as shot); the right face is in shade. Each block's front arris catches the sun in a broken hairline. Shadows fall on the bed and treads below, and on the paper as one soft shadow that fades with distance. |

Simplified: a finished pyramid hid its stepped core inside a smooth casing of dressed Tura limestone. Here, as at
Giza today, the core is shown stripped, stepping at every course. The pyramid is small, a few
of its courses' heights across, so a course has two to four blocks on a side, not hundreds. The sun doesn't move.
No ramp, sledge or worker is drawn. Iufaa's pyramidion is 35 cm tall and is drawn at the scale of a royal one.

## How it works

**Offline** (Python, in `tools/engine/jobs/pyramid-steps-*`): the four colour views of the pyramidion are matted
with BiRefNet (the engine's `convert.matte`). The left and right edges of each matte are fitted by robust lines,
the broken base by a line through its lowest boundary, and the apex is where the edges meet. An affine map from
those three points to the true face triangle (slant ÷ base = 1.416) rectifies each face. Block faces are cut from
hand-read boxes, the outline found from each box's own dark joints (local-contrast threshold, the region connected
to the middle, pits filled), then edge-decontaminated, half-flattened, colour-matched and shelf-packed into one
atlas. Every asset passes the engine's taste gate (`inspect --use texture`).

**Runtime** (Canvas2D, no libraries): an orthographic camera (33° yaw, 15° pitch), so every face of every block is
a parallelogram and draws exactly by `setTransform` + `drawImage` from the atlas, clipped. Then the face's light is
multiplied on. Painter's order: the shadow on the paper, the setting-out, anything still on the ramp behind, the
finished courses (one cached layer, redrawn only when a course completes), then the open course: mortar bed, cast
shadows, blocks sorted by depth. Then the capstone. Each block carries a progress 0..1 and its own start time, so
a reversal mid-move just turns it round. The loop runs only while something moves, and stops off screen. Canvas
DPR ≤ 2.

## Accessibility

- It is a real `<nav>` with an `<ol>`. The current step has `aria-current="step"`. Done steps are buttons named
  "Account, done". Coming steps are plain text. A polite live region says "Step 3 of 5: Address", or "All 5 steps
  done".
- Focus stays where it was when a pressed label stops being a button.
- The canvas is `aria-hidden`.
- **Reduced motion:** nothing travels; blocks and capstone are simply home or not.

## Cost

Assets 1.5 MB (block atlas 0.79 MB, capstone 0.67 MB, mortar). At rest nothing runs. While laying: about 60 to
120 clipped `drawImage`s a frame, the finished courses from one cached canvas. Two navs on a page (header strip and
tower) share the assets.

## Credits

Capstone: *Pyramidion of Iufaa*, Dynasty 26, The Metropolitan Museum of Art (21.2.66), CC0. Mortar: *Specimen of
Mortar from the Great Pyramid*, The Met (17.6.143), CC0. Block faces: Olaf Tausch (CC BY 3.0), Jean-Pierre Houdin
(CC BY-SA 4.0), lienyuan lee (CC BY 3.0); tops: Djehouty (CC BY-SA 4.0, Dahshur), @bastique (CC BY-SA 2.0), all
via Wikimedia Commons. Course heights: W. M. F. Petrie, *The Pyramids and Temples of Gizeh* (1883), pl. VIII. Every
part, with its box in its source photograph, is in `assets/credits.json`.

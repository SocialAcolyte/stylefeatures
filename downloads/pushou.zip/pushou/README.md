# pushou

A press button for actions that knock or ring ("Request access", "Notify me", "Knock", "Ring for service").
It holds a Warring States bronze handle in the Freer Gallery (F1917.18, 5th–4th century BCE): a monster's mask with a
ring through its nose, gold and silver hammered into both. It is the *pushou* (鋪首) form that hung on palace and tomb
doors as the door's pull and its knocker. Press, and the ring lifts on the bar inside the nose loop. Let go, and it
swings back and strikes the door. That blow is the knock. The ring is the photograph's own pixels turned as a rigid
plane about its hinge; the mask never moves.

At rest it is the museum's photograph, cut off its white sweep: three images of one canvas (the plate, the ring and the
loop in front of it) that recombine to the photograph within 1/255. The words are a real `<button>`.

```html
<link rel="stylesheet" href="pushou.css">
<button type="button" class="po" data-pushou>
  <span class="po-knocker" aria-hidden="true">
    <img class="po-plate" src="assets/plate-168.webp" srcset="assets/plate-168.webp 117w, assets/plate-480.webp 335w, assets/plate-1207.webp 842w" sizes="28px" width="117" height="168" alt="" decoding="async">
    <img class="po-ring"  src="assets/ring-168.webp"  srcset="assets/ring-168.webp 117w, assets/ring-480.webp 335w, assets/ring-1207.webp 842w"   sizes="28px" width="117" height="168" alt="" decoding="async">
    <img class="po-loop"  src="assets/loop-168.webp"  srcset="assets/loop-168.webp 117w, assets/loop-480.webp 335w, assets/loop-1207.webp 842w"   sizes="28px" width="117" height="168" alt="" decoding="async">
  </span>
  <span class="po-label">Request access</span>
</button>
<script type="module" src="pushou.js"></script>
```

`sizes` is the knocker's width: its height × 0.6976 (28px for `.po`, 23px for `.po-sm`, 19px for `.po-xs`). For the
hero tile it is `(min-width: 824px) 196px, (min-width: 530px) 23.8vw, 126px`, so the right file loads first, and
without the script too. If a layer's file was chosen for a width more than 20% off the width it is shown at, the
script chooses again; it leaves a right `sizes` alone (choosing again lets the browser swap in a larger cached file).

```js
import { pushou } from './pushou.js';
const knocker = pushou(button, { size: 16 });             // auto-started on [data-pushou] anyway
button.addEventListener('click', send);                    // the button's own click, as usual (at once)
button.addEventListener('pushou:knock', (e) => e.detail);  // {force 0-1, strike 1|2, source 'pointer'|'keyboard'|'script'}
knocker.knock();     // a knock from script: the ring lifts briefly and falls
knocker.wait();      // while your request is on its way: the ring is held a little up, still (aria-busy="true")
knocker.cancel();    // the ring is put back down without a knock, and the wait ends
knocker.lift(20);    // hold it up (degrees) ... knocker.release();
knocker.angle;       // degrees out from hanging straight
knocker.waiting;     // true between wait() and knock() or cancel()
knocker();           // destroy: listeners, observers, the loop and the shadow go; the markup is left as it was
```

`click` fires when the button is pressed, as for any button. `pushou:knock` fires about a quarter of a second later,
when the ring hits the door. Its `force` is how hard (a full lift is about 0.8), and `strike: 2` is the small
rebound. It only follows a real click: a press dragged off the button and let go outside doesn't click, so the hand
puts the ring back down without a knock, and a finger that turns out to be scrolling never lifts it (or, if it had
begun to, puts it back down). Use `click` to act, and `pushou:knock` for anything that should land with the blow (the
demo changes its words then).

**Words that change.** If the label changes (Request access, Requesting…, Requested), put every wording in the label,
each in its own `<span>`, with `hidden` on all but the one showing, and move `hidden` to change them. They share one
place, so the pill keeps the width of the longest and the knocker doesn't move when the words do (in a right-aligned
footer or row, a pill that changed width would carry the knocker sideways). Mark the wording that goes with
`.po-done` with `data-po-done`: it carries the tick, so the tick's room is kept too. The hidden wordings are not read;
the button's name is the one showing. Where `:has()` is missing (browsers before 2023), or a site's CSS forces
`[hidden] { display: none !important }`, the pill simply takes the width of the words showing, as before.

```html
<span class="po-label"><span>Request access</span><span hidden>Requesting…</span><span hidden data-po-done>Requested</span></span>
```

**A request that takes time.** Call `wait()` in your click listener: the hand catches the ring and holds it about
11° up (18° on a knocker under 48 px, where 11° would hardly show) while the label says what is happening
("Requesting…"), and the button is `aria-busy`. While it waits, presses don't move the ring and clicks aren't passed
on. Call `knock()` when the request has arrived: the ring is lifted a little higher and let go, and the knock lands
then. `cancel()` puts it back down instead. The demo's folder footer does this with an 800 ms delay; when the request
arrives its Cancel is dimmed, and it gives way to Withdraw as the ring strikes. On the light pills the held ring's
shadow shows on the door. On the ink primary at row size the ring's shadow falls on black and the lift is a pixel or
so of foreshortening, so there the words (and `aria-busy`, and the progress cursor) carry the working state.

**Done.** When an action has happened and can't be repeated, add `aria-disabled="true"` and `.po-done`: the button
keeps focus (so a keyboard user isn't dropped onto the page), doesn't click again, and looks done, not unavailable:
the bronze keeps its colour with the ring at rest, the words step back to ink-2 on the paper with a tick that isn't
read aloud, and a primary leaves its ink. `disabled` is for actions that can't be taken at all: the bronze goes grey.

**Without JS** it is still a working button, and `:active` still lifts the ring (22°) and lets it drop when you
release, unless motion is reduced. **Reduced motion:** nothing moves. The click reports its knock at once (`force: 1`).

## In life, and here

| In life | Here |
|---|---|
| A *pushou* is a beast mask fixed to a door leaf, its nose bent into a loop with a ring hanging through it. Double doors had a pair, one on each leaf. The ring was the pull, and the knocker: lifted outward and let go, it fell against the door. Bronze ones from palace gates run large: the openwork dragon-and-phoenix pushou from the Yan capital at Yi county (Laomutai, excavated 1966) is 74.5 cm long. Han tomb doors of stone or stamped clay carry them in relief, for the dead, as guardians and as a door. | The button is the door. The knocker sits on the page at rest, exactly as photographed. The ring hangs from the bar inside the loop: the hinge, 44.97% down the knocker, where the ring's inner rim rests. |
| This handle is small, 7.7 × 5.4 × 2.2 cm. The Freer doesn't record what it was fixed to. Fittings of this size were fixed to lacquered wood: chests, coffins, small doors. On bronze vessels the same mask and ring was cast as the handles. Larger ones were cast for the doors themselves. | It is shown at 28–54 px in a button row and up to 280 px as a hero. The swing is timed as for a knocker about 16 cm long (`data-size`), so that it reads at screen size. At 7.7 cm it would fall in a tenth of a second. |
| Lifting: a hand draws the ring out from the door and it turns on the bar. | Pressing: the hand lifts the ring (a stiff, critically damped spring) to 24°, or to the 32° the cut allows on a knocker under 48 px, where a smaller lift would hardly show. Space holds it up until the key comes up. It turns as a rigid plane in perspective (`rotateX` about the hinge line, perspective 3.6 × its height): its own pixels, foreshortened, never redrawn. While it is up, its shadow, cut from its own outline, falls on the door below it; on a small knocker the shadow is given a floor (1.5 px down, 0.42, sharp) so the ring is seen to leave the door. |
| Knocking: let go, the ring swings back past hanging straight and strikes the door. It rebounds a little and comes to rest. | Released: a pendulum under gravity with light damping, stepped at 240 Hz from the clock, not from frames. The door is a hard stop just past vertical, with restitution 0.32. The blow is `pushou:knock` with its force, and the rebound (strike 2) is softer. Once the ring can't reach the door again, the bar's friction stops it (damping 9/s), so it hangs still about a second after you let go. The sound is a real metal door knocker, off until the visitor turns it on. |
| A quick rap still lifts the knocker properly, and a hand that is still pressing keeps hold of the ring even if it drifts off the door. | A press shorter than 110 ms finishes the lift before letting go, so a tap knocks as firmly as a hold (about 0.8). A finger waits 90 ms before it lifts, in case it is starting a scroll; a tap that ends sooner lifts at once. Let go on the button, the ring falls and knocks. A press slid off and let go elsewhere doesn't click, so the hand puts the ring back down: no knock. |
| A hand can also hold the ring part way, waiting to be let in. | `wait()`: about 11° (18° under 48 px), still, while a request is on its way. |
| *Cuo jin yin* (錯金銀), the Warring States craft of inlay: channels cast into the bronze, gold and silver hammered in and burnished flush. On this one: the mask's brows and nose ridge, a band round the loop, cloud spirals and a twisting ribbon on the ring. | The inlay is untouched. When the ring lifts, the spirals foreshorten with it, and the mask's gold stays put. |

Simplified, and why:

- The museum photographed it lying on its back, so its ring rests on the table at about 12°: its foot on the table,
  its top held up by the loop. On a door it would hang nearly straight. Treating the photograph as hanging straight
  leaves the ring 2% shorter than true. That is left as photographed and never stretched.
- The lift is capped at 32°. Two reasons. Above the hinge the ring's band drops toward the bar as it turns, uncovering
  a strip of the mask no one photographed; that strip is restored (see below), and only as deep as a 32° lift needs.
  And a round-section ring turned much further would show its rim, which wasn't photographed either.
- The rebound is the real one, but light. A knocker that rattled on would be shake for its own sake.
- At row size the stroke is small, as it is on the real thing seen from across a room: on a 33 px knocker a full
  lift shortens the ring by about a pixel and a half and puts its shadow under it, a few hundred device pixels of
  change. It reads, and the pill's pressed tone confirms it. At the hero it is unmistakable.

## How it was cut (offline, `tools/`)

Python, `./tools/run.sh <stage>.py`. The photograph and the work files go in the engine's job folders
(`tools/engine/jobs/pushou-src`, `pushou-work`); set `PO_SRC`, `PO_WORK` (and `PO_ENGINE`, for the matte worker) to
put them anywhere else.

1. `fetch.py`: the Freer's own photograph FS-7729_16, 4200 × 3150 (the object about 1650 × 2380 px, 310 px/cm).
2. `matte.py`: the engine's BiRefNet worker decides what is object. Then `matte_fine.py` solves every edge again at
   full resolution against the sweep (the sweep from clear pixels nearby, the bronze from solid pixels nearby, alpha
   by projection) and unmixes the edge colour from it, so the rough corroded outline survives with no white halo.
3. `ring_fit.py`: ellipses fitted to the ring's free edges. Where its band crosses the mask, its edge was traced at 3×:
   on the left it runs on the fitted circle; on the right it rides up to 35 px higher, along the top of the gold
   ribbon. The ring is cut with a 9 px margin on the mask's side (about 1 px on screen), so its bright rim always
   moves with it.
4. `parts.py`:
   - The plate, ring and loop on one canvas. The loop, the nose bent round the ring, lies in front of the band and is
     cut straight across below the band's inner rim.
   - Exact at rest: under the ring's soft edge the plate supplies exactly the coverage the matte leaves, and the
     ring's colour is solved, so that ring over plate equals the photograph.
   - Behind the band the mask continues. Its hidden lower edge comes from a harmonic fill of its own alpha across
     the band, joining the edges seen on either side.
   - Its surface, in the strip a lifted ring can uncover (at most about 57 source px, 8 px on screen at the hero),
     is filled by exemplar: blocks of the mask's own lower cheeks, never the inlay, the nose or the sweep, chosen to
     continue the real pixels at the seam and cross-faded in.
   - Where the loop hides the band, the band is continued from its own pixels (never seen).
5. `preview_motion.py`: frames at 0, 12, 24 and 32°, to check for ghost edges and tears.
6. `export.py`: uniform Lanczos downscales to 1207, 480 and 168 px tall; `assets/pushou.json` has the hinge and ring
   as fractions of the canvas.

## Runtime

No canvas, no library: three `<img>` layers and one shadow `<span>` the script adds. No filter ever touches the
photograph: the contact shadows that set the knocker on the door are `::before` (under the mask) and `::after` (under
the ring) of `.po-knocker`, masked by the layers' own images and drawn behind them, and the ring's lets go of it as it
lifts, when its cast shadow takes over. So the mask's pixels are the same at rest, held and after (measured: no pixel
more than one level off).

The ring's `transform` is set only while it moves. A `requestAnimationFrame` loop runs from a press until the ring
hangs still again, about a second after you let go, then stops and clears the transform, so at rest the page shows
the image untouched. Nothing runs while the ring is held still (by a press, Space or `wait()`), and nothing runs off
screen: an `IntersectionObserver` settles the ring at once when the knocker leaves the viewport, and a knock that was
on its way lands then, as hard as it would have. The physics is a fixed 240 Hz step driven by the clock: after a
stalled frame it catches up (up to half a second).

## Options

| Option | Attribute | Default | |
|---|---|---|---|
| `hold` | `data-hold` | `24`, or `32` under 48 px | Degrees the hand lifts the ring while pressed (max 32). |
| `tap` | `data-tap` | `18`, or `24` under 48 px | Degrees for Enter and for `knock()`. |
| `wait` | `data-wait` | `11`, or `18` under 48 px | Degrees `wait()` holds it at. |
| `size` | `data-size` | `16` | cm: the knocker's scale for the swing. Larger is slower and heavier. |
| `bounce` | `data-bounce` | `0.32` | Restitution of the ring against the door. |

## Sizes and variants

The knocker sits in the pill's round end, a 32nd of the height right of centre and a 64th below it, so that the
mask's top ear clears the border by more than a pixel at every size (1.3 px on `.po-xs`, 1.5 on `.po-sm`, 1.7 on
`.po`, 2.0 on `.po-lg`, measured from the layers' own alpha).

| Class | | Knocker |
|---|---|---|
| `.po-xs` | a 32 px pill, for a dense toolbar or list; its touch target is 44 px | 26 px |
| `.po-sm` | a 40 px row button (settings rows) | 33 px |
| `.po` | a 48 px pill: knocker, then the words | 40 px |
| `.po-lg` | a 64 px pill | 54 px |
| `.po-icon` | a round 44 px button with no words: give it `aria-label`, and a visible label nearby | 32 px |
| `.po-hero` | a tile: the knocker large, the words under it; rule edge, darker on hover, pressed tone | `clamp(180px, 34vw, 280px)` |
| `.po-solid` | the primary, in ink (combine with a size). Pressed, the ink takes a little of the paper, a step that shows on a phone too | |
| `.po-done` | with `aria-disabled="true"`: done (see above) | |
| `.po-block` | full width | |

## Theming

Uses `--paper`, `--ink`, `--ink-2` (the focus ring, done words), `--ink-3`, `--rule`, `--sans`.

| Variable | Default | |
|---|---|---|
| `--po-h` | `48px` | The pill's height. Every size derives its knocker from it. |
| `--po-size` | `--po-h` − 8 px (− 6, − 7, − 10, − 12 for xs, sm, lg, icon) | The knocker's height (set it directly for any size). |
| `--po-paper` | `--paper` | The button's face. |
| `--po-shadow`, `--po-contact` | warm black, `0.3` | The knocker's shadows on the door, and the contact shadow's strength. |

## Accessibility

A real `<button>`: its name is the label (or `aria-label` on `.po-icon`), Space and Enter work as on any button, and
`:focus-visible` gets a 2 px outline. The knocker is `aria-hidden` with `alt=""` on each layer. `disabled` greys the
bronze, and the ring stays down and the pill doesn't react to a press. `aria-disabled="true"` looks the same (or done,
with `.po-done`) and keeps focus. Its clicks are stopped on the button itself, in the capture phase, so listeners on
the button and bubbling listeners on its ancestors never see them, and no knock arrives. A capture-phase listener on
an ancestor (on `document`, say) still gets the click first, as it would for any button: check `aria-disabled` there.
While `wait()` holds it, it is `aria-busy` and doesn't click either. With words that change, only the wording showing
is read. State changes are yours to announce: each of the demo's actions writes to a `role="status"` line (in ink-2,
8.5:1), and each line keeps the room of everything it can say, so nothing below it moves when it speaks. In forced
colours the pill gets a system border, GrayText when disabled, and the shadows are dropped. Touch targets are 40 px
or more (`.po-xs` draws 32 px and takes 44).

## Sound

Off until the visitor turns it on (the speaker button, from `sound.js`; the choice is remembered). `sounds.json` wires
`assets/sounds/knock.wav` to `event:pushou:knock`: strike 1 at volume 0.42, the rebound at 0.14. To change it, use
the viewer's Sound panel (`tools/studio`), or edit `sounds.json`. `sound.js` is the house runtime, unchanged; the demo
docks its switch at the top of the page below 1160 px, where a fixed one would sit over the rows' buttons.

## Cost

| | |
|---|---|
| Three layers at 168 px (row, toolbar and icon buttons) | 13 KB |
| at 480 px | 55 KB |
| at 1207 px (the hero on a 2× or 3× screen) | 195 KB |
| `pushou.js` + `pushou.css` | 18 KB + 10 KB (unminified, with comments) |
| sound (only if turned on) | 33 KB |

Idle, held still, or off screen: nothing runs. While a ring moves (about a second per knock): one transform, one
shadow and up to 240 physics steps a second, each a few multiplications.

## Credits

The handle: *Mask and ring handle*, China, Eastern Zhou dynasty, Warring States period, 5th–4th century BCE. Bronze
with gold and silver inlay, 7.7 × 5.4 × 2.2 cm. National Museum of Asian Art, Smithsonian Institution, Freer Gallery
of Art, F1917.18, gift of Charles Lang Freer. Smithsonian Open Access, CC0. Photograph FS-7729_16.

The sound: *Door knocker audio* by Mx. Granger, Wikimedia Commons, CC0: a metal door knocker; the third knock,
trimmed.

The hunt (47 candidates, the shortlist and why this one): `assets/PICK.md`. See `assets/credits.json`.

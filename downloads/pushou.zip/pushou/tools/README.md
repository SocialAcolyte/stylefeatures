# pushou / tools

The offline cut, in order (`./run.sh <stage>.py`; matte_fine.py and ring_fit.py run under `uv run`):

1. `fetch.py`: the Freer's photograph FS-7729_16 of F1917.18 (4200 x 3150, CC0) into the engine's job folder.
2. `matte.py`: BiRefNet (the engine's worker), then `matte_fine.py`: every edge solved again at full resolution against
   the sweep, its colour unmixed from it.
3. `ring_fit.py`: ellipses fitted to the ring's free edges (where it lies against the sweep). The ring centre and radii
   in `common.py` come from it; the band's edge where it crosses the mask was traced at 3x (`common.py`).
4. `parts.py`: plate, ring and loop on one canvas, exact at rest (checked against the matte, within 1/255), with the
   strip the lifted ring can uncover restored from the mask's own surface.
5. `preview_motion.py`: the ring lifted 0-32 deg over the plate, to check for ghosts and tears.
6. `export.py`: WebP at 1207, 480 and 168 px tall, and `assets/pushou.json`.

Work files go to `tools/engine/jobs/pushou-work/` and the photograph to `tools/engine/jobs/pushou-src/`; set `PO_WORK`
and `PO_SRC` to put them elsewhere, and `PO_ENGINE` for the engine whose BiRefNet worker `matte.py` runs. Importing
`common.py` creates nothing; each stage makes the folders it writes. Nothing here touches the photograph itself.

# denarii

A bar chart counted out in Roman silver on a real cloth. You write a plain `<table>` of your own numbers, and each
row is laid out as a line of real denarii, one coin to a unit, in fives, each coin resting a little on the one before,
with a real quinarius (the half-denarius) for a half unit. The count lies on the plain field of a real wool tunic
fragment from Egypt (400s-600s), between its own two tapestry bands, with its corner band in the gutter beside the
names. Every coin is a separate museum photograph of a separate hand-struck coin, cut from its ground and shown at
its true size relative to the others. Hover or tap a coin and it lifts off the cloth and reads the count up to it.
Tap it to turn it over: what you see is that coin's own reverse. With more than one column of numbers there is a
switch, and the coins are counted on or gathered off as the values change.

Without JS it is the table. With JS the table is still the content: its cells stay in place for assistive tech, and
the coins are drawn in one extra, `aria-hidden` cell per row.

```html
<link rel="stylesheet" href="denarii.css">
<figure class="dn" data-denarii data-unit-label="yr|yrs">
  <table>
    <caption>Nine emperors <small>Years on the throne, and age at death.</small></caption>
    <thead><tr><th scope="col">Emperor</th><th scope="col">Years reigned</th><th scope="col">Age at death</th></tr></thead>
    <tbody>
      <tr><th scope="row">Augustus</th><td>40.6</td><td>75</td></tr>
      <tr><th scope="row">Tiberius</th><td>22.5</td><td>77</td></tr>
      <!-- … -->
    </tbody>
  </table>
</figure>
<script type="module" src="denarii.js"></script>
```

```js
import { denarii, count } from './denarii.js';
const chart = denarii(figure, { minCoins: 15, maxCoins: 40 });
chart.show(1);          // the second column of numbers
chart.select(0);        // read a row (dims the others, says it in the live region)
chart.turn(0, 3);       // turn row 0's fourth coin over
chart.recount();        // count every row out again (e.g. after you change the table's numbers and call it afresh)
chart.column; chart.unit;
figure.addEventListener('denarii:change', (e) => e.detail);   // {column, name}
figure.addEventListener('denarii:select', (e) => e.detail);   // {row, label, value, column}
chart();                // destroy: removes the coins, the switch, the key and listeners; leaves the plain table
count(23, 5);           // {n: 4, half: true, slots: 5}, the coins a value takes
```

Each row's first cell is its label (a `<th scope="row">`), and every other cell is a number. A cell's number is read
from its text (`1,240`, `£3.2`, `−4` all work), or from `data-value` when the text says something else
(`<td data-value="3200000">3.2m</td>`). The text, exactly as you wrote it, is what is shown at the end of the row.

## In life, and here

| In life | Here |
|---|---|
| The denarius was Rome's silver coin from about 211 BC until the middle of the third century AD. It was worth ten bronze asses and was marked X for it. Its half, the quinarius, was marked V. | One denarius is one unit of your data, and one quinarius is half a unit. The key under the chart says what a unit is (`2 yrs`, `1 yr`). The coin size is set by the width (about one coin per 30 px, at least 15 to a full row). Then, for each column on its own, the unit is the smallest of 1, 1.5, 2, 2.5, 3, 4, 5, 6 or 8 × 10ⁿ for which that column's longest value still fits. Each column's coins are then sized so its longest row reaches about 90% of the cloth's field (85% on a phone), with its number still after it. Switching columns can change the unit (the key says so) and the coins' size; coins that stay slide and resize to their new places, and the rows keep their spacing. |
| Each coin was struck by hand. Blanks were made so many to the pound of silver, not each to an exact size. A blank was set on the lower die and hit once with the upper die held in the hand. So coins of the same issue differ in size, centring, flan shape and wear, and no two are alike. | Every coin is its own photograph: 144 denarii and 3 quinarii from the Art Institute of Chicago, struck between 200 BC and the 240s AD (and one, of Galerius, about 307), obverse and reverse. Each is shown at the diameter the museum recorded (14 to 22 mm) on one scale. All coins sit on the same pitch, so length stays honest, each centred in a slot as wide as the widest denarius, and each coin rests a little on the one before. No coin appears twice in a row, and adjacent rows draw from different parts of the pool. Faces are upright, as the museum photographed them. The purple-black toners are culled from the pool by measured lightness and colour cast. |
| Coins were counted out on a table, often onto a cloth, one by one, set down beside the last, and money was reckoned in ones and fives (I, V, X). In Roman Egypt, tunics were woven in one piece on the loom: a plain wool or linen ground, with tapestry bands and ornaments worked into it as it grew. | Coins are laid in fives, with a small gap between each five. The cloth is a real tunic fragment, shown untouched. It is cut from the museum's mount along its own torn edge, its two losses open to the page, and it is never stretched: one scale, chosen so that its plain field between the bands holds the rows. Measured in the demo, that is 1.4 to 1.6 times the coins' scale on a desktop and 1.8 to 2.3 times on a phone, and it is cropped only where the chart ends. No lines are drawn on it, so the fives and the value at each row's end do the reading. When the chart scrolls into view each row is counted out: one coin after another, each set down just short of its place and sliding the rest of the way on the cloth. Constant friction gives an even deceleration, so it eases out quadratically. When the numbers change, coins that stay slide to their new places, new coins are counted on from the end of the row, and coins no longer needed are gathered back. |
| Each coin had two faces, struck by two dies: usually a head and a type, often the moneyer's name. | Tap a coin (or press Enter on a row) and it turns over to its own reverse, photographed with it. |

There is no transformation and no payoff at the end: the coins are the bars, from the first frame to the last.

What it does not do: negative values (they count as nothing), stacked or grouped bars, and fractions finer than a half
unit. A value is rounded to the nearest half coin, a quarter or more becoming a quinarius, and the exact value is always
written at the end of the row.

## Options

| Option | Attribute | Default | |
|---|---|---|---|
| `unit` | `data-unit` | chosen | What one denarius stands for. |
| `max` | `data-max` | the largest value | The scale's end, to compare several charts. |
| `minCoins` | `data-min-coins` | `15` | The fewest coins a full-width row is sized for. |
| `maxCoins` | `data-max-coins` | `40` | The most coins in any row. |
| `cloth` | `data-cloth` | `true` | `false` lays the count on the page instead of the cloth. |
| `coin` | `data-coin` | `--dn-coin` | The largest slot, in px. |
| `column` | `data-column` | `0` | Which number column to show first. |
| `face` | `data-face` | `obv` | `obv`, `rev`, or `mixed` (as if the coins had been thrown down). |
| `seed` | `data-seed` | random | The draw of coins. Each load draws differently unless this is set. |
| `unitLabel` | `data-unit-label` | | A short unit for the key and readings (`mi`, `t`), or singular and plural as `yr|yrs`. |
| `label` | `data-label` | `Show` | The switch's group label. |
| `src` | `data-src` | `assets/coins.json` beside the script | The pool. `coins/` sits beside it. |

## Theming

Uses `--paper`, `--ink` (names and numbers on the cloth), `--ink-2`, `--ink-3`, `--rule`, `--accent` (focus),
`--serif`, `--sans`.

| Variable | Default | |
|---|---|---|
| `--dn-coin` | `60px` | The largest slot. |
| `--dn-min` | `20px` | The smallest slot. |
| `--dn-reserve` | `64px` | Room after the longest row for its number. |
| `--dn-label` | `26%` | The most the label column takes. |

Below 640 px of its own width (so it works in a sidebar too) each name goes above its row on the cloth, the corner
band moves off to the left, and the coins take the full width. When the cloth is shown large (a phone, many rows),
the full-resolution crop of its left side (`cloth-near.webp`, 9.9 px/mm) is used, so the weave stays sharp.

## Accessibility

The table stays a real table: caption, column headers and every number are in the accessibility tree. When there is a
switch, the caption is shown once, visually, above it (an `aria-hidden` copy) and kept on the table for screen readers.
Inactive columns are visually hidden but still read. The coins, the cloth, the key and the readings are `aria-hidden`. The
table is one tab stop. Up and Down read the rows, Home and End go to the first and last, Left and Right change the
column, and Enter turns the row's coins over. A polite live region (role `status`) says the row and its value, or the
new column. The switch is real buttons with `aria-pressed`, 44 px tall. In forced colours the coins are hidden and the
table is shown as a table.

**Reduced motion:** the coins are simply there, with no counting, sliding or lifting. Turning a coin over swaps its
face at once.

## Cost

The cloth: `cloth.webp` 1.5 MB (the whole fragment at 6.5 px/mm), or `cloth-near.webp` 1.7 MB on screens that show it
large. Only one is loaded. The pool: 294 webp files, 3.5 MB on disk, about 12 KB each. A chart loads only the coins
it shows (the demo's first chart 83 obverses on a desktop, about 1 MB), and a reverse only when its coin is turned. The JSON is
18 KB. No canvas and no
rAF loop: coins are `<img>` elements with WAAPI animations that end. Idle, nothing runs. A ResizeObserver relays the
rows out when the chart's width changes.

## How it was made

`tools/engine/jobs/sf-chart-work/`: `cut.py` finds each face on the museum's flat grey ground (exactly RGB 113,
σ 0.2, so a distance threshold, opening, closing and hole fill find the coin with its own rim, nicks and flan cracks),
gives it a 1.6 px soft edge pulled in by 0.8 px, and keeps the two largest regions as obverse and reverse. `export.py`
scales every face to 8 px per millimetre of its recorded diameter and writes `assets/coins.json` and
`assets/credits.json`. `tone.py` measures each obverse's lightness and cast for the cull. `cloth.py` cuts the tunic fragment
from its mount by chroma (the mount is pale, low-chroma linen), keeps losses over 3 mm open, crops just outside the
two bands and records the field's edges in `assets/cloth.json`. Masters (3000 px coins, the 6345 px TIFF) and both
cloth files passed `engine.py inspect`. The hunt, the contact sheets and the reasons are
in `assets/PICK.md`.

## Credits

Coins: The Art Institute of Chicago, CC0 (public domain), photographs by the museum. Cloth: *Fragment of a Tunic*, Egypt,
Byzantine period, 400s-600s, tabby weave with inwoven tapestry ornament, linen and wool, The Cleveland Museum of Art
1946.413, CC0. One entry per object, with object page, source file, date and dimensions: `assets/credits.json`. Demo data: reign lengths and ages are from the usual
dates for each emperor. Aqueduct lengths are Frontinus's, from *De aquaeductu*, converted at a thousand paces to
the Roman mile.

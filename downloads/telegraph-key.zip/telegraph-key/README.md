# telegraph-key

A Send button that is the Morse–Vail key of 1844: the key Alfred Vail made as an improvement on Morse's first
transmitter, believed to be from the first Baltimore–Washington line, photographed side on by the Smithsonian. Press
it and the photographed lever turns on its pin until the point of its front screw meets the brass anvil. Let go and the
flat spring under it throws it back onto its back screw. The lever, the spring and everything on them are the
photograph's own pixels, turned rigidly about their own centres. Nothing is drawn.

It is a real `<button type="submit">`: it has a visible label, works with Space and Enter, shows focus, can be disabled
and submits its form. It reads as a 40 px row button in a form footer, and works large as a panel's one action. While a
send is going it can stay down on the anvil, busy, and then say Sent.

```html
<link rel="stylesheet" href="telegraph-key.css">
<button class="tk" type="submit" data-telegraph-key data-sending="Sending" data-sent="Sent">
  <span class="tk-key" aria-hidden="true">
    <img class="tk-base"   src="assets/key-base-400.webp"   srcset="assets/key-base-400.webp 400w, assets/key-base-800.webp 800w"     sizes="65px" width="400" height="198" alt="">
    <img class="tk-spring" src="assets/key-spring-400.webp" srcset="assets/key-spring-400.webp 400w, assets/key-spring-800.webp 800w" sizes="65px" width="400" height="198" alt="">
    <img class="tk-lever"  src="assets/key-lever-400.webp"  srcset="assets/key-lever-400.webp 400w, assets/key-lever-800.webp 800w"   sizes="65px" width="400" height="198" alt="">
    <img class="tk-cheek"  src="assets/key-cheek-400.webp"  srcset="assets/key-cheek-400.webp 400w, assets/key-cheek-800.webp 800w"   sizes="65px" width="400" height="198" alt="">
  </span>
  <span class="tk-label">Send</span>
</button>
<script type="module" src="telegraph-key.js"></script>
```

The four images are one photograph in four layers in the same box, in this order: the base (block, plates, anvil,
posts), the spring, the lever, and the near cheek of the trunnion (it stands in front of the lever's lug). Keep the
order and give all four the same `srcset` and `sizes`. At rest they composite to the photograph.

**Without JS** it is still a working submit button, and CSS alone presses the key (`:active`). **The module** makes
the stroke itself (it adds `.tk-js`, and CSS then follows its `data-tk-down` instead of `:active`): it presses for
Enter (a button is never `:active` for Enter), makes every press a whole stroke (a click quicker than the lever, as a
trackpad's tap is, still lands on the anvil), waits a moment on a touch so the start of a scroll never presses it,
springs the key back if the pointer slides off it while held, times the two clicks of the key, holds it down while a
send is going, and reports what happened:

```js
import { telegraphKey } from './telegraph-key.js';
const key = telegraphKey(button, { sending: 'Sending', sent: 'Sent' });   // auto-starts on [data-telegraph-key]
button.addEventListener('telegraph-key:down',    (e) => e.detail);  // { via }: the point has met the anvil
button.addEventListener('telegraph-key:contact', (e) => e.detail);  // { via }: ...and the stroke is a press, not a scroll
button.addEventListener('telegraph-key:up',      (e) => e.detail);  // { via, held, cancelled, contact }: back on its back screw
button.addEventListener('telegraph-key:send',    (e) => e.detail);  // { via, held, mark, form }: it sent
button.addEventListener('telegraph-key:state',   (e) => e.detail);  // { state, from }: idle, sending, sent

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  key.hold();                            // the key stays down on the anvil: busy, a second press does nothing
  await send(form);
  key.done();                            // it springs back onto its stop and says Sent for a moment
});                                      // key.done('Not sent') to say something else; key.reset() to just let go

key.press(); key.release(); key.tap();   // by hand
key.down;                                // true while the lever is down
key.state;                               // 'idle', 'sending' or 'sent'
key();                                   // destroy: listeners and timers go; the plain button stays
```

`via` is `pointer`, `touch`, `key` or `other`. `held` is how long the circuit stayed closed, in ms. `mark` is `dot`
or `dash` (held longer than 200 ms). A stroke is never cut short: however quick the click (a trackpad's tap-to-click
lasts a few milliseconds), the tap or the send, the point lands on the anvil and rests there before the spring throws
the lever back. The shortest stroke is a dot: 90 ms from press to lift, with the circuit closed for 42 ms of it (all
90 under reduced motion), and that is the `held` it reports, as Enter's does. The native `click` and `submit` are
untouched, so wire your action to those as usual.

`send` means it sent. A submit button in a form sends as its form submits: after the browser has checked the form,
just before your own `submit` handler. A click that the form's validation stops (a required field still empty), or
that a click handler cancels, still makes its stroke but sends nothing and never holds. `form.requestSubmit(key)`
sends too, with a stroke of its own. Any other button sends on its click. For Enter, `el.click()`, implicit
submission and a click quicker than the lever, the click comes first, so `send` comes before that stroke's `down` and
`up`; its `held` is the same as the `up`'s, unless a send then holds the key down. Call `hold()` in your submit
handler (for a button that submits no form, in its click handler), and not after an `await`, so the key never lifts
before it holds.

Every stroke has one `down` and one `up`. A second click inside a stroke's dot lands on a key that is still down: it
sends again, and the stroke stays one. An `up` with `cancelled: true` ended without a click: the pointer slid off
the key, a touch held still for a moment then became a scroll, or focus left while Space was down. `contact` says the
stroke was a press. For a mouse, a key or a click it comes with `down`. A touch or a pen cannot be told from the
start of a scroll until it lifts on the key, so a touch held on the key makes contact as it lifts (a quick tap has
lifted before the point lands, so it makes contact with `down`). A touch that rests on the key and then scrolls
shows the press, never makes contact, and its `up` says `contact: false`. A touch that turns into a scroll straight
away is not a press at all: no stroke, no events, no sound. Wire feedback that must never fire on a scroll (sound,
haptics) to `contact`, and to an `up` with `contact: true`, as the sounds are.

## Options

From `data-` attributes, or the options object (which wins).

| Option | Attribute | Default | |
|---|---|---|---|
| `sending` | `data-sending` | none | The word while a send is going (`hold()`). With it, the label's words are stacked in one cell, so the button never changes size. |
| `sent` | `data-sent` | none | The word for a moment after `done()`. |
| `sentFor` | `data-sent-for` | `1600` | How long the sent word shows, ms. |
| `dash` | `data-dash` | `200` | A contact held longer than this (ms) is a dash. |
| `hold` | `data-hold` | `false` | `true` (or the bare attribute): the key holds itself down as it sends, that is as its form submits (on its click, for a button that submits no form), never for a click that validation stops; the page then calls `done()` or `reset()`. |

## In life, and here

| In life | Here |
|---|---|
| The operator works the key from the wrist, with the fingers on the flat plate at the end of the lever. The lever is a little over four inches from the plate to the pin, and less than an inch from the pin to the contact, so the plate travels about five and a half times as far as the contact. | The plate is 111 mm from the pin and the contact 20.6 mm, measured on the photograph and checked against the Smithsonian's scan of the same key (113.8 and 20.2 mm). The lever turns about the pin, so the plate drops 7.6 mm while the point closes 1.4 mm: 2.9 px on a 40 px row button, 21 px on the large key. |
| The lever hangs on a steel pin through a lug that drops between two brass cheeks. The nut of the pin sits on the near cheek. | The pin's centre is the nut's centre, corrected for the camera's view about 12° from above. The near cheek and its nut are a layer of their own, over the lever, so the lug slides behind the cheek as the lever turns and the cheek never moves. |
| The front thumbscrew carries the platina point. Pressing brings it down onto the anvil and closes the circuit. The anvil is the down stop (Pope, §52). | The press is a rotation of 3.918° that ends exactly where the point meets the anvil: `telegraph-key:down`, then `telegraph-key:contact` and the contact click if sound is on (for a touch held on the key, as it lifts). While a message is going (`hold()`) the key stays there, the circuit closed. |
| A flat spring beneath the lever brings it back when the finger lifts. The back thumbscrew, resting on its post, is the up stop. | Release throws the lever back onto its back screw: `telegraph-key:up`, and a second, softer click. The spring is real too. It turns 1.613° about the end of its screwed plate, so its tip follows the lever. Its sweep over the block's top face uncovers wood, filled from that same face. Pressed, the back screw lifts 1.1 mm off its post: the screw's own rounded tip, and the top of the post's dome, which the tip hides in the photograph (see the cut, step 3). |
| The play, how far the lever travels, was each operator's own. It was set with the screws. | The museum keeps this key screwed down: both screws sit on their seats, measured column by column in the photograph, so as photographed it cannot move at all. Here the front thumbscrew stands 1.4 mm off the anvil, raised along its own thread, as an operator would set it: an open setting, chosen so the stroke reads at the size the button is used. The thread the raise shows above the lock nut is the same screw two pitches (1.64 mm) higher. |
| Morse code is made of the contact's lengths: a dot is a short closing, a dash about three dots. | `telegraph-key:send` tells you how long the contact was closed, and whether it was a dot or a dash. |

**The scan is for measuring only.** The Smithsonian's photogrammetry of the key (CC0) placed the pin and the lever
arms. It is never shown or rendered. Where the scan and the photograph disagree, the photograph wins. The scan shows
both contacts 0.47 mm open, which is how photogrammetry renders touching surfaces, not a setting.

## Sizes

| | class | key | button |
|---|---|---|---|
| Row (form footers, toolbars) | `.tk` | 32 px tall, 65 px wide | 40 px tall |
| Small (settings rows) | `.tk tk-sm` | 24 px | 32 px |
| Large (a panel's one action) | `.tk tk-lg` | `clamp(92px, 30vw, 236px)` tall, the word beneath in capitals; never wider than its container | |
| No frame (inside a toolbar) | add `tk-bare` | | |

The key's height is `--tk-key-h` and its width follows at 2.021 : 1. Pick `srcset` widths to match: 400 w for row
buttons, up to 1600 w for the large one (`sizes="(min-width: 790px) 477px, 61vw"` in the demo). On a 40 px row the
finger plate drops 2.9 px, on the 32 px small button 2.2 px.

## Theming

Uses `--ink`, `--ink-3`, `--paper-2`, `--rule`, `--sans`, and `--card` / `--card-line` when they are set.

| Variable | Default | |
|---|---|---|
| `--tk-key-h` | `32px` | The key's height. |
| `--tk-bg` | `var(--card, #f8f5ee)` | The button's face. |
| `--tk-line` | `var(--card-line, var(--rule))` | Its edge. |
| `--tk-down-bg` | `var(--paper-2)` | The face while the key is down. |
| `--tk-bare-down-bg` | `#ddd6c7` | The same for `.tk-bare`, deeper than its hover, and pressed in. |
| `--tk-press` | `48ms` | Finger to contact. The shortest stroke, press to lift, is this plus 20 ms, and never under 90 ms. |
| `--tk-release` | `72ms` | Spring to back stop. |

Both strokes ease in and stop dead, as a lever does when it hits a stop: no settle, no bounce.

## Accessibility

A real `<button>`: its name is the label, the key's images are `alt=""` inside an `aria-hidden` span. Focus shows a
2 px ink outline. Space presses and holds it, and its click comes on release, as with any button. Enter clicks at
once, and the key still makes a dot's stroke; holding Enter sends once, not at the key's repeat rate. A disabled key
cannot be pressed, takes no pressed tone (not even when it is disabled while a send holds it down), and turns grey
and faint; so does one with the author's `aria-disabled="true"`, which stays focusable and swallows its click. While
sending, the key has `aria-busy="true"` and `aria-disabled="true"`, keeps focus, and ignores presses and clicks (no
second submit). The words for sending and sent are in the label (the hidden ones `aria-hidden`); say what happened in
the page's own live region too, as the demo does. **Reduced motion:** the lever and spring go straight to each state
with no travel, so the events never wait on travel. A quick click still shows the key down for its dot (90 ms), so
the press is seen. In forced colours the frame takes `ButtonText`.

## How it was cut (offline, `tools/`)

Python, `./tools/run.sh <stage>.py`. The source is the Smithsonian's 7428 × 4872 JPEG (in
`tools/engine/jobs/telegraph-src`). Work is done at half size in `tools/engine/jobs/telegraph-cut`. From a copy of this
folder elsewhere, set `TK_SRC` and `TK_WORK` (and `TK_ASSETS` to export somewhere else); nothing is written until a
stage writes. `TK_PLAY_MM` sets the play (1.4).

1. `work.py`: the museum had already clipped the key onto pure white (every background pixel is 255). So each edge
   pixel is unmixed against white, `C = a·F + (1 − a)·white`, with `F` from the nearest solid pixel of the key.
   Bright highlights inside the outline (the block's chamfer, glints on the brass) stay key.
2. `parts.py`: the parts as loops of waypoints, loose against the sweep and exact where two parts meet. The boundaries
   are measured on zoomed, gridded crops (`gridcrop.py`): the contact line under the front point, the back screw's
   rounded tip down to its dark contact line on the post, the top of the near cheek, the circle where the front screw
   goes into its lock nut, the line where it comes out under the lever, and the post's dome (its two visible
   shoulders fit one circle to 0.6 px).
3. `layers.py`: the spring's two edges over the wood are traced with a livewire (dynamic programming down the
   strip); from its root its top is the far edge of its top surface on the wood (worn brass and patina against
   red-brown), so the whole strip turns. The wood its sweep can uncover is filled from the block's own top face: the
   same column cloned down where there is room, the same row translated along the grain near the face's far edge. It
   is never stretched. The front
   screw is lifted 26 px (1.4 mm). The rows it opens above the nut come from two thread pitches higher, at the
   thread's full width. Where the back screw's tip hides the top of the dome, the dome is carried up to its circle in
   the colour of its own rows just under the tip (in the screw's shadow). Every cut between two layers has the layer
   behind running on under the one in front: the base keeps every pixel that never moves (so the cheek's own cut
   edges lie over the same photograph), the lever's lug runs 28 px down behind the cheek with its own brass carried
   on down the column (it rises out of there by up to 12 px), the spring runs 16 px up under the lever where it
   bears on it, the far plate continues under the lever's block, and never at a soft edge, where two layers would
   both count.
4. `check.py`: the four layers composited at rest match the photograph everywhere except the raised screw (no pixel
   more than 2 levels off). Pressed and half-pressed, every joint is checked at 2–6×.
5. `export.py`: 400, 800 and 1600 px WebP, resized premultiplied, and `key.json` with the pivot, the spring's root and
   the angles.
6. `checkweb.py`: the exported layers composited at rest, at each export size and again at the sizes the page draws
   them (the row key at 2× and 3×, the small key, the large key), against the photograph resized the same way. The
   joints stay closed: outside the raised screw the worst pixel is 40 levels lighter, at single pixels on soft edges
   (before this, the cheek's cut showed as a light seam up to 61 levels lighter along its whole width).

## Cost

One size of the key is about 20 KB (400 w), 62 KB (800 w) or 173 KB (1600 w) for the four layers. The two sounds are
29 KB and load only if the visitor turns sound on. The module is about 19 KB with its comments and no dependencies.
Idle, nothing runs. A press is two CSS transforms for about a tenth of a second.

## Sound

Off until the visitor turns it on (`sound.js`, `sounds.json`; the house Sound toggle). `contact` plays on
`telegraph-key:contact`, as the point strikes the anvil. `backstop` plays on `telegraph-key:up` when that stroke made
contact (`"match": { "contact": true }`), as the spring throws the lever back. So a touch held on the key clicks as it
lifts, and a touch that becomes a scroll makes no sound at all. Both are cut from one take of antique brass switches
by SoundsofTheMachine (Freesound 797930, CC0):
a 1920s brass push switch and an old knife switch. No CC0 recording of a telegraph key itself was found on Commons
or Freesound.

## Credits

*Morse–Vail Telegraph Key*, 1844, Alfred Vail for Samuel F. B. Morse. Smithsonian National Museum of American History,
EM.181411, from Western Union Telegraph Co. Photograph NMAH-JN2014-3911, CC0 (Smithsonian Open Access). The 3D scan of
the same key (Smithsonian 3D, CC0) was used to measure. Other NMAH photographs of the key (88-8830-12, SIA-74-2491,
MAH-27979) were used to read the trunnion. Sounds: SoundsofTheMachine, Freesound 797930, CC0. See `assets/credits.json`
and `assets/PICK.md` (the hunt: 147 images of about 40 keys).

Reference: Frank L. Pope, *Modern Practice of the Electric Telegraph* (New York, 1869 and later), §52, "The Morse
Signal Key".

# qalamdan

A toggle switch that is a Persian pen box: Fathallah Shirazi's qalamdan, painted in Shiraz in the mid-19th century
with nightingales on flowering branches (*gul o bulbul*). Off, the box is closed. On, its own tray is drawn out of its
sleeve. In the tray's black lacquer well lie a calligrapher's tools, each cut from its own museum photograph and laid
at its catalogued size where it really lay:
- a silver filigree inkwell at the end;
- a jewelled reed pen and a penknife along the walls;
- a pierced bone plate under them;
- a gilt ink spoon on top.

Closed, it is the box as the Met photographed it from above. Both moving pieces are rigid cut-outs from the Met's own
documentation photographs of this box, and nothing else moves. It comes in two sizes:
- **The large box**, with its words in a pill beneath it.
- **`.ql-compact`**, a switch for a settings row or a toolbar. The pen box is its own track: off, the closed box lies
  at the left end; on, the tray comes out and its end cap fills the right end.

It is a real checkbox with `role="switch"` inside a `<label>`; the box is its picture. Without JS it still switches:
the label, Space and forms all talk to the checkbox, and `:checked` slides the tray in CSS.

```html
<link rel="stylesheet" href="qalamdan.css">
<label class="ql" data-qalamdan>
  <input type="checkbox" role="switch" class="ql-switch" name="tools">
  <span class="ql-box" aria-hidden="true">
    <span class="ql-tray">
      <img class="ql-tray-img" src="assets/tray.webp" width="1586" height="277" alt="">
      <!-- the tools, bottom of the pile first, placed in the tray photograph's own px (74 px/cm) -->
      <img class="ql-tool" src="assets/tools/pen-rest.webp"  alt="" style="--x:470;--y:48;--w:943">
      <img class="ql-tool" src="assets/tools/penholder.webp" alt="" style="--x:72;--y:42;--w:1063;--r:180deg">
      <img class="ql-tool" src="assets/tools/knife.webp"     alt="" style="--x:6;--y:146;--w:1134;--r:180deg">
      <img class="ql-tool" src="assets/tools/spoon.webp"     alt="" style="--x:478;--y:38;--w:683;--r:-7deg">
      <img class="ql-tool" src="assets/tools/inkwell.webp"   alt="" style="--x:1140;--y:39;--w:401">
    </span>
    <img class="ql-sleeve" src="assets/sleeve.webp" width="1595" height="280" alt="">
  </span>
  <span class="ql-text">Show the tools</span>
</label>
<script type="module" src="qalamdan.js"></script>
```

For a settings row, add `ql-compact` and put the words first, so they sit to the left of the switch:

```html
<label class="ql ql-compact" data-qalamdan>
  <span class="ql-text">Show the tools</span>
  <input type="checkbox" role="switch" class="ql-switch">
  <span class="ql-box" aria-hidden="true">…the same tray and sleeve…</span>
</label>
```

The input must come before `.ql-box`, because the CSS reads `.ql-switch:checked ~ .ql-box`. The input can carry
`name`, `value`, `checked` and `disabled`, and it posts with a form like any checkbox.

## API

The module boots every `[data-qalamdan]` on the page when it loads. Call it yourself for boxes added later:

```js
import { qalamdan } from './qalamdan.js';
const q = qalamdan(label, { pressed: true });   // returns the box's handle; label.qalamdan is the same handle
q.set(true);                                    // switch on or off; input and change fire, as if a person switched it
q.toggle();
q.pressed;                                      // true when on
q.input;                                        // the checkbox
label.addEventListener('qalamdan:toggle', (e) => e.detail.pressed);   // bubbles; on every change
q();                                            // destroy: listeners and the writing; the plain switch stays
```

- `qalamdan:toggle` fires on the label whenever the input's `change` does: a click, a tap, Space, Enter or `set()`.
  Its `detail` is `{ pressed }`.
- Starting on does not fire it: that is not a change.
- `set()` does nothing on a disabled switch, or when the switch is already in that state.

## Options

Set them as `data-*` on the label, or in the options object, which wins.

| Option | Attribute | Default | |
|---|---|---|---|
| `pressed` | `data-pressed` | off | Start on. The box lands there at once, without sliding as the page loads. `checked` on the input does the same and works without JS. `pressed: false` turns a `checked` input off. |
| `draw` | `data-draw` | `1100` | How far the tray comes out, in the tray photograph's px (74 px/cm): 14.9 cm. Also `--ql-draw`. |
| `well` | `data-well` | `66 210` | The band of the well's floor that takes words, in tray px (inside the sloping inner walls). |
| `minSize` | `data-min-size` | `13` | The smallest type for an inscription, css px. |

## In life, and here

| In life | Here |
|---|---|
| A *qalamdan* is made of papier-mâché: layers of paper pasted over a wooden former, gessoed, painted in watercolour and gold, and sealed under coat after coat of varnish. It has two parts. The **sleeve** is a tube closed at one end. The **tray** slides in from the open end and carries the tools. | Two rigid cut-outs: the sleeve and the tray of the same box. They come from the Met's own documentation photographs, taken straight down in one campaign at about 148 px/cm (`LC-2018_664a-d6`, `-d2`). Nothing is drawn: the tray's inside, its rims, its worn gilding and its dealer's label are the photograph's. |
| Closed, the two read as one painted surface. The sleeve's top runs on past its open end as a rounded **tongue**. The tray's end cap carries a **U-shaped rim**, gold on black, that wraps around it. Tabs on the cap's sides fill cut-outs in the sleeve, so the seam is a cusped line you have to look for. | Closed, the tray lies under the sleeve 45 px along, its rim around the tongue. That position was found by fitting the tongue's outline (390 px wide) into the rim's opening (391–400 px) and running the cap's outer walls flush with the sleeve (530 against 538). It was checked against the Met's closed three-quarter view (DP-19012-002). The cap's bare tab tops show only when the tray is out, as on the object. |
| You hold one part and draw the other with a thumb on the end cap: the inkwell end comes first. | Switching on is the hand. The tray comes 14.9 cm out of its 21 cm (`--ql-draw: 1100`) in a second, on an ease that settles, and switching off slides it home. In the demo's large boxes the tray stays and the sleeve slides off it, out past the edge of the screen (`--ql-split: 1`). The default moves each half the way, so the box stays in view inside any container. A compact switch holds its sleeve still and draws the tray 7.6 cm, to the end of its track. Under the pointer, a closed box gives 2 mm, the way a tray moves when you touch its cap. |
| Painters in Isfahan and Shiraz signed these boxes small, inside the painting, and many were made as gifts. This one is *gul o bulbul* in grisaille and gold on a tan ground, Fathallah Shirazi's palette (active about 1850s–80s). Along its upper edge, in his hand: "a gift presented to the presence of … His Exalted Highness the Nāʾib al-Salṭana, Amīr-i Kabīr, may my soul be his ransom". Those are the titles of Kamran Mirza, Nasir al-Din Shah's son and minister of war. Along the lower edge: *ʿamal-i Fatḥallāh Shīrāzī*, "the work of Fathallah Shirazi". | The painting is untouched, at half the Met's resolution, and keeps its wear: a chip of paper core at the closed end, rubbed gold along the top edge. |
| At the end of the tray sits the inkwell (*davat*), often silver, holding a tuft of raw silk (*liqa*) soaked in ink, so the pen takes only what it needs. | Cleveland's Qajar silver filigree inkwell (1942.854.c), cut from the photograph where it lies beside its own tray. It came out 2.7 cm wide, the width of a qalamdan tray's end, which is what it was made for. Its openwork is see-through to the lacquer. |
| The reed pen (*qalam*) is cut from a seasoned reed. It is opened along its length with the penknife (*qalamtarash*), pared, and split down the nib so the ink runs. The final cut across the tip, the *qaṭṭ*, is made on a small plate (*maqta'*) of bone or ivory, with one press of the knife. The angle of that cut is part of the script: each hand, *naskh* or *nastaʿlīq*, has its own. | The pen is a cut reed nib in its jewelled holder and the knife a gold-inlaid blade on a nephrite handle. Both are from the Walters (51.87, 57.620), both Ottoman: open collections hold Ottoman tools of this size, not Persian ones (see `assets/PICK.md`). Under them, a pierced bone plate with a *maqta'*'s shape, which the Met catalogues as a pen rest (21.6.110). The pen, 14.3 cm, and the knife, 15.2 cm, both lie beside the 5.4 cm inkwell in a 20.7 cm well, at their catalogued lengths. |
| A small spoon added water to the ink. | A parcel-gilt silver spoon dated 1808–9 (Met 97.2.205), laid on top with its bowl by the inkwell. |
| Some pen boxes carry verses. Rumi, in the Masnavi: the pen ran on in the writing, and on reaching love it split. Every qalam is split. | The demo's second switch, "Write the couplet", carries a lighter kit, and Rumi's couplet is written in its free lane of lacquer, a half-line to a line. That is pretext, laying the box's `.ql-note` into the gaps the tools leave. |

## What lies in the tray

The tools are content: put in the ones your page wants. The demo has the full kit and a lighter one (the pen, the
spoon and the ink). Keep each at its `--w` (its catalogued length × 74), and keep it inside the well:
- y 36–240 between the walls;
- x 10–1140 beside the inkwell, which takes 1140–1541.

A box can also carry a short **inscription**: a `.ql-note` inside `.ql-tray`, a line or two, with `<br>` for a new
line. qalamdan.js writes it in the lacquer the tools leave free:
- **pretext** (Cheng Lou's text layout) lays it line by line into the free runs between the tools. The runs are
  measured from each tool's own outline (its alpha, as placed and turned) and kept 2 mm clear of every tool and of the
  dealer's label.
- It is set at the **largest size at which it fits whole** (up to 30 tray px, never under `minSize`). Its lines are
  then balanced, and a `<br>` starts a new line (the two halves of a couplet).
- **If it can't fit whole, nothing is written**: the tray shows only its tools. A full kit leaves no lane, and a
  compact switch is far too small.
- The writing is part of the picture (`aria-hidden`), and without JS it isn't written. So put words that matter in the
  page as well, as the demo does in its gloss.

## Theming

Uses `--ink`, `--paper`, `--paper-2` and `--rule` (the compact track), `--accent` (the focus ring), `--serif` (the
inscription) and `--sans` (the words), each with a fallback.

| Variable | Default | |
|---|---|---|
| `--ql-draw` | `1100`; `560` compact | as `draw` |
| `--ql-split` | `.5`; `0` compact | How the drawing is shared. `0`: the sleeve stays and the tray comes out (a switch: the box fills its track). `.5`: each moves half the way. `1`: the tray stays and the sleeve slides off it, out of the box's room (clipped there). |
| `--ql-align` | `.5`; `0` compact | Where the closed box sits in its room, from `0` (left) to `1` (right). |
| `--ql-w` | `1628 + draw` | The box's room in tray px. The closed box is 1628, so this sets how big the box is in its container. |
| `--ql-bleed` | `0px` | Let the room run out into the page's margins, so a sleeve sliding off leaves at the page's edge, not the column's. The demo's large boxes use `--ql-split: 1; --ql-w: 2150; --ql-bleed: calc((100vw - 100%) / 2)`, and under 640 px `--ql-w: 1800; --ql-bleed: var(--gutter)`. The component sets no phone defaults: those are the page's to choose. |
| `--ql-h` | `22px` | Compact: the track's height. The track is as long as the box drawn open: 172 px at 22. |
| `--ql-track`, `--ql-track-line` | `--paper-2`, `--rule` | Compact: the track's fill and its edge. |
| `--ql-ring` | `--accent` | The focus ring. |
| `--ql-ink` | `#eadcb4` | The inscription. |
| `--ql-time` | `1.05s`; `.6s` compact | The slide. |
| `--ql-gap` | `clamp(14px, 2.2vw, 24px)` | The large box: from the box to its words. |

## Accessibility

- It is a native checkbox with `role="switch"`, announced as a switch, on or off. Its name is the visible words
  (`.ql-text`): the box and its tools are `aria-hidden`, decorative images in it.
- Space switches it (native), and Enter too (qalamdan.js). A click or tap anywhere on the label switches it, and the
  label is at least 44 px tall.
- The focus ring shows for keyboard focus only. On the large box it is drawn round the words, because the box's room
  may run to the page's edges. On a compact switch it is drawn round the track.
- A disabled switch is dimmed and can't be switched.
- In forced colours the picture can't show the state, so the real checkbox shows beside the words, and the shadows go.
- **Reduced motion:** nothing slides. On and off land at once, and the closed box doesn't give under the pointer.
- **Without JS:** the label, Space, the CSS slide and forms all still work. Enter, `qalamdan:toggle` and the
  inscription need the script.

## Cost

- **Assets:** 655 KB of WebP. The sleeve is 176 KB and the tray 117 KB; the tools are 35–115 KB each, 362 KB together.
  A compact switch loads the same files.
- **Code:** 15 KB of JS and 8 KB of CSS, unminified. pretext (145 KB) is imported only when a box has a `.ql-note` to
  lay.
- **Idle:** nothing runs. Switching is a CSS transition on two transforms. An inscription is laid once, while the box
  is still closed, and again only when the box changes size.

## Credits

See `assets/credits.json`: every part, its museum, accession number, licence and the photograph it was cut from.
`assets/PICK.md` has the hunt: the shortlists, the contact sheets, the measurements (size, white balance, light) and
why these.
- The box: Fathallah Shirazi, *Pen Box and Glass Case*, mid-19th century. The Met 2018.664a–d, Gift of Dara Zargar,
  2018, CC0.
- The inkwell: Cleveland Museum of Art 1942.854.c, Gift of George W. Bierce, CC0.
- The penknife and the penholder: Walters Art Museum 57.620 and 51.87, CC0.
- The plate and the spoon: The Met 21.6.110 (Gift of Lily S. Place, 1921) and 97.2.205 (Gift of Mrs. Samuel P. Avery,
  1897), CC0.

pretext v0.0.8 by Cheng Lou (MIT) is vendored unmodified in `vendor/pretext/`. Rumi's couplet (Masnavi I) is in a
new English rendering for this demo.

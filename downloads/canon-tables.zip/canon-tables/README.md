# canon-tables

A comparison table set in the canon pages of a Gospel book. Gospel books open with the canon tables of
Eusebius: the four Gospels in columns under painted arches, so that one passage can be found in every
Gospel by reading across a row, running over several pages (Canon I, II, …). This is the same thing for
any comparison you would put in a real page (plans, versions, translations, before and after) in two to
five columns, in one of two hands:

- **Roslin** (the default wherever he painted a page for the table): T'oros Roslin's Zeyt'un Gospels,
  1256 (the Getty), all eight of its canon pages (fols. 1v–8). The page is the folio itself, as
  photographed, with its cranes and partridges, cocks, candles, palms, crows and owls; its bays are
  emptied to bare parchment and its columns lifted off as parts, so they can still be moved. Every one
  of Roslin's canon pages has two bays, so this hand serves two-column tables: a canon *in quo duo*,
  two translations, two plans.
- **Metz** (three to five columns, or `data-hand="metz"`): a Carolingian Gospel book, ca. 825–50 (the
  Met). Its arcades are assembled for the table from parts cut from seven canon pages: arch rows,
  capitals, shafts and bases. A 3-column table gets three bays, a 5-column table five, and nothing is
  ever stretched.

The text is set in the architecture, not over it. Cheng Lou's pretext sets every line into the run left
free between the painted silhouettes (read from each part's own alpha). The Gospels' names sit up in the
crowns (Metz) or at the heads of the bays (Roslin); the first row starts inside the lunettes where the
curve shortens its lines, and an atlas's elbow, an ox's horn or a capital's painted head bites into the
lines beside it. Rows line up across the columns as the canon numbers do.

**A page holds what its painted shafts hold.** The table is never made to fit by growing the columns:
it goes on to the next canon page of the book, in the book's own order, as Canon I does in the real
thing. A row too long for what is left of a page is cut at the page's foot, each cell at the word where
it stopped, and continued at the head of the next. A table that fits one page is drawn at the scale at
which it fills it.

It is read and handled:

- **Scroll: it is written in.** As a row comes up into the window it is written, every Gospel's cell at
  once, line after line at a pen's pace, from the left, with a soft wet front. Rows come one after
  another, never all at once; a row written stays written.
- **Click: the passage is found.** Click a row (or press Enter on its row head): a rubric line is ruled
  across it, every cell opens to its whole passage (its `[data-more]`), the other rows of the page close
  up to their first line, fading where they go on, and if the opened row has moved out of view the
  window is carried to it. Click again, or Escape, and the page closes back.
- **Slide a column.** Grab a shaft (capital, shaft and base move together) and pull it sideways. It is
  stone: a heavy, damped spring behind the hand. The two bays it divides widen and narrow (each Metz arch
  rescaled whole about its springing; a Roslin column slides under the band with its corbel), every line
  in them set again every frame, and the rows re-align on springs. It stops where a bay could no longer
  hold its widest word. Let go and it settles back to the painter's spacing.
- **Carry a Gospel.** Drag a column's text sideways (on a touch screen, hold it first) and carry it to
  another bay. The others slide over on every page and are re-set at their new widths; put it down and
  the real table's columns are reordered too, and once the stone has settled the pages are cut again
  for the new order.

```html
<link rel="stylesheet" href="canon-tables.css">
<figure class="cn" data-canon-tables>
  <table>
    <caption>Canon I · in quo quattuor</caption>
    <thead>
      <tr><td></td><th scope="col">Matthew</th><th scope="col">Mark</th><th scope="col">Luke</th><th scope="col">John</th></tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">The loaves</th>
        <td><b>14.17</b> <span data-more>And they say unto him, </span>We have here but five loaves, and two fishes.<span data-more> <b>14.18</b> He said, Bring them hither to me.</span></td>
        <td><b>6.38</b> <span data-more>He saith unto them, How many loaves have ye? go and see. And when they knew, they say, </span>Five, and two fishes.</td>
        …
      </tr>
    </tbody>
  </table>
</figure>
<script type="module" src="canon-tables.js"></script>
```

Or `import { canonTables } from './canon-tables.js'` and call `canonTables(figure, options)`, which
returns `destroy()`.

- The source is a real `<table>`. Without JS (or before the fonts and parts arrive) it is that table,
  styled as a plain rubricated table; with JS it stays in the DOM, visually hidden, for screen readers,
  find-in-page and print, and the drawing beside it is `aria-hidden`.
- Two to five data columns (six works; more is left as a plain table). Rows whose first cell is a
  `<th>` have labels; without them the arcade takes the whole width.
- `<b>`, `<strong>` or `[data-rubric]` inside a cell is drawn in rubric red (verse numbers, prices).
  Only the colour changes, so pretext's measurements stay exact. Cells are text: put buttons and
  links outside the table.
- `<span data-more>` inside a cell is left out of the table as drawn, and opened when its row is
  clicked: put the rest of the passage in it (before, after or both). `<span data-less
  aria-hidden="true">` is drawn only while closed (a capital letter where the short form begins
  mid-sentence); the CSS hides it from the plain table, so the table always holds the whole passage.
- The `<caption>` is drawn under the bases in red capitals, where the books write *Finit canon*,
  with the page's number (*i*, *ii*, …) when the table runs over more than one.

## The real thing

Eusebius of Caesarea (about 260–339) divided each Gospel into numbered sections, about 1,160 in all,
and sorted them into ten canons: Canon I lists the passages found in all four Gospels, II to IV those in
three, V to IX those in two, X those in one alone. Each canon is a table of section numbers, one column
per Gospel, and a row holds the numbers of the same passage. A reader in Luke found the section number
in the margin, with its canon in red under it, turned to that canon, and read across the row to the
same story in the others. From the sixth century the tables were set under painted architecture, and
by the ninth they opened every Gospel book.

| In life | Here |
|---|---|
| Each Gospel has its column under its own arch, headed in red capitals (MAT, MAR, LVC, IOH), written small where the arch closes in. | Each column of the table has its bay; the `<th scope="col">` heads are set in red capitals high in the crowns, one size for all, the size the tightest crown allows. |
| The scribe writes inside the painted frame: the numbers keep clear of the columns and the arch. | Every line is set into the free run between the painted silhouettes, so the text follows the arch's curve and steps round a capital's elbow. |
| A row is one passage: its section numbers stand on the same line in every column, whatever their length. | A row is one `<tr>`: each row is as tall as its longest cell, short cells sit on the row's top line, and every column ends on one line. |
| Thin red rules divide the numbers into groups, interrupted by the columns; a red rule runs under the last line. | Red hairlines divide the rows and pass behind the shafts; a stronger one runs under the last row. |
| The page is ruled first and the arcade drawn to fit the number of columns the canon needs: three bays for Canon II, four for Canon I, sometimes more on a two-page opening. | The arcade is assembled for 2–5 columns from the parts of one folio, its bays in their own order, more bays inserted as middle pairs so that the ends stay the painter's own. |
| The bays of one page are not quite equal; the painter spaced them by eye. | The arcade keeps the folio's own bay widths at one scale; pretext gives each cell its own width. |
| Capitals and bases change from page to page: stepped blocks, Corinthian leaves, heads of men, lions and oxen (the creatures of the Evangelists), crouching atlases, seated figures, lion paws. | Seven folios, each with its own capitals, shafts and bases. A table takes one folio at random per visit (`data-folio` pins it). |
| The columns are marbled, twisted or plain, in alternating colours. | Each shaft is the painted shaft at its painted length. (Only a bay squeezed by hand, or a row opened past what its page holds, ever continues one for a moment, cross-faded in on its own axis.) |
| The canons run over several pages, each an arcade painted once at the page's proportions; Canon I alone takes two to four. | The table runs over the book's canon pages in its own order, each at its painted height; a long cell is continued on the next page at the word where it stopped. |
| The scribe wrote the numbers in after the arcade was painted, row by row across the page. | Each row is written in as it comes up into view, across every column at once. |
| The table is the way in: the reader finds a number, reads across, and turns to the passage in each Gospel. | A click opens the row's passage in every column at once, the rest of the page closing up round it. |
| In Armenian books the arcade is a great headpiece on columns, with birds drinking at a fountain, candles, and trees and crows beside it; the tables are written in the bays below. | The Roslin hand: the whole folio, untouched outside the bays; the bays emptied to parchment (the page's own tone and grain), the columns lifted off and moved as parts. |
| *Finit canon primus in quo quattuor*: the end of Canon I, in which the four. | The `<caption>`, under the bases, with the page's number. |

Simplified: the real tables hold numbers, not prose, and run to many rows a page; here a cell holds a
paragraph. The real page is laid out once; this one is laid out again at every width.

## How it is solved

pretext (Cheng Lou) measures every cell, head and label once at 100px. After that a line is
arithmetic over cached widths (`layoutNextLineRange`), linear in the font size, so the whole table can
be poured many times in a millisecond or two.

1. **The arcade.** The folio's arch row is cut at its capital centres into bays and two ends. The bays
   for n columns are laid side by side at one scale (never stretched), so the arch over a wide column
   is a little taller, as on the page. The scale is the one at which the arcade fills the measure,
   capped at 0.56 css px per source px so the parts are never enlarged on a 2x screen.
2. **The margin.** Row labels sit in the margin, flush toward the first shaft, like the section
   numbers in the margin of the Gospel text. Its width is bisected: the narrowest at which every label
   fits in two lines without breaking a word.
3. **The fit.** The text size steps down from 17 to 15px until every word fits its bay and every bay
   holds about six words a line. If none does (a phone, or many columns in a narrow measure), the
   arcade becomes one arch wide and swipes sideways, a bay at a time, with the labels moved inside each
   bay above its row, and a row of column names under it to jump between bays.
4. **The lines.** Each line of a cell is set by `layoutNextLineRange` into its own run: from the right
   edge of the left column's silhouette to the left edge of the right column's, over the line's
   height, and inside the arch's intrados where the line is above the springing. A run narrower than
   about three words (or one that would break a word, where the bay is wider lower down) is skipped half
   a line at a time; a short fragment stranded above an obstruction is taken back and set below it.
5. **The rows.** Each row is as tall as its tallest cell. Because all columns share the row heights,
   swiping from one column to the next on a phone keeps every row exactly where it was.
6. **The pages.** Rows go onto a page while its painted shafts hold them (a page's capacity is the
   foot of its painted shafts, or of its base band). The next row goes over to the next folio. A row is
   cut at the page's foot if it is the first on the page, or if more than six lines of the page would
   otherwise stand empty: each cell stops at the pretext cursor where its lines ran out, and the next
   page starts from that cursor (`layoutNextLineRange` takes it as it is). Every page but the last keeps
   its painted height; the last ends with its text. A one-page table is bisected for the scale at which
   it fills its page (down to 86% of the widest).

## Reading it

- **Writing in.** A row starts writing when its top passes 90% of the window's height (more near the
  foot of the document, so the last rows are always written). Each line of each cell is unmasked from
  the left with a 1.6em soft front, starting 0.11 s after the line above it, taking 0.22 s plus 7.5 ms
  a character. Rows already above the window are written at once. With `data-ink="off"`, or reduced
  motion, everything is simply there.
- **Opening.** The opened row is set from its whole passage (pretext prepared both forms once); the
  other rows of its page are set with room for one line, which fades out over its last 3.2em; the row
  springs carry everything to its new place, lines that come in fade in, lines that go fade where they
  stood. A row cut over two pages opens whole on the first and is withheld from the second while open.
  420 ms later, if the opened row is not in the window, the window scrolls just enough to bring it in,
  never its head out.

## Handling it

Every frame while something moves: the springs step (at 120 Hz), the table is set again at the joints'
present places (heads, rows, every line), and the drawing is moved
(pooled line elements, transforms only; a line's markup changes only when its words do).

- **The columns** are springs on the joints' offsets: ω 10, ζ 0.95 while held (it lags the hand, as a
  weight does), ω 6, ζ 1 coming home (critically damped: no bounce). Limits: a bay keeps room for its
  widest word plus the two columns' half-widths and its margins; no arch is scaled below a half or above
  five thirds. Past the limit the stone gives by 4%, at most a third of an em.
- **The arches** rescale each bay uniformly about its springing (so both capitals stay under it). Where
  a big arch meets a small one, their joint is cross-faded over a width proportional to the difference
  in scale; at rest it is zero and the arcade is the folio's own pixels.
- **The rows** are springs (ω 12, ζ 1) on their tops; the text of a row rides its row.
- **A plate cannot grow**, so on Roslin's pages a column stops where narrowing its bay would push the
  text past the base band (found while dragging, held until it is let go).
- **Carrying** moves the Gospel's text with the pointer; when its centre passes into another bay the
  order changes, and the others keep where they were drawn and slide (ω 11, ζ 1) into their new bays,
  set at the new widths. On release the real `<table>`'s cells are moved into the new order, a live
  region says so, and `canon-tables:reorder` fires with `detail.order` (the column names).

Measured on the demo's Canon I (24 cells, now over two pages) while dragging, at 1440px and DPR 2:
stepping, setting the page and moving the drawing takes a median 0.4 ms a frame (p95 0.6 ms, worst
7.3 ms, a page re-cut) across 881 frames.

`root.dataset.cnJoints` reports the joints' offsets while they move, `root.dataset.cnFrame` the last
frame's time in ms.

`root.dataset.cnSolve` reports the last solve (time, the folios of the pages, columns, scales, mode);
`root.dataset.cnPages` the number of pages; `root.dataset.cnMode` is `folio` or `swipe`;
`root.dataset.cnRow` is the row last lit.

## The parts

Made offline from the Met's photographs (scripts in `tools/engine/jobs/canon-tables-work/`: `cut.py`,
`pack.py`). For each folio, the capital centres, the springing, the necking and the base lines were read
by eye off gridded crops; then the vellum is estimated locally (a blur of the bare parchment) and
every pixel's colour distance from it gives the paint. The arch row keeps everything painted above the
springing; a capital, shaft or base keeps only what is connected to its own column's centre strip, so
the rubrics and numerals that touch the columns fall away (red that is not part of the column is
removed, and a few touching letters by hand-placed boxes). Shafts are traced row by row between their
outer ink lines, with the edges smoothed along their length. Edge colour is un-mixed from the vellum,
so the parts sit on any light sheet. `assets/arcades.json` holds each folio's geometry, every part's
place on the page, and each shaft's centreline.

Columns against the binding (the last shaft or base on folios 16, 18, 21 and 24, the last capital on 18,
21 and 24) are left out and replaced by a sister two columns along, the colour the painter alternated;
the right ends of 18, 21 and 24 run into the gutter and are drawn as the folio's own left end, turned.
The finial folios (04, 05) are used only for four columns, so a finial is never cut in half.

### Roslin's pages

Getty Ms. 59 (Zeyt'un Gospels, Hromkla, 1256), all eight canon pages, fols. 1v–8 (four facing
openings, each page two bays), from the Getty's IIIF (3168×4418; fol. 6 at 4600×6400) and worked at 2100 wide (`tools/engine/jobs/
canon-tables-roslin/roslin.py`, `pack.py`). The column centres and the band and base lines were read
off gridded crops and then found exactly (the band is the run of rows that are paint right across a
bay). Each column is cut row by row outward from its axis until four pixels of bare parchment, median
filtered over 15 rows (the old table's gold ruling touches the capitals in places), with the red and gold
flecks beside it taken along (never the scribe's dark ink) and the corbels under the band included, so
a column slides along the band as a bracket would. The bays and the place of each column are refilled
with parchment: the tone carried in from the bays' own bare parchment between the old ruling, and the
grain (its dark flecks included) tiled from the page's bottom margin, its strength matched to the
margin's. Everything outside the bays is the photograph. Every plate and column passes the engine.

## Options

| attribute | option | default | what it does |
|---|---|---|---|
| `data-hand` | `hand` | `auto` | `auto`: Roslin's whole pages where he painted one for this many columns (two), else the Metz arcades. `roslin` or `metz` forces one. |
| `data-folio` | `folio` | `auto` | The first page's folio (`04 05 16 17 18 21 24`; Roslin `f1v f2 f7v f8`); the next pages follow in the book's order. `auto` starts at a random one per visit. |
| `data-ink` | `ink` | `on` | `off`: no writing in on scroll. |
| `data-seed` | `seed` | random | A number makes `auto` pick the same folio every load (stills, tests). |
| `data-size` | `size` | auto | Cell text size in px. Auto is 17 down to 15, the largest that fits. |
| `data-max-scale` | `maxScale` | from the hand | Largest css px per source px (Metz 0.56, Roslin 0.5). Above 0.5 the art is slightly enlarged on 2x screens. |
| `data-min-cell` | `minCell` | `6.4` | Narrowest bay text, in ems, before the arcade swipes. |
| `data-src` | `src` | by hand | The manifest (`assets/arcades.json` or `assets/roslin.json`), resolved from the module's folder. |

## Theming

| variable | default | |
|---|---|---|
| `--cn-ink` | `#2e241b` | Cell text: iron-gall brown-black. |
| `--cn-rubric` | `#b4462a` | Heads, verse numbers, the reading line, lit labels: the book's orange-red minium. |
| `--cn-dim` | `#b8ab95` | Text of the other rows while one is lit. |
| `--cn-label` | `var(--ink-2)` | Row labels at rest. |
| `--cn-rule` | `rgba(180,70,42,.5)` | The hairlines between rows. |
| `--cn-cell-font`, `--cn-head-font` | EB Garamond, Cormorant Garamond | Load them before the script (the demo uses Google Fonts). |

Set it on a light sheet: the parts carry the painted colour only, and a halo of the book's vellum
shows faintly on dark grounds. The demo uses `#f1e9d6`.

## Accessibility and reduced motion

- The real table is what screen readers read: headers, scope, caption, all intact.
- Keyboard: the row headers of the source table take one tab stop between them; Tab lands on the
  first, Up/Down/Home/End move between rows and light each one on the drawing (scrolling to it if it is
  off screen), with a focus ring round its label; **Enter or Space opens its passage**, and the opening
  is announced. In the swiping arcade, Left/Right move between columns. Esc closes.
- The column headers take another tab stop: Left/Right move between them (a ring round the name on
  the drawing); **Shift+Left/Right carries the column** one bay over (the table is reordered and it is
  announced); **Alt+Left/Right shoves the shaft on its right**, held while the key repeats, settling
  back when it stops.
- Pointer: hover lights a row; click or tap opens it (or pins it, when it has nothing more); tap again or anywhere else lets go. A sideways
  drag on a column moves it; on the text it carries the Gospel (mouse), or after a 380 ms hold (touch).
  The drawing is `touch-action: pan-y`, so a vertical swipe always scrolls the page. On a phone's
  swiping arcade the shafts keep `pan-y` (a sideways drag on a shaft moves it) and the text scrolls the
  bays natively.
- The pager under a swiping arcade is real buttons, 44px tall, with the current column marked
  `aria-current`.
- Reduced motion: no springs. A column still follows the hand (direct manipulation) and is home the
  moment it is let go; a carried Gospel drops straight into place; rows re-align at once. The reading
  line appears without running, the text falls back without fading, the pager scrolls without
  smoothing. Nothing is written in: every row is there. Opening a row re-sets the page at once. Nothing
  moves by itself in any case.
- The frame loop runs only while something moves and the table is on screen; at rest nothing runs.

## Cost

Metz: 3.8 MB in all, about 0.5–0.6 MB of webp a page (the arch row, four to six capitals, shafts and
bases). Roslin: about 1.1 MB a page (the plate, about 0.9 MB, and its three columns); 8.7 MB for all eight. The first page's
folio is loaded before the table is drawn; the next pages' as they come near (lazy images, preloaded
after the first draw). The solve with pagination is 3–13 ms.

## Credits

- Metz hand: Gospel Book, Carolingian, made probably in Metz, ca. 825–50. The Metropolitan Museum of
  Art, The Cloisters Collection and Director's Fund, 2015 (2015.560), Open Access, CC0. Seven folios.
- Roslin hand: T'oros Roslin, Zeyt'un Gospels, Hromkla, 1256. J. Paul Getty Museum, Ms. 59 (95.MG.4),
  Open Content (CC0). Fols. 1v, 2, 3v, 4, 5v, 6, 7v, 8. Every part is listed with its source image in
  `assets/credits.json`.
- [pretext](https://github.com/chenglou/pretext) by Cheng Lou, MIT (`vendor/pretext`, unmodified,
  with its `LICENSE` and `VERSION`).
- Demo texts: the King James Version and the Clementine Vulgate (public domain): the Lord's Prayer
  (Matthew 6, Luke 11; Canon V), John 1:1–14, the feeding of the five thousand (Canon I). The plans
  table was written for the demo.
